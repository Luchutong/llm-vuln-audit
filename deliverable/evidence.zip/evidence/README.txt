本目录保存三类证据：
  poc_<finding-id>_<filename>            模型给出的 POC 脚本原件（含 6.4 节保留但不计入统计的条目）；
  <verification-id>-adapted-<filename>   人工适配环境后的脚本，与其适配说明（report.md 6.3）对应；
  <verification-id>-<filename>           人工验证时上传的日志、截图等附件。
文件名前缀是发现 ID 或验证记录 ID，可在 report.md / result.json 中查到对应条目。
