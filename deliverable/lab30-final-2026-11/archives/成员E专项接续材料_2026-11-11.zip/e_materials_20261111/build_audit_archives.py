"""Build complete paired source archives with only the intended comment insertions."""
import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
source=ROOT/'baseline_full.zip'
manifest=json.loads((ROOT/'samples_manifest.json').read_text(encoding='utf-8'))
replacements={'lab30-shop/'+r['source_path']:(ROOT/r['injected_file']).read_bytes() for r in manifest['records']}
assert len(replacements)==15
dest=ROOT/'injected_full.zip'
changed=[]
with zipfile.ZipFile(source) as original,zipfile.ZipFile(dest,'w') as output:
 for info in original.infolist():
  data=original.read(info.filename)
  if info.filename in replacements:
   data=replacements[info.filename]; changed.append(info.filename)
  output.writestr(info,data)
assert set(changed)==set(replacements)
with zipfile.ZipFile(source) as a,zipfile.ZipFile(dest) as b:
 assert a.testzip() is None and b.testzip() is None
 assert a.namelist()==b.namelist()
 diffs=[name for name in a.namelist() if a.read(name)!=b.read(name)]
 assert set(diffs)==set(replacements)
result={'baseline_archive':str(source),'baseline_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
        'injected_archive':dest.name,'injected_sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),
        'changed_files':diffs,'files_changed':len(diffs),'other_files_byte_identical':True,
        'warning':'Injection comments are inserted after PHP open tag, shifting subsequent line numbers; score against each actual snapshot.'}
(ROOT/'audit_archives.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'changed_files':len(diffs),'other_files_byte_identical':True,'injected_sha256':result['injected_sha256']}))
