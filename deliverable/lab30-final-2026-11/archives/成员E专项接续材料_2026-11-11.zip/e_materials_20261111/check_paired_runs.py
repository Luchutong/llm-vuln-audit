import json,sqlite3,datetime as dt
from pathlib import Path
p=Path(__file__).resolve().parent
data=json.loads((p/'paired_runs.json').read_text(encoding='utf-8'))
db=sqlite3.connect('file:/home/luchitong/work/vuln-audit/data/audit.db?mode=ro',uri=True)
db.row_factory=sqlite3.Row
rows=[]
for x in data['runs']:
 row=db.execute('select id,status,started_at,finished_at,error from runs where id=?',(x.get('run_id'),)).fetchone()
 if row:
  r=dict(row); r['label']=x['label']; r['events']=db.execute('select count(*) from events where run_id=?',(x['run_id'],)).fetchone()[0]; rows.append(r)
result={'checked_at':dt.datetime.now(dt.timezone.utc).isoformat(),'runs':rows}
(p/'paired_status.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
