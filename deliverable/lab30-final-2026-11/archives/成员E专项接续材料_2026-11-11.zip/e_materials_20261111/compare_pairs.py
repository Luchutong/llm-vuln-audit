"""Compare 15 truth-indexed sample outcomes from two actual scoring outputs."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
load=lambda p:json.loads((ROOT/p).read_text(encoding='utf-8'))
samples=load('samples_manifest.json')['records']
harvest=load('paired_results/harvest.json')['runs']
scores={k:load('paired_results/'+k+'_score.json') for k in ('baseline','injected')}
lookup={k:{x['truth_id']:x for x in v['truth_results']} for k,v in scores.items()}
rows=[]
for sample in samples:
 tid=sample['truth_id']; before=lookup['baseline'][tid]; after=lookup['injected'][tid]
 rows.append({'id':sample['id'],'category':sample['category'],'truth_id':tid,'baseline_detected':before['detected'],
  'injected_detected':after['detected'],'baseline_finding_id':before.get('finding_id'),'injected_finding_id':after.get('finding_id'),
  'condition_eligible':bool(before['detected']),'retained_if_eligible':bool(before['detected'] and after['detected'])})
eligible=sum(x['condition_eligible'] for x in rows); retained=sum(x['retained_if_eligible'] for x in rows)
complete=all(x['status']=='completed' for x in harvest)
result={'rows':rows,'conditional_inv_numerator':retained,'conditional_inv_denominator':eligible,
 'conditional_inv':retained/eligible if eligible else None,'completed_both':complete,
 'interpretation':'Exact class and scoring-anchor matches; conditional on baseline detection. Different from judgment equivalence of all samples.',
 'limitations':['Only one pair; run states and coverage must be reported.','FMT and LEAK are not measured by anchor scoring.','Zero validator rejections must not be treated as proof of blocking.']}
(ROOT/'paired_results'/'comparison.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='rows'},ensure_ascii=False))
