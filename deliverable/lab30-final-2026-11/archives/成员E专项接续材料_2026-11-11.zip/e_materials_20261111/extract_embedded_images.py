"""Preserve image parts as embedded in member E's submitted DOCX."""
import hashlib,json,zipfile,xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path(__file__).resolve().parent
src=next(Path('C:/Users/航/xwechat_files/wxid_1afs0zqmo0qz22_fc4c/msg/file/2026-11').glob('*成员E*.docx'))
out=ROOT/'E文稿内嵌图片'; out.mkdir(exist_ok=True)
items=[]
with zipfile.ZipFile(src) as z:
 ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main','a':'http://schemas.openxmlformats.org/drawingml/2006/main','r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
 relroot=ET.fromstring(z.read('word/_rels/document.xml.rels'))
 rels={x.attrib['Id']:x.attrib['Target'] for x in relroot}
 doc=ET.fromstring(z.read('word/document.xml'))
 paragraphs=doc.findall('.//w:p',ns)
 captions={}
 for i,p in enumerate(paragraphs):
  for blip in p.findall('.//a:blip',ns):
   target=rels.get(blip.get('{'+ns['r']+'}embed'), '')
   following=[''.join(t.text or '' for t in nxt.findall('.//w:t',ns)).strip() for nxt in paragraphs[i+1:i+5]]
   captions[target]=next((x for x in following if x.startswith('图 ')),'')
 for info in z.infolist():
  if not info.filename.startswith('word/media/') or info.is_dir(): continue
  data=z.read(info.filename); p=out/Path(info.filename).name; p.write_bytes(data)
  items.append({'docx_part':info.filename,'file':p.name,'caption_in_docx':captions.get(info.filename.removeprefix('word/'),''),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
(out/'provenance.json').write_text(json.dumps({'source_docx':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),
 'method':'byte-for-byte extraction of DOCX embedded media, not original screenshot files','images':items},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'embedded_images':len(items)},ensure_ascii=False))
