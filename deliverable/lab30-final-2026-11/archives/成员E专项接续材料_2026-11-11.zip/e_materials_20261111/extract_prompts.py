"""Extract member E's three original prompt texts without inventing registration."""
from pathlib import Path
import hashlib,json,zipfile,xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parent
source=next(Path('C:/Users/航/xwechat_files/wxid_1afs0zqmo0qz22_fc4c/msg/file/2026-11').glob('*成员E*.docx'))
ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
with zipfile.ZipFile(source) as z:
    doc=ET.fromstring(z.read('word/document.xml'))
paragraphs=[''.join(t.text or '' for t in p.findall('.//w:t',ns)) for p in doc.findall('.//w:p',ns)]
markers=[('A.1　S-secondorder　二次注入专属','secondorder'),('A.2　S-authz　越权与隐性逻辑漏洞专属','authz'),('A.3　S-state　状态机与并发缺陷专属','state'),('附录 B　路由 ↔ 入口 ↔ 参数映射表（30 行）',None)]
positions=[next(i for i,p in enumerate(paragraphs) if p.strip()==name) for name,_ in markers]
records=[]
for j,(_,name) in enumerate(markers[:-1]):
    out=ROOT/'prompts'/(name+'.md'); out.parent.mkdir(exist_ok=True)
    text='\n\n'.join(p for p in paragraphs[positions[j]+1:positions[j+1]] if p.strip())+'\n'
    out.write_text(text,encoding='utf-8')
    records.append({'name':name,'path':str(out.relative_to(ROOT)).replace('\\','/'),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'registration_and_invocation':'not located; not claimed'})
(ROOT/'prompts'/'provenance.json').write_text(json.dumps({'source':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'extraction':'paragraph text from docx word/document.xml','prompts':records},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'prompts':len(records)},ensure_ascii=False))
