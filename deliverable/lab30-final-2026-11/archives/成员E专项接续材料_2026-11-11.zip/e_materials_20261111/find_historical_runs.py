import sqlite3,json
from pathlib import Path
db=sqlite3.connect('file:/home/luchitong/work/vuln-audit/data/audit.db?mode=ro',uri=True)
rows=[]
for prefix in ('1856ce70','f4cf5cef','147c3a95'):
    matches=db.execute('select id,status,created_at,snapshot_id from runs where id like ?', (prefix+'%',)).fetchall()
    rows.append({'prefix':prefix,'matches':[dict(zip(('id','status','created_at','snapshot_id'),row)) for row in matches]})
Path(__file__).with_name('historical_run_lookup.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(rows,ensure_ascii=False))
