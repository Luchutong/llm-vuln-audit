"""Freeze mechanical line-offset anchors before inspecting paired results."""
import hashlib,json,zipfile,datetime as dt
from pathlib import Path
ROOT=Path(__file__).resolve().parent
src=ROOT/'baseline_anchors.json'
data=json.loads(src.read_text(encoding='utf-8'))
samples=json.loads((ROOT/'samples_manifest.json').read_text(encoding='utf-8'))['records']
changed={x['source_path'] for x in samples}
injected=ROOT/'injected_full.zip'
data['source_archive_sha256']=hashlib.sha256(injected.read_bytes()).hexdigest()
data['review']['note']='机械变换：仅对插入一行注释的文件中原第2行及以后位置加1；在查看配对运行结果之前冻结。真值类别及锚点源码行内容不改。'
adjustments=[]
with zipfile.ZipFile(injected) as z:
 for v in data['vulnerabilities']:
  for a in v['scoring_locations']:
   if a['path'] in changed and a['line']>=2:
    old=a['line']; a['line']+=1
    line=z.read('lab30-shop/'+a['path']).splitlines()[a['line']-1]
    assert hashlib.sha256(line).hexdigest()==a['line_sha256'],(a['path'],old)
    adjustments.append({'truth_id':v['id'],'path':a['path'],'old_line':old,'new_line':a['line'],'line_sha256':a['line_sha256']})
(ROOT/'injected_anchors.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(ROOT/'anchor_adjustments.json').write_text(json.dumps({'frozen_at':dt.datetime.now(dt.timezone.utc).isoformat(),'adjustments':adjustments},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'adjustments':len(adjustments),'all_line_hashes_match':True}))
