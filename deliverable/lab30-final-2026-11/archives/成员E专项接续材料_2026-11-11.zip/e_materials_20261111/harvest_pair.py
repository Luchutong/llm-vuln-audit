"""Export finished paired runs, redact credentials, and replay frozen-anchor scoring."""
import datetime as dt,hashlib,json,re,sqlite3,subprocess,sys,urllib.request,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
runlist=json.loads((ROOT/'paired_runs.json').read_text(encoding='utf-8'))['runs']
db=sqlite3.connect('file:/home/luchitong/work/vuln-audit/data/audit.db?mode=ro',uri=True); db.row_factory=sqlite3.Row
OUT=ROOT/'paired_results'; OUT.mkdir(exist_ok=True)
def redact(v,key=''):
 if re.fullmatch(r'(authorization|cookie|set.cookie|password|passwd|api.key|access.token|refresh.token|auth.token|capability.token|session.id|secret|bearer.token|csrf.token|encrypted.*)',key,re.I) and v: return '[REDACTED]'
 if isinstance(v,dict): return {k:redact(x,k) for k,x in v.items()}
 if isinstance(v,list): return [redact(x) for x in v]
 if isinstance(v,str):
  v=re.sub(r'(?im)^(\s*(?:Cookie|Set-Cookie|Authorization|Proxy-Authorization)\s*:\s*)[^\n]+',r'\1[REDACTED]',v)
  v=re.sub(r'(?i)(\b(?:PHPSESSID|sessionid|csrftoken|csrf_token)=)[^\s;"&<>]+',r'\1[REDACTED]',v)
  v=re.sub(r'\bsk-[A-Za-z0-9_-]{16,}','[REDACTED_API_KEY]',v)
  return re.sub(r'(?i)(\bBearer\s+)[A-Za-z0-9._~+/-]{12,}',r'\1[REDACTED]',v)
 return v
def save(name,obj): (OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
keep=('id','finding_kind','category','title','summary','disposition','vulnerability_type','primary_location','evidence','cvss','severity','legacy_severity')
meta=[]
for entry in runlist:
 label,rid=entry['label'],entry['run_id']
 status=db.execute('select status from runs where id=?',(rid,)).fetchone()['status']
 if status in ('running','pending','queued'): raise SystemExit(label+' still '+status)
 row=db.execute('select json_export,input_hash,created_at from frozen_run_reports where run_id=?',(rid,)).fetchone()
 if row:
  raw=row['json_export'].encode(); source='frozen_run_reports'
 else:
  with urllib.request.urlopen('http://127.0.0.1:8899/api/runs/'+rid+'/report?format=json',timeout=120) as response: raw=response.read()
  source='live report export (no frozen report)'
 report=json.loads(raw); save(label+'_report.redacted.json',redact(report))
 allfind=report.get('findings') or []
 accepted=[f for f in allfind if f.get('disposition','open') not in ('duplicate','retracted','superseded') and (f.get('final_review_decision') or {}).get('decision')=='accept']
 selected=accepted if accepted else [f for f in allfind if f.get('disposition','open') not in ('duplicate','retracted','superseded')]
 method='final accepted' if accepted else 'active candidates; no accepted set available'
 inputs=[{k:f.get(k) for k in keep} for f in selected]; save(label+'_findings.json',redact(inputs))
 # Independent limited output check: required fields and source line bounds on the
 # actual archive. This does not prove semantic correctness or lack of leakage.
 checks=[]
 with zipfile.ZipFile(ROOT/entry['archive']) as archive:
  names=set(archive.namelist())
  for f in selected:
   refs=f.get('evidence') or []; errors=[]
   if not f.get('title') or not f.get('summary') or not isinstance(refs,list) or not refs:
    errors.append('missing title/summary/evidence')
   if isinstance(refs,list):
    for ref in refs:
     path=ref.get('path',''); path=path if path.startswith('lab30-shop/') else 'lab30-shop/'+path
     if path not in names: errors.append('missing source file: '+path); continue
     lines=len(archive.read(path).splitlines()); start=ref.get('start_line'); end=ref.get('end_line')
     if not isinstance(start,int) or not isinstance(end,int) or not 1<=start<=end<=lines: errors.append('invalid source range: '+path)
   checks.append({'finding_id':f.get('id'),'passed':not errors,'errors':errors})
 save(label+'_format_checks.json',{'scope':'title, summary, evidence file/range; selected records only','checks':checks,
      'passed':sum(x['passed'] for x in checks),'total':len(checks)})
 anchor=ROOT/'injected_anchors.json' if label=='injected' else ROOT/'baseline_anchors.json'
 command=[sys.executable,str(ROOT/'replay/scripts/score_dataset.py'),'--protocol','lab30-v2','--truth',str(ROOT/'ground_truth.json'),'--anchors',str(anchor),'--findings',str(OUT/(label+'_findings.json')),'--out',str(OUT/(label+'_score.json'))]
 proc=subprocess.run(command,capture_output=True,text=True,encoding='utf-8',cwd=ROOT)
 (OUT/(label+'_score.log')).write_text(proc.stdout+proc.stderr,encoding='utf-8')
 meta.append({'label':label,'run_id':rid,'status':status,'source':source,'raw_export_sha256':hashlib.sha256(raw).hexdigest(),'finding_count':len(inputs),'selection':method,'score_exit_code':proc.returncode,'score_command':command})
save('harvest.json',{'collected_at':dt.datetime.now(dt.timezone.utc).isoformat(),'runs':meta,'redaction':'header/key/known token patterns; not a blanket secret detector','poc_mode':'off'})
print(json.dumps(meta,ensure_ascii=False))
