"""Enumerate ZAP alert instances and exact-path truth candidates without declaring TP/FP."""
import json,sys
from pathlib import Path
from urllib.parse import urlsplit
ROOT=Path(__file__).resolve().parent
truth=json.loads((ROOT/'ground_truth.json').read_text(encoding='utf-8'))['vulnerabilities']
source=ROOT/'zap'/sys.argv[1]
data=json.loads(source.read_text(encoding='utf-8-sig'))
rows=[]
for site in data.get('site',[]):
 for alert in site.get('alerts',[]):
  for inst in alert.get('instances',[]):
   path=urlsplit(inst.get('uri','')).path or '/'
   candidates=[]
   for t in truth:
    entry=t.get('entry_point') or {}
    route=entry.get('route','')
    if isinstance(route,str) and path in route.split():
     candidates.append({'truth_id':t['id'],'title':t['title'],'expected_parameter':entry.get('parameter'),'truth_class':t.get('class')})
   rows.append({'plugin_id':alert.get('pluginid'),'alert':alert.get('alert'),'risk':alert.get('riskdesc'),
      'url':inst.get('uri'),'path':path,'method':inst.get('method'),'parameter':inst.get('param'),
      'evidence':inst.get('evidence'),'path_candidates':candidates,'assessment':'unreviewed; path match alone is not a truth match'})
out=ROOT/'zap'/(source.stem+'_instances.json')
out.write_text(json.dumps({'source':source.name,'zap_version':data.get('@version'),'instances':rows},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'source':source.name,'alert_types':sum(len(s.get('alerts',[])) for s in data.get('site',[])),'instances':len(rows),'with_path_candidates':sum(bool(r['path_candidates']) for r in rows),'tp_fp':'not assessed'},ensure_ascii=False))
