"""Verify SHA manifest and reproduce the two deterministic scores offline."""
import hashlib,json,os,subprocess,sys,tempfile,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'manifest.json').read_text(encoding='utf-8'))
for name,entry in manifest['files'].items():
 data=(ROOT/name).read_bytes()
 assert hashlib.sha256(data).hexdigest()==entry['sha256'],name
for s in json.loads((ROOT/'samples_manifest.json').read_text(encoding='utf-8'))['records']:
 for kind in ('baseline','injected'):
  assert hashlib.sha256((ROOT/s[kind+'_file']).read_bytes()).hexdigest()==s[kind+'_sha256']
with tempfile.TemporaryDirectory() as temp:
 for label in ('baseline','injected'):
  out=Path(temp)/(label+'.json')
  cmd=[sys.executable,str(ROOT/'replay/scripts/score_dataset.py'),'--protocol','lab30-v2',
   '--truth',str(ROOT/'ground_truth.json'),'--anchors',str(ROOT/(label+'_anchors.json')),
   '--findings',str(ROOT/'paired_results'/(label+'_findings.json')),'--out',str(out)]
  p=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8',env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
  assert p.returncode==0,p.stderr
  actual=json.loads(out.read_text(encoding='utf-8')); expected=json.loads((ROOT/'paired_results'/(label+'_score.json')).read_text(encoding='utf-8'))
  actual.pop('truth_file',None); expected.pop('truth_file',None)
  assert actual==expected,label
print(json.dumps({'status':'passed','files':len(manifest['files']),'sample_pairs':15,'replayed_scores':2},ensure_ascii=False))
