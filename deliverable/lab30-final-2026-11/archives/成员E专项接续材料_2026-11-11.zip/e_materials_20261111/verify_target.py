"""Compare scanned container source files with the frozen Lab30 source ZIP."""
import hashlib,json,subprocess,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
archive=ROOT/'baseline_full.zip'
paths=['app/public/catalog/greeting.php','app/public/catalog/index.php','app/public/auth/register.php','app/public/auth/login.php']
rows=[]
with zipfile.ZipFile(archive) as z:
 for name in paths:
  expected=z.read('lab30-shop/'+name)
  actual=subprocess.run(['docker','exec','courseevidence1111-lab30-1','cat','/var/www/shop/'+name.removeprefix('app/')],capture_output=True,check=True).stdout
  h=lambda x:hashlib.sha256(x).hexdigest()
  rows.append({'path':name,'archive_sha256':h(expected),'container_sha256':h(actual),'match':actual==expected})
(ROOT/'zap'/'target_identity.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'files':len(rows),'all_match':all(x['match'] for x in rows)}))
