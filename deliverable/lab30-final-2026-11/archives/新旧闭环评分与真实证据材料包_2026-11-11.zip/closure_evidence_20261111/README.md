# 新旧闭环评分与真实证据材料包

本包是材料归档，未撰写或替换最终报告。旧定稿保留为对照，新闭环作为框架迭代后的接续、复核与人工补证结果。

| 批次 | 结论数 | TP | D | U | FP | FN | Precision | Recall | F1 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| old | 23 | 22 | 0 | 1 | 1 | 8 | 95.6522% | 73.3333% | 0.8302 |
| new | 31 | 29 | 0 | 2 | 2 | 1 | 93.5484% | 96.6667% | 0.9508 |

旧run：`2969bcf204cd43b5baf2683cbb0e841d`；新run：`3b50dbaf45955d989aacf47162e47967`。

- [11张真实截图及时间/URL/哈希](screens/INDEX.md)：新闭环8张、旧定稿3张，原图与AX文本成对保存。
- [30项真值对照](scores/truth_comparison.md)、[U/FN审查说明](scores/unmatched_review.md)、[定级质量](scores/rating_quality.md)。
- [逐条冻结处置台账](review/frozen_disposition_ledger.json)及[重复处置依据](review/duplicate_dispositions.md)。
- `evidence/old/`、`evidence/new/`：冻结导出、终审、原始作业请求/响应及验证记录；为字段脱敏衍生件。
- `evidence/iteration/`：恢复、方向合同、人工取证与人工POC记录，以及6份既有回归日志。回归日志是从磁盘收集，采集期间没有重跑这些测试。
- [来源链及配置](provenance/ancestry_index.md)：7条接续记录；`run_configuration_ancestry.json`和`old_run_configuration.json`保存目标、Prompt及策略配置。
- `inputs/`：同身份Lab30源码ZIP、30项真值、43评分锚点及新旧评分输入。SHA核对见`provenance/input_identity.json`。
- `replay/`：原评分实现及stdlib依赖；[实际WSL复算命令和退出码](scores/execution.json)。
- [对照计划书后的缺口](计划书核对与剩余材料.md)：区分已取得、仍需补证、后续报告整合及取消项。

在本目录执行：

```text
python verify_and_replay.py
```

该命令先核对manifest列出的文件，再在临时目录离线重算新旧两份评分，比较全部明细（仅忽略平台绝对truth_file路径）。不调用模型、runner或数据库。结果见`validation/package_verification.json`。manifest不包含自身、验证运行输出、Python缓存；ZIP另有SHA-256旁文件。

解释限制：

1. 新结果含继承验证和operator人工取证/3条历史人工验证记录；界面队列显示复用24、本轮复测7。不能宣称31项均为本轮新生成或完全无人参与。
2. 新旧使用同一源码/真值/锚点/评分协议，但目标、框架、预算和恢复过程不同，且新闭环仅1例；可描述迭代后观测结果，不证明单一改动的因果收益或统计显著性。
3. 动态31/31为冻结的兼容验证/复核口径；poc_agent的28 verified+12 inconclusive与operator的3 verified是历史记录数，不是43个独立漏洞。页面把人工记录列为历史人工记录，且某处统称31条自动验证，两者不能消除来源区别；冻结JSON保留source。
4. 新冻结第一方覆盖61/61、方向78/78；当前页面整包读取63/69另列。旧冻结读取59/61、复核61、动态22/23。分母及时间点不可混用。
5. `61e30cd…`是采集时干净工作区版本；运行跨多次修复，不能将其写为整个新实验的唯一执行版本。每次历史版本仍按各补丁/原始记录说明。
6. 截图时间是2026-11-11北京时间，页面中的原始运行/验证时间按原记录保留。截图是当前前端恢复历史事实，不是采集时重跑。
7. P11独立复位重复试验尚未完成。既有三轮只读搜索和正常/写入/攻击三步都不能替代2–3次独立复位试验。
8. 完整数据库、模型连接密钥未打包；原始未脱敏导出仅保留SHA。源代码内的靶场测试账号、模拟数据及POC唯一标记不是第三方生产凭据；本包未对外上传。
9. 平台终审已完成，但界面仍提示修复后复测步骤/回归条件缺失，见S-N08。审计闭环不能替代计划书所有材料验收。
