"""Read frozen local records, export redacted evidence and replay both scores."""
import collections
import datetime as dt
import hashlib
import json
import platform
from pathlib import Path
import re
import shutil
import sqlite3
import subprocess
import sys

SOURCE = Path('/home/luchitong/work/vuln-audit')
OUT = Path(__file__).resolve().parent
NEW = '3b50dbaf45955d989aacf47162e47967'
OLD = '2969bcf204cd43b5baf2683cbb0e841d'
TZ = dt.timezone(dt.timedelta(hours=8))
START = dt.datetime.now(TZ).isoformat()
REDACTIONS = collections.Counter()

def digest(data):
    return hashlib.sha256(data).hexdigest()

def dump(path, value):
    p = OUT / path
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def text(path, value):
    p = OUT / path
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(value, encoding='utf-8')

def redact(value, key=''):
    if re.fullmatch(r'(?:authorization|proxy.authorization|cookie|set.cookie|password|passwd|api.key|access.token|refresh.token|auth.token|capability.token|session.id|secret|bearer.token|csrf.token|encrypted.*)', key, re.I):
        if value:
            REDACTIONS[key] += 1
            return '[REDACTED]'
    if isinstance(value, dict):
        return {k: redact(v, k) for k, v in value.items()}
    if isinstance(value, list):
        return [redact(v) for v in value]
    if isinstance(value, str):
        value, n = re.subn(r'(?im)^(\s*(?:Cookie|Set-Cookie|Authorization|Proxy-Authorization)\s*:\s*)[^\n]+', r'\1[REDACTED]', value)
        REDACTIONS['header_lines'] += n
        value, n = re.subn(r'(?i)(\b(?:PHPSESSID|sessionid|csrftoken|csrf_token)=)[^\s;"&<>]+', r'\1[REDACTED]', value)
        REDACTIONS['session_values'] += n
        value, n = re.subn(r'\bsk-[A-Za-z0-9_-]{16,}', '[REDACTED_API_KEY]', value)
        REDACTIONS['api_key_patterns'] += n
        value, n = re.subn(r'(?i)(\bBearer\s+)[A-Za-z0-9._~+/-]{12,}', r'\1[REDACTED]', value)
        REDACTIONS['bearer_patterns'] += n
        return value
    return value

def git(*args):
    return subprocess.check_output(['git', *args], cwd=SOURCE)

def copy(src, target):
    p = OUT / target
    p.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(SOURCE / src, p)

head_start = git('rev-parse', 'HEAD').decode().strip()
db = sqlite3.connect(f'file:{SOURCE / "data/audit.db"}?mode=ro', uri=True)
db.row_factory = sqlite3.Row
db.execute('BEGIN')

def frozen(rid):
    row = db.execute('select * from frozen_run_reports where run_id=?', (rid,)).fetchone()
    if not row:
        raise RuntimeError(f'No frozen report: {rid}')
    return dict(row), json.loads(row['json_export'])

new_row, new = frozen(NEW)
old_row, old = frozen(OLD)
raw_fingerprints = {}
run_keys = ('id', 'snapshot_id', 'snapshot_name', 'status', 'created_at', 'started_at', 'finished_at',
            'model', 'budgets', 'run_limits', 'usage', 'worker_strategy', 'prompt_id', 'prompt_label',
            'scope_mode', 'task_spec', 'poc_policy', 'agent_policy', 'execution_summary', 'final_summary')

for label, rid, row, report in [('new', NEW, new_row, new), ('old', OLD, old_row, old)]:
    raw_fingerprints[label] = {'run_id': rid, 'db_frozen_input_hash': row.get('input_hash'),
        'raw_json_export_sha256': digest(row['json_export'].encode()),
        'raw_markdown_sha256': digest((row.get('markdown') or '').encode()),
        'frozen_at': row['created_at'], 'raw_export_not_in_package': True}
    dump(f'evidence/{label}/frozen_report.redacted.json', redact(report))
    text(f'evidence/{label}/frozen_report.redacted.md', redact(row.get('markdown') or report.get('report_markdown', '')))
    dump(f'evidence/{label}/final_review.redacted.json', redact(report.get('final_review', {})))
    dump(f'evidence/{label}/run_metadata.json', redact({k:report['run'].get(k) for k in run_keys}))
    dump(f'evidence/{label}/snapshot.json', report.get('snapshot', {}))
    dump(f'evidence/{label}/verification_jobs.redacted.json', redact(report.get('verification_jobs', [])))
    counts = collections.Counter()
    verifications = []
    for f in report.get('findings', []):
        for v in f.get('verifications', []):
            counts[(str(v.get('source')), str(v.get('status')), str(v.get('verdict')))] += 1
            verifications.append({'finding_id': f['id'], 'title': f.get('title'), 'record': v})
    dump(f'evidence/{label}/verification_records.redacted.json', redact(verifications))
    dump(f'evidence/{label}/verification_record_counts.json', [
        {'source':k[0], 'status':k[1], 'verdict':k[2], 'records':v} for k,v in counts.items()])

# Score only the final accepted, active vulnerability records. Keep the IDs and exact coordinates.
keep = ('id', 'finding_kind', 'category', 'title', 'summary', 'disposition', 'vulnerability_type',
        'primary_location', 'evidence', 'cvss', 'severity', 'legacy_severity')
accepted = [f for f in new['findings'] if f.get('disposition', 'open') not in ('duplicate','retracted','superseded')
            and (f.get('final_review_decision') or {}).get('decision') == 'accept']
assert len(accepted) == new['final_review']['counts']['accepted'] == 31
dump('inputs/new/findings.json', [{k:f.get(k) for k in keep} for f in accepted])
dump('inputs/new/selection.json', {'run_id':NEW, 'raw_records':len(new['findings']),
    'accepted_records':len(accepted), 'excluded':[{'id':f['id'],'disposition':f.get('disposition')}
        for f in new['findings'] if f not in accepted],
    'source':'frozen_run_reports.json_export', 'fields':keep})
copy('deliverable/lab30-closure-2026-10-30/findings.json', 'inputs/old/findings.json')
copy('deliverable/lab30-closure-2026-10-30/reproduction-manifest.json', 'evidence/old/original_reproduction_manifest.json')
copy('deliverable/lab30-closure-2026-10-30/scoring-result.json', 'evidence/old/original_scoring_result.json')

source_zip = 'llm-vuln-audit-feat-lab30-shop/llm-vuln-audit-feat-lab30-shop/lab30-shop-1.0.0-source.zip'
copy(source_zip, 'inputs/dataset/lab30-shop-1.0.0-source.zip')
copy('datasets/lab30-shop/ground_truth.json', 'inputs/dataset/ground_truth.json')
copy('datasets/lab30-shop/scoring_anchors_v2.json', 'inputs/dataset/scoring_anchors_v2.json')
zip_hash = digest((OUT / 'inputs/dataset/lab30-shop-1.0.0-source.zip').read_bytes())
original_manifest = json.loads((OUT/'evidence/old/original_reproduction_manifest.json').read_text())
identity = {'source_zip_sha256':zip_hash,
    'new_frozen_archive_sha256':new['snapshot']['archive_sha256'],
    'old_original_archive_sha256':original_manifest['files'][source_zip],
    'new_snapshot_id':new['snapshot']['id'], 'old_snapshot_id':old['snapshot']['id'],
    'truth_sha256':digest((OUT/'inputs/dataset/ground_truth.json').read_bytes()),
    'anchors_sha256':digest((OUT/'inputs/dataset/scoring_anchors_v2.json').read_bytes())}
identity['source_zip_matches'] = zip_hash == identity['new_frozen_archive_sha256'] == identity['old_original_archive_sha256']
identity['truth_matches_old_manifest'] = identity['truth_sha256'] == original_manifest['files']['datasets/lab30-shop/ground_truth.json']
identity['anchors_match_old_manifest'] = identity['anchors_sha256'] == original_manifest['files']['datasets/lab30-shop/scoring_anchors_v2.json']
assert all(identity[k] for k in ('source_zip_matches','truth_matches_old_manifest','anchors_match_old_manifest'))
dump('provenance/input_identity.json', identity)

# Self-contained original scoring implementation, with its real dependencies.
score_files = ['scripts/score_dataset.py','scripts/cvss31.py','scripts/verify_lab30_dataset.py',
               'backend/audit/__init__.py','backend/audit/prompt_evaluation.py',
               'backend/audit/cvss31.py','backend/audit/worker_strategies.py']
for name in score_files:
    copy(name, 'replay/' + name)
copy('datasets/lab30-shop/SCORING_V2.md', 'replay/SCORING_V2.md')

versions = {'collected_head':head_start, 'worktree_status':git('status','--porcelain').decode(),
    'interpretation':'Collection-time code identity, not a claim that this commit was used throughout the multi-day resumed run.',
    'audit_files':{str(p.relative_to(SOURCE)):digest(p.read_bytes()) for p in sorted((SOURCE/'backend/audit').rglob('*.py'))},
    'scoring_files':{p:digest((SOURCE/p).read_bytes()) for p in score_files},
    'recent_commits':git('log','-12','--format=%H %aI %s').decode().splitlines()}
dump('provenance/code_versions.json', versions)
text('provenance/audit_worktree.patch', git('diff','--','backend/audit').decode())

# Preserve the complete parent chain; do not add usages without checking inherited-cost semantics.
lineage = []
rid = NEW
while rid and rid not in {x['run_id'] for x in lineage}:
    try:
        row, r = frozen(rid)
    except RuntimeError:
        break
    continuation = (r.get('final_review',{}).get('provenance',{}).get('continuation') or {})
    lineage.append({'run_id':rid, 'status':r['run'].get('status'), 'model':r['run'].get('model'),
        'usage':r['run'].get('usage'), 'run_limits':r['run'].get('run_limits'),
        'continuation':continuation, 'frozen_input_hash':row['input_hash'],
        'final_counts':r.get('final_review',{}).get('counts')})
    rid = continuation.get('parent_run_id')
dump('provenance/continuation_lineage.json', redact(lineage))

events = db.execute('select id,kind,payload,created_at from events where run_id=? order by id',(NEW,)).fetchall()
kind_counts = collections.Counter(e['kind'] for e in events)
dump('evidence/new/event_kind_counts.json', dict(sorted(kind_counts.items())))
selected = []
for e in events:
    kind = e['kind']
    if any(s in kind for s in ('operator','checkpoint','budget','resume','paused','run_completed','run_created','continuation','claim_released')):
        selected.append({'event_id':e['id'],'kind':kind,'created_at':e['created_at'],'payload':json.loads(e['payload'])})
dump('evidence/new/resume_operator_budget_events.redacted.json', redact(selected))

docs = ['docs/existing-record-closure-2026-11-11.md', 'docs/recent-final-review-and-retest-repair.md',
        'docs/comprehensive-source-context-repair-2026-11-11.md',
        'docs/incremental-review-and-budget-checkpoints-2026-11-10.md',
        'docs/worker-finding-reuse-and-dedup.md']
docs += [str(p.relative_to(SOURCE)) for p in (SOURCE/'docs/validation').glob('*2026-11-11.json')]
for name in docs:
    p = SOURCE / name
    if p.exists():
        if p.suffix == '.json':
            dump('evidence/iteration/' + p.name, redact(json.loads(p.read_text())))
        else:
            text('evidence/iteration/' + p.name, redact(p.read_text()))

db.commit()
db.close()
dump('provenance/raw_fingerprints.json', raw_fingerprints)
dump('provenance/redaction_counts.json', {k:v for k,v in REDACTIONS.items() if v})
end_head = git('rev-parse','HEAD').decode().strip()
assert end_head == head_start, 'Source HEAD changed while collecting'
dump('provenance/collection.json', {'started_at':START,'finished_at':dt.datetime.now(TZ).isoformat(),
    'method':'SQLite URI mode=ro, one read transaction; copied frozen exports, no model requests or runner jobs',
    'source_root':str(SOURCE),'collection_commit':head_start,'python':sys.version,'platform':platform.platform(),
    'new_run':NEW,'old_run':OLD,'database_copied':False,'model_requests':0,'runner_jobs':0,
    'full_exports':'Redacted derivatives; raw DB JSON/Markdown SHA-256 preserved separately',
    'timestamps':'Run timestamps retain their original UTC zone; collection time is Asia/Shanghai',
    'screenshot_status':'pending browser capture'})

commands = []
for label in ('old','new'):
    cmd = [sys.executable, str(OUT/'replay/scripts/score_dataset.py'),'--protocol','lab30-v2',
           '--truth',str(OUT/'inputs/dataset/ground_truth.json'),'--anchors',str(OUT/'inputs/dataset/scoring_anchors_v2.json'),
           '--findings',str(OUT/f'inputs/{label}/findings.json'),'--check-cvss','--check-severity',
           '--out',str(OUT/f'scores/{label}.json')]
    (OUT/'scores').mkdir(exist_ok=True)
    result = subprocess.run(cmd,capture_output=True,text=True,cwd=OUT)
    text(f'scores/{label}_console.txt', result.stdout + result.stderr)
    commands.append({'label':label,'argv':cmd,'exit_code':result.returncode})
    assert result.returncode == 0, result.stderr
dump('scores/execution.json', commands)
scores = {label:json.loads((OUT/f'scores/{label}.json').read_text()) for label in ('old','new')}
expected = {'old':{'TP':22,'D':0,'U':1,'FP':1,'FN':8},'new':{'TP':29,'D':0,'U':2,'FP':2,'FN':1}}
for label, exp in expected.items():
    assert all(scores[label][k] == v for k,v in exp.items()), label
dump('scores/comparison.json', {label:{k:scores[label].get(k) for k in ('protocol','truths','findings','TP','D','U','FP','FN','precision','recall','f1')} for label in scores})
print(json.dumps({'output':str(OUT),'identity':identity,'scores':{k:{m:scores[k][m] for m in ('TP','FP','FN','precision','recall','f1')} for k in scores},'lineage_runs':len(lineage)},ensure_ascii=False))
