"""Read-only run ancestry/configuration and existing regression logs; run in WSL."""
import datetime as dt
import hashlib
import json
from pathlib import Path
import re
import sqlite3

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/home/luchitong/work/vuln-audit')
NEW = '3b50dbaf45955d989aacf47162e47967'
OLD = '2969bcf204cd43b5baf2683cbb0e841d'
started = dt.datetime.now(dt.timezone.utc).isoformat()

def save(name, value):
    p = ROOT/name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

db = sqlite3.connect(f'file:{SOURCE/"data/audit.db"}?mode=ro', uri=True)
db.row_factory = sqlite3.Row
db.execute('BEGIN')
cols = 'id,snapshot_id,status,model,created_at,started_at,finished_at,prompt_id,prompt_label,prompt_text,budgets,agent_policy,task_spec,poc_policy,worker_strategy'
seen = set()
records = []
rid = NEW
while rid and rid not in seen:
    seen.add(rid)
    row = db.execute('select '+cols+' from runs where id=?', (rid,)).fetchone()
    if not row:
        records.append({'id': rid, 'missing_run_row': True})
        break
    data = dict(row)
    for k in ('budgets','agent_policy','task_spec','poc_policy','worker_strategy'):
        try:
            data[k] = json.loads(data[k]) if isinstance(data[k],str) else data[k]
        except (ValueError,TypeError):
            pass
    data['frozen_report_available'] = bool(db.execute('select 1 from frozen_run_reports where run_id=?',(rid,)).fetchone())
    records.append(data)
    continuation = (data.get('task_spec') or {}).get('continuation') or {}
    rid = continuation.get('parent_run_id')
save('provenance/run_configuration_ancestry.json', records)
old = dict(db.execute('select '+cols+' from runs where id=?',(OLD,)).fetchone())
for k in ('budgets','agent_policy','task_spec','poc_policy','worker_strategy'):
    try:
        old[k] = json.loads(old[k]) if isinstance(old[k],str) else old[k]
    except (ValueError,TypeError):
        pass
save('provenance/old_run_configuration.json', old)
db.commit()
db.close()

logs = []
for name in ('closure-final-handoff.log','closure-direction-contract-tests.log',
             'closure-evidence-final-tests.log','closure-operator-final-tests.log',
             'closure-handoff-tests.log','closure-completion-final-tests.log'):
    source = SOURCE/'.run'/name
    if not source.is_file():
        logs.append({'file':name,'available':False})
        continue
    raw = source.read_bytes()
    text = raw.decode('utf-8',errors='replace')
    text = re.sub(r'(?im)^(\s*(?:Cookie|Set-Cookie|Authorization)\s*:\s*)[^\n]+',r'\1[REDACTED]',text)
    text = re.sub(r'\bsk-[A-Za-z0-9_-]{16,}','[REDACTED_API_KEY]',text)
    dest = ROOT/'evidence/iteration/test_logs'/name
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text(text,encoding='utf-8')
    logs.append({'file':str(dest.relative_to(ROOT)),'available':True,
                 'source_path':str(source),'source_sha256':hashlib.sha256(raw).hexdigest(),
                 'source_mtime_utc':dt.datetime.fromtimestamp(source.stat().st_mtime,dt.timezone.utc).isoformat(),
                 'collected_existing_log':True,'rerun_during_collection':False})
save('provenance/supplement_collection.json',{'started_at':started,
    'finished_at':dt.datetime.now(dt.timezone.utc).isoformat(),
    'method':'Read-only SQLite transaction, whitelisted fields, existing log files',
    'ancestry_records':len(records),'missing_frozen_reports':[x['id'] for x in records if not x.get('frozen_report_available')],
    'model_requests':0,'runner_jobs':0,'logs':logs})
print(json.dumps({'ancestry_records':len(records),'logs':len(logs),'model_requests':0,'runner_jobs':0}))
