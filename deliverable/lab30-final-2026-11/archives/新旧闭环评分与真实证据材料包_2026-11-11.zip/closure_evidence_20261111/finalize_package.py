"""Build material indexes, deterministic comparison tables and a file manifest."""
import collections
import datetime as dt
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
TZ = dt.timezone(dt.timedelta(hours=8))

def read(name):
    return json.loads((ROOT/name).read_text(encoding='utf-8'))

def write(name,text):
    p = ROOT/name
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(text,encoding='utf-8')

def dump(name,value):
    write(name,json.dumps(value,ensure_ascii=False,indent=2)+'\n')

def cell(value):
    return str('' if value is None else value).replace('|','\\|').replace('\n',' ')

def table(headers,rows):
    return '| '+' | '.join(headers)+' |\n| '+' | '.join(['---']*len(headers))+' |\n'+''.join('| '+' | '.join(cell(x) for x in row)+' |\n' for row in rows)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    captures = read('screens/capture_manifest.json')
    for capture in captures:
        assert sha(ROOT/capture['file']) == capture['sha256'],capture['file']
        assert (ROOT/capture['accessibility']).is_file()
    screens = ['# 新旧闭环真实截图索引\n\n',
       '采自本机实际 Chrome 页面，JPEG 视口原图，未绘制、拼接或修改像素。配套 AX 文本记录完整页面的可访问内容，包含视口以外内容；不能据此声称所有文字都出现在图片内。\n\n',
       '截图反映历史记录在当前前端的恢复展示，并非在采集时重新执行模型或 POC。运行时间与截图时间分开保留。UTC 原始时间在下表换算为北京时间。\n\n']
    for cap in captures:
        moment = dt.datetime.fromisoformat(cap['captured_at'].replace('Z','+00:00')).astimezone(TZ).isoformat()
        filename = Path(cap['file']).name
        screens.append(f'## {filename}\n\n{cap["caption"]}\n\n- run：`{cap["run_id"]}`\n- URL：{cap["url"]}\n- 北京时间：{moment}\n- SHA-256：`{cap["sha256"]}`\n- [页面可访问文本]({Path(cap["accessibility"]).name})\n\n![{filename}]({filename})\n\n')
    write('screens/INDEX.md',''.join(screens))

    scores = {label:read(f'scores/{label}.json') for label in ('old','new')}
    old = {x['truth_id']:x for x in scores['old']['truth_results']}
    new = {x['truth_id']:x for x in scores['new']['truth_results']}
    truth_rows = []
    for tid,n in new.items():
        o = old[tid]
        change = '保持命中' if o['detected'] and n['detected'] else '新增匹配' if n['detected'] else '本轮未匹配' if o['detected'] else '均未匹配'
        loc = '；'.join(f'{x["path"]}:{x["line"]}' for x in n['scoring_locations'])
        truth_rows.append([tid,n['title'],n['class'],loc,'TP' if o['detected'] else 'FN','TP' if n['detected'] else 'FN',change,n.get('finding_id') or ''])
    write('scores/truth_comparison.md','# 30项真值逐项对照\n\n来源：同包内 old.json / new.json，SCORING_V2 同一源码、真值及锚点。新增匹配是两次结果间的描述，不证明由某一框架改动单独造成。\n\n'+table(['真值','标题','类型','锚点','旧定稿','新闭环','变化','新finding ID'],truth_rows))
    unmatched = '# 未匹配断言与剩余漏报\n\nFP=D+U 是协议计数；U 不等于已证明为假，不据此修改真值。以下是材料审查说明，未经另行人工签署裁决。\n\n'
    for label in ('old','new'):
        s = scores[label]
        unmatched += f'## {label}\n\n'+table(['finding ID','标题','类型','主定位'],[[f['id'],f['title'],f['vulnerability_type'],f"{f['primary_location']['path']}:{f['primary_location']['line']}"] for f in s['unmatched']])+'\n'
        unmatched += '未命中真值：'+', '.join(x['truth_id'] for x in s['truth_results'] if not x['detected'])+'。\n\n'
    unmatched += '新闭环 #06 RFI 未匹配：同一 template-preview.php:3 位置存在 LFI 结论，但分类为 lfi；评分要求 rfi 类型与精确锚点共同满足。属于协议分类不匹配，不能只写成完全没有发现该位置。\n\n注册入口 CSRF 断言位于官方真值集以外。冻结终审限定为无令牌建号；是否构成对受害者有实际影响的跨站攻击仍需严格浏览器场景验证，不能用服务端接受无 token POST 单独证明完整跨站利用。\n\n旧8项FN在新闭环均形成匹配，但新闭环未匹配旧已命中的#06，因此TP净增7；不能写成净增8。旧轮漏报的具体发生原因仍需逐条核读旧Worker轨迹，类型归纳只是待证假设。\n'
    write('scores/unmatched_review.md',unmatched)

    rows = []
    for label in ('old','new'):
        s=scores[label]; sev=s['severity_evaluation']; cv=s['cvss_evaluation']
        rows.append([label,f"{sev['correct']}/{sev['compared']}",f"{sev['accuracy']:.2%}",cv['compared'],cv['missing_reported'],f"{cv['score_mae']:.4f}",f"{cv['score_accuracy']:.2%}",f"{cv['vector_accuracy']:.2%}"])
    write('scores/rating_quality.md','# 定级质量补充\n\n来源：评分器 --check-severity --check-cvss 的实际输出。检出率提高不等于定级准确性提高，各分母单列。\n\n'+table(['批次','严重性正确/比较','严重性准确率','CVSS比较项','缺报告CVSS','分值MAE','分值准确率','向量准确率'],rows)+'\n新闭环仍存在CVSS与真值差异及3项缺评分，报告中应保留这项局限。逐项明细见各score的matches/rating字段。\n')

    ledger=[]
    for label in ('old','new'):
        report=read(f'evidence/{label}/frozen_report.redacted.json')
        for f in report['findings']:
            decision=f.get('final_review_decision') or {}
            ledger.append({'batch':label,'finding_id':f['id'],'title':f.get('title'),
                'primary_location':f.get('primary_location'),'disposition':f.get('disposition'),
                'disposition_reason':f.get('disposition_reason'),
                'final_decision':decision.get('decision'),'final_rationale':decision.get('rationale'),
                'review_source':decision.get('source'),'inherited_from_run_id':decision.get('inherited_from_run_id')})
    dump('review/frozen_disposition_ledger.json',ledger)
    duplicate_rows=[[x['batch'],x['finding_id'],x['title'],x['disposition'],x['disposition_reason']] for x in ledger if x['disposition'] in ('duplicate','retracted','superseded')]
    write('review/duplicate_dispositions.md','# 冻结候选处置台账\n\nJSON逐条保留全部候选的终态及理由，以下列出撤回/重复项。新闭环34→31、旧定稿30→23可追溯。\n\n'+table(['批次','finding ID','标题','处置','原记录理由'],duplicate_rows)+'\n这是最终冻结时点的台账。不能将这些已修订的字段直接还原为终审前原始版本。本包未新增一份历史处理前评分，P14 的同集合历史前后 Precision 对比仍待补证。\n')

    ancestry=read('provenance/run_configuration_ancestry.json')
    write('provenance/ancestry_index.md','# 接续来源与配置\n\n从runs表只读导出7条实际接续记录，含当时保存的目标、Prompt、策略与预算；不含model_profile连接密钥。三条现存冻结导出的用量另见continuation_lineage.json，其余记录不伪造冻结报告。\n\n'+table(['run ID','parent','root','模式','冻结报告可得'],[[x['id'],(x.get('task_spec') or {}).get('continuation',{}).get('parent_run_id'),(x.get('task_spec') or {}).get('continuation',{}).get('root_run_id'),(x.get('task_spec') or {}).get('continuation',{}).get('mode'),x.get('frozen_report_available')] for x in ancestry])+'\n原始成本存在继承与累计层级，不能将父子usage直接相加作为总费用。未获取完整逐次计费账单，也未为整段跨日运行证明唯一代码commit。\n')

    collection=read('provenance/collection.json')
    collection['screenshot_status']='captured and indexed'
    collection['screenshot_count']=len(captures)
    collection['screenshot_manifest']='screens/capture_manifest.json'
    collection['package_finalized_at']=dt.datetime.now(TZ).isoformat()
    dump('provenance/collection.json',collection)
    summary=read('scores/comparison.json')
    metric_rows=[]
    for label,s in summary.items():
        metric_rows.append([label,s['findings'],s['TP'],s['D'],s['U'],s['FP'],s['FN'],f"{s['precision']:.4%}",f"{s['recall']:.4%}",f"{s['f1']:.4f}"])
    readme='# 新旧闭环评分与真实证据材料包\n\n本包是材料归档，未撰写或替换最终报告。旧定稿保留为对照，新闭环作为框架迭代后的接续、复核与人工补证结果。\n\n'
    readme+=table(['批次','结论数','TP','D','U','FP','FN','Precision','Recall','F1'],metric_rows)
    readme+='''
旧run：`2969bcf204cd43b5baf2683cbb0e841d`；新run：`3b50dbaf45955d989aacf47162e47967`。

- [11张真实截图及时间/URL/哈希](screens/INDEX.md)：新闭环8张、旧定稿3张，原图与AX文本成对保存。
- [30项真值对照](scores/truth_comparison.md)、[U/FN审查说明](scores/unmatched_review.md)、[定级质量](scores/rating_quality.md)。
- [逐条冻结处置台账](review/frozen_disposition_ledger.json)及[重复处置依据](review/duplicate_dispositions.md)。
- `evidence/old/`、`evidence/new/`：冻结导出、终审、原始作业请求/响应及验证记录；为字段脱敏衍生件。
- `evidence/iteration/`：恢复、方向合同、人工取证与人工POC记录，以及6份既有回归日志。回归日志是从磁盘收集，采集期间没有重跑这些测试。
- [来源链及配置](provenance/ancestry_index.md)：7条接续记录；`run_configuration_ancestry.json`和`old_run_configuration.json`保存目标、Prompt及策略配置。
- `inputs/`：同身份Lab30源码ZIP、30项真值、43评分锚点及新旧评分输入。SHA核对见`provenance/input_identity.json`。
- `replay/`：原评分实现及stdlib依赖；[实际WSL复算命令和退出码](scores/execution.json)。
- [对照计划书后的缺口](计划书核对与剩余材料.md)：区分已取得、仍需补证、后续报告整合及取消项。

在本目录执行：

```text
python verify_and_replay.py
```

该命令先核对manifest列出的文件，再在临时目录离线重算新旧两份评分，比较全部明细（仅忽略平台绝对truth_file路径）。不调用模型、runner或数据库。结果见`validation/package_verification.json`。manifest不包含自身、验证运行输出、Python缓存；ZIP另有SHA-256旁文件。

解释限制：

1. 新结果含继承验证和operator人工取证/3条历史人工验证记录；界面队列显示复用24、本轮复测7。不能宣称31项均为本轮新生成或完全无人参与。
2. 新旧使用同一源码/真值/锚点/评分协议，但目标、框架、预算和恢复过程不同，且新闭环仅1例；可描述迭代后观测结果，不证明单一改动的因果收益或统计显著性。
3. 动态31/31为冻结的兼容验证/复核口径；poc_agent的28 verified+12 inconclusive与operator的3 verified是历史记录数，不是43个独立漏洞。页面把人工记录列为历史人工记录，且某处统称31条自动验证，两者不能消除来源区别；冻结JSON保留source。
4. 新冻结第一方覆盖61/61、方向78/78；当前页面整包读取63/69另列。旧冻结读取59/61、复核61、动态22/23。分母及时间点不可混用。
5. `61e30cd…`是采集时干净工作区版本；运行跨多次修复，不能将其写为整个新实验的唯一执行版本。每次历史版本仍按各补丁/原始记录说明。
6. 截图时间是2026-11-11北京时间，页面中的原始运行/验证时间按原记录保留。截图是当前前端恢复历史事实，不是采集时重跑。
7. P11独立复位重复试验尚未完成。既有三轮只读搜索和正常/写入/攻击三步都不能替代2–3次独立复位试验。
8. 完整数据库、模型连接密钥未打包；原始未脱敏导出仅保留SHA。源代码内的靶场测试账号、模拟数据及POC唯一标记不是第三方生产凭据；本包未对外上传。
9. 平台终审已完成，但界面仍提示修复后复测步骤/回归条件缺失，见S-N08。审计闭环不能替代计划书所有材料验收。
'''
    write('README.md',readme)

    excluded={'manifest.json','validation/package_verification.json','validation/package_verification.stderr.txt'}
    files={}
    for p in sorted(ROOT.rglob('*')):
        if not p.is_file() or '__pycache__' in p.parts or p.suffix=='.pyc':
            continue
        name=p.relative_to(ROOT).as_posix()
        if name in excluded:
            continue
        origin='本机只读采集或从项目归档复制'
        if name.startswith('screens/'):
            origin='Chrome实际页面采集；图注/索引由Codex整理'
        elif name.endswith('.md') and name not in ('replay/SCORING_V2.md',) and not name.startswith('evidence/'):
            origin='Codex据归档证据整理；非人工签名结论'
        files[name]={'sha256':sha(p),'bytes':p.stat().st_size,'origin':origin}
    dump('manifest.json',{'schema':'closure-evidence-package/v1','generated_at':dt.datetime.now(TZ).isoformat(),
       'collector':'Codex','authors':'原始材料作者以来源文件为准；未冒填人工复核姓名',
       'collection_commit':collection['collection_commit'],'run_ids':[collection['old_run'],collection['new_run']],
       'commands':['collect_evidence.py (WSL)','collect_supplement.py (WSL)','finalize_package.py','verify_and_replay.py'],
       'excluded':sorted(excluded|{'**/__pycache__/**','**/*.pyc'}),'files':files})
    result=subprocess.run([sys.executable,str(ROOT/'verify_and_replay.py')],cwd=ROOT,capture_output=True,text=True,encoding='utf-8')
    write('validation/package_verification.stderr.txt',result.stderr)
    if result.returncode:
        print(result.stdout)
        raise SystemExit(result.stderr)
    validation=json.loads(result.stdout)
    validation.update({'executed_at':dt.datetime.now(TZ).isoformat(),'python':sys.version,'platform':platform.platform(),'exit_code':result.returncode})
    dump('validation/package_verification.json',validation)
    print(json.dumps(validation,ensure_ascii=False))

if __name__=='__main__':
    main()
