# 接续来源与配置

从runs表只读导出7条实际接续记录，含当时保存的目标、Prompt、策略与预算；不含model_profile连接密钥。三条现存冻结导出的用量另见continuation_lineage.json，其余记录不伪造冻结报告。

| run ID | parent | root | 模式 | 冻结报告可得 |
| --- | --- | --- | --- | --- |
| 3b50dbaf45955d989aacf47162e47967 | 566a1c802c1e5ef19b153cb5529b1446 | 7150ee45e16a49ad935ed62ab194be99 | audit | True |
| 566a1c802c1e5ef19b153cb5529b1446 | 1995ca42dc1959488aadb74da515fbee | 7150ee45e16a49ad935ed62ab194be99 | audit | True |
| 1995ca42dc1959488aadb74da515fbee | eb67cbf8636b54a39cad67fc3753aa03 | 7150ee45e16a49ad935ed62ab194be99 | review | True |
| eb67cbf8636b54a39cad67fc3753aa03 | 8a035cfcda5254238742ea8af118f869 | 7150ee45e16a49ad935ed62ab194be99 | review | False |
| 8a035cfcda5254238742ea8af118f869 | e06a8b4849815d2f894b420e354a6bfd | 7150ee45e16a49ad935ed62ab194be99 | poc_review | False |
| e06a8b4849815d2f894b420e354a6bfd | 7150ee45e16a49ad935ed62ab194be99 | 7150ee45e16a49ad935ed62ab194be99 | audit | True |
| 7150ee45e16a49ad935ed62ab194be99 |  |  |  | True |

原始成本存在继承与累计层级，不能将父子usage直接相加作为总费用。未获取完整逐次计费账单，也未为整段跨日运行证明唯一代码commit。
