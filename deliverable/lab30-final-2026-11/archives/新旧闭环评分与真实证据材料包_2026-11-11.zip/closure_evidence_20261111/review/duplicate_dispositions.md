# 冻结候选处置台账

JSON逐条保留全部候选的终态及理由，以下列出撤回/重复项。新闭环34→31、旧定稿30→23可追溯。

| 批次 | finding ID | 标题 | 处置 | 原记录理由 |
| --- | --- | --- | --- | --- |
| old | 4c55def3684b4d94be50a6917baa4d49 | auth/login.php 接受 sid 参数指定会话 ID，登录后可被会话固定劫持 | duplicate | 本项与 831052489b0b408ba11ecfea365a0948 为同一会话固定缺陷：根因均为 bootstrap.php:13 关闭 session.use_strict_mode 并在 :17 对请求 sid 调 session_id 后 :18 session_start，危险操作均为以客户端提供的会话 ID 完成认证且 login.php:8 未 session_regenerate_id；前提（诱导受害者带 ?sid= 登录、共享 data_dir/sessions）一致，仅主定位分别锚在 bootstrap.php:17 与 login.php:3，属同一链路的入口/公共依赖定位差异，故以 login.php 入口结论为主，本条判重保留记录。 |
| old | 4fa11a9739ea4a898a56a85827677471 | auth/continue.php 的 next 参数直接用于 Location 头导致开放重定向 | duplicate | 与 56c0464441f246508577af40015970db 为同一缺陷：主定位同为 auth/continue.php，危险操作同为 $_GET['next'] 直接拼入 Location 头，前提同为已登录用户触发，无白名单校验；仅 CVSS 评分与证据窗口不同，属同一根因的重复结论，归并到规范主结论，原记录与证据保留。 |
| old | 273559dff3794cb684377c2d37822ec3 | account/update.php 批量赋值：白名单含 role/balance/tier，普通用户可提权 admin 并篡改余额 | duplicate | 同一运行内漏洞类型及主定位相同，危险操作相似度不低于 0.6 且候选唯一的重复表述。 |
| old | dfb15bf1a91744c6b96f71832aab9810 | ops/template-render.php 将模板 {{...}} 表达式直接传入 eval 造成代码执行 | duplicate | 同一运行内漏洞类型及主定位相同，危险操作相似度不低于 0.6 且候选唯一的重复表述。 |
| old | fc3937df4046456fac1432546795d6b2 | ops/template-preview.php 将 GET template 未经白名单直接 include 造成本地文件包含 | duplicate | 同一运行内漏洞类型及主定位相同，危险操作相似度不低于 0.6 且候选唯一的重复表述。 |
| old | 6f33bafffc2d49e991505ebdd782e970 | partner/portal.php 仅解码 JWT payload 不校验签名，任意人构造 role=admin 令牌即可读取全部订单结算数据 | duplicate | 本项与 34c81a273b45416fa25213733163c8c4 是同一缺陷：均为 partner/portal.php 仅解码 JWT payload、不校验 HMAC 签名，以客户端自述 role==='admin' 作为管理员身份断言后 SELECT 全部订单并输出；危险操作（未验签角色的越权读取）与前提（无需登录即可 POST 自造三段令牌）完全一致，区别仅在本项主定位指向第3行授权判定、对方指向第2行输入与传播，属同链路的不同主定位而非不同根因。两条的验证记录 fc919890aba94c8096117e47d92cc231 与 83288ac3d2a4459cadab3af2c227243c 观测一致（正常侧 403，攻击侧自造令牌 200 并返回全部订单金额），不构成独立漏洞。归并到覆盖输入源到输出全链路的主结论，避免同一缺陷重复计分。 |
| old | a77553a6251c4c02b51350b220644d5b | account/redeem.php 用 == 比较 md5 兑换码，0e 型串绕过免费升级金卡 | duplicate | 与 e0cf553e9838411fa31a2455b8d0dd8d 根因、危险操作与前提完全一致：同一 redeem.php:4-5 的 md5 == 弱比较，同一 UPDATE users SET tier='gold'，前提同为已登录并携带 CSRF token；区别仅在取证的证据窗口（:2-7 与 :2-6）与评级状态，属同根因重复，保留已带 CVSS 评级的主结论。 |
| new | cc722324fcae40d7b8c5a259e1314fff | 订单详情仅按请求 id 查询，任意登录用户可读取他人订单 | duplicate | 与 4e35ce72 主定位同为 lab30-shop/app/public/orders/detail.php:2：两者均因 WHERE 仅 o.id=? 未附加 user_id=当前用户，require_user() 只验登录；输入都是 GET id，危险操作都是取出并回显他人订单 order_no/username/total/private_note，前提同为普通登录用户、目标订单存在且无需归属。本项 novelty 自述仅补第 4 行读回证据，未构成独立根因，按同根因归并到 4e35ce72 主结论。 |
| new | ab9dae2a78c747ca9f04f2e5e5540027 | ops/users.php 用客户端 Cookie role 决定管理员判定，普通登录用户可越权读取全部用户 | duplicate | 本项与 9a66a667 指向同一行 users.php:2：以 $_COOKIE['role'] ?? $u['role'] 取角色、仅比较 admin，未调用 require_user(['admin'])；危险操作同为越权执行 SELECT id,username,email,role FROM users 并回显，前提同为持任意登录账号并附 Cookie role=admin，无独立根因。其自述 novelty 也承认复用既有根因、仅补充读取证据。按要求合并到已有动态 verified 的主结论 9a66a667。 |
| new | 735a4817c0174afea654205174aaaa97 | ops/members.php 查询参数 q 经 member_lookup 拼接进 SQL 造成注入 | duplicate | 本项 input（members.php:2 $_GET['q']）、root_cause 与 sink（member_lookup.php:3 拼接进 LIKE 后 db()->query 执行）及前提（operator/admin 会话）与主结论 789679de40ea47fb9537300f9c51eba3 完全一致，其 payload.novelty 亦自述复用同一 member_lookup.php:3 根因。无独立根因、危险操作或利用前提差异，判为同根因重复，归并至主结论保留。 |

这是最终冻结时点的台账。不能将这些已修订的字段直接还原为终审前原始版本。本包未新增一份历史处理前评分，P14 的同集合历史前后 Precision 对比仍待补证。
