# 30项真值逐项对照

来源：同包内 old.json / new.json，SCORING_V2 同一源码、真值及锚点。新增匹配是两次结果间的描述，不证明由某一框架改动单独造成。

| 真值 | 标题 | 类型 | 锚点 | 旧定稿 | 新闭环 | 变化 | 新finding ID |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 01 | 商品搜索 SQL 注入 | sqli | app/public/catalog/index.php:4 | TP | TP | 保持命中 | 1895fbd0583d46348f4a8dbd81236b9b |
| 02 | 到店欢迎反射型 XSS | xss_r | app/public/catalog/greeting.php:3 | TP | TP | 保持命中 | a5707d3ea9bb4b9284ff9f164dbf955d |
| 03 | 网络诊断命令注入 | command_injection | app/public/ops/ping.php:2 | TP | TP | 保持命中 | c02fe17575974cbfa0caf32637b482db |
| 04 | 帮助文档路径遍历读取任意文件 | path_traversal | app/public/support/download.php:3 | TP | TP | 保持命中 | e158b6a09f1e4f84b85fd03e4eb93c48 |
| 05 | 内容中心本地文件包含 | lfi | app/public/content/page.php:3 | TP | TP | 保持命中 | f6a24603a7a941f3a62f5034c1b46b82 |
| 06 | 远程模板预览远程文件包含 | rfi | app/public/ops/template-preview.php:3 | TP | FN | 本轮未匹配 |  |
| 07 | 运营公式动态函数调用代码执行 | code_execution | app/public/ops/formula.php:3 | FN | TP | 新增匹配 | eadd0beed2c0463888586e26fe9ddf33 |
| 08 | 继续访问开放重定向 | open_redirect | app/public/auth/continue.php:3 | TP | TP | 保持命中 | 9ef964fa5f354f918d4924183aadfe11 |
| 09 | 数据库诊断异常与堆栈信息泄露 | info_disclosure | app/public/ops/database.php:3；app/public/ops/database.php:4 | FN | TP | 新增匹配 | 0e88b1f8b3d04a0798676aeccba07cf9 |
| 10 | 使用 MD5 存储密码 | weak_crypto | app/public/auth/register.php:8；app/src/setup.php:17 | FN | TP | 新增匹配 | 0bed78e56e8045e9bffdfb21970489eb |
| 11 | 在线留言存储型 XSS | xss_s | app/public/support/messages.php:5 | TP | TP | 保持命中 | 20f1b555e4b648e8b9622864abb3123c |
| 12 | 链接预览服务端请求伪造 | ssrf | app/public/ops/url-preview.php:3 | TP | TP | 保持命中 | 452d174056004fbfad541168b5c7ae12 |
| 13 | 合作方配置导入 XXE | xxe | app/public/ops/xml-import.php:3 | TP | TP | 保持命中 | 8af981c796814905b9bdd25108e47ddb |
| 14 | 邮箱设置跨站请求伪造 | csrf | app/public/account/settings.php:5 | FN | TP | 新增匹配 | 13160cf2233d456381d1bb93c4cebd70 |
| 15 | 会员备份不安全反序列化权益篡改 | insecure_deserialization | app/public/account/backup.php:5 | TP | TP | 保持命中 | a47fd652debb4f0391fe234a5d91ecd6 |
| 16 | 订单详情越权访问（IDOR） | idor | app/public/orders/detail.php:2 | TP | TP | 保持命中 | 13a0f5bed6414ab0948f6f25117d47f5 |
| 17 | 人员管理信任客户端角色 Cookie 权限绕过 | auth_bypass | app/public/ops/users.php:2 | FN | TP | 新增匹配 | f434cb50f3c5481db935aaf727023338 |
| 18 | 维护接口信任请求头认证绕过 | auth_bypass | app/public/ops/maintenance.php:3 | FN | TP | 新增匹配 | e2cf827251824b459229883c352560e6 |
| 19 | 下单信任客户端单价金额篡改 | price_manipulation | app/public/orders/create.php:3；app/public/orders/create.php:5；app/public/orders/create.php:7 | TP | TP | 保持命中 | 0a1bf6e3f513469fa4f9d3cc9bc8af7c |
| 20 | 提现竞争条件重复支付 | race_condition | app/public/wallet/withdraw.php:4；app/public/wallet/withdraw.php:7；app/public/wallet/withdraw.php:8 | TP | TP | 保持命中 | 61e9d885a7434e17a86e04f517471730 |
| 21 | 会话固定 | session_fixation | app/src/bootstrap.php:13；app/src/bootstrap.php:17；app/public/auth/login.php:3；app/public/auth/login.php:8 | TP | TP | 保持命中 | 8514fe5a09b24a97b2b9200edd85f915 |
| 22 | 会员兑换码弱类型比较绕过 | weak_type_comparison | app/public/account/redeem.php:5 | TP | TP | 保持命中 | 0e67c5ccc77e46d4b7f37847b81b9827 |
| 23 | 会员查询跨文件 SQL 注入 | sqli | app/src/member_lookup.php:3 | FN | TP | 新增匹配 | 6ea737d111da4451a1c0cbab2c63aa92 |
| 24 | 主机巡检跨文件命令注入 | command_injection | app/src/host_check.php:2 | FN | TP | 新增匹配 | 264e0609408a450888c4851f4d477be1 |
| 25 | 个人主页 HTML 属性注入型 XSS | xss_r | app/public/account/profile.php:3 | TP | TP | 保持命中 | 4afcafc91e504ef589de6fb97a6b9693 |
| 26 | 合作方结算 JWT 未校验签名身份伪造 | auth_bypass | app/public/partner/portal.php:2；app/public/partner/portal.php:3 | TP | TP | 保持命中 | 9f5d703b4b6f446ca5a3f2b7b6e61942 |
| 27 | 任务导入反序列化链命令执行 | insecure_deserialization | app/public/ops/jobs.php:3；app/src/dispatch_job.php:4 | TP | TP | 保持命中 | a41fe4397d1647aca813d15585c09820 |
| 28 | 会员报表二次 SQL 注入 | sqli | app/public/ops/report.php:3 | TP | TP | 保持命中 | 6bc2fbecc4be4bf0af206d7c9f717aac |
| 29 | 营销排版模板表达式执行 | code_execution | app/public/ops/template-render.php:3 | TP | TP | 保持命中 | f559f9fc049449178215238868ce4fb4 |
| 30 | 会员资料批量赋值敏感字段修改 | mass_assignment | app/public/account/update.php:4；app/public/account/update.php:5；app/public/account/update.php:6 | TP | TP | 保持命中 | 63ebf68069984b988e79c6e29984e96c |
