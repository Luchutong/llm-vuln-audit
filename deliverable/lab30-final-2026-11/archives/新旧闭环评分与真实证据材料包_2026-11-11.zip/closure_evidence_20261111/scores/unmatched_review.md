# 未匹配断言与剩余漏报

FP=D+U 是协议计数；U 不等于已证明为假，不据此修改真值。以下是材料审查说明，未经另行人工签署裁决。

## old

| finding ID | 标题 | 类型 | 主定位 |
| --- | --- | --- | --- |
| 755caa0a9ce04369bac0bc106f3406d2 | 运营远程模板预览将 GET template 直接 include 造成任意本地文件包含 | lfi | lab30-shop/app/public/ops/template-preview.php:3 |

未命中真值：07, 09, 10, 14, 17, 18, 23, 24。

## new

| finding ID | 标题 | 类型 | 主定位 |
| --- | --- | --- | --- |
| bd815376f74949faa53e29011c3e66ac | 注册入口 POST 状态变更未受 check_csrf 保护，可被跨站强制注册 | csrf | lab30-shop/app/public/auth/register.php:7 |
| 264f7c68e27b4d749e1ecf9b3205317c | 运营模板预览页面将 $_GET['template'] 裸变量传入 include 导致任意本地文件包含（可延伸 RFI） | lfi | lab30-shop/app/public/ops/template-preview.php:3 |

未命中真值：06。

新闭环 #06 RFI 未匹配：同一 template-preview.php:3 位置存在 LFI 结论，但分类为 lfi；评分要求 rfi 类型与精确锚点共同满足。属于协议分类不匹配，不能只写成完全没有发现该位置。

注册入口 CSRF 断言位于官方真值集以外。冻结终审限定为无令牌建号；是否构成对受害者有实际影响的跨站攻击仍需严格浏览器场景验证，不能用服务端接受无 token POST 单独证明完整跨站利用。

旧8项FN在新闭环均形成匹配，但新闭环未匹配旧已命中的#06，因此TP净增7；不能写成净增8。旧轮漏报的具体发生原因仍需逐条核读旧Worker轨迹，类型归纳只是待证假设。
