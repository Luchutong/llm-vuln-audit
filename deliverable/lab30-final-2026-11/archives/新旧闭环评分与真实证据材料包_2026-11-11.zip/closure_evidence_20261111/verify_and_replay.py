"""Verify this evidence package and replay both archived scores (stdlib only)."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent

def main():
    manifest = json.loads((ROOT / 'manifest.json').read_text(encoding='utf-8'))
    for name, expected in manifest['files'].items():
        path = ROOT / name
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != expected['sha256']:
            raise SystemExit('Missing or changed package file: ' + name)
    results = {}
    with tempfile.TemporaryDirectory(prefix='closure-score-replay-') as folder:
        for label in ('old', 'new'):
            dest = Path(folder) / (label + '.json')
            argv = [sys.executable, str(ROOT/'replay/scripts/score_dataset.py'),
                    '--protocol','lab30-v2','--truth',str(ROOT/'inputs/dataset/ground_truth.json'),
                    '--anchors',str(ROOT/'inputs/dataset/scoring_anchors_v2.json'),
                    '--findings',str(ROOT/f'inputs/{label}/findings.json'),
                    '--check-severity','--check-cvss','--out',str(dest)]
            env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
            process = subprocess.run(argv,cwd=ROOT,env=env,capture_output=True,text=True,encoding='utf-8')
            if process.returncode:
                raise SystemExit(process.stderr)
            actual = json.loads(dest.read_text(encoding='utf-8'))
            expected = json.loads((ROOT/f'scores/{label}.json').read_text(encoding='utf-8'))
            # This field stores the platform-dependent absolute path, not score data.
            actual.pop('truth_file',None)
            expected.pop('truth_file',None)
            if actual != expected:
                raise SystemExit('Score details changed: ' + label)
            results[label] = {k:actual[k] for k in ('TP','D','U','FP','FN','precision','recall','f1')}
    print(json.dumps({'status':'passed','verified_files':len(manifest['files']),
        'scores':results,'model_requests':0,'runner_jobs':0,'database_required':False},
        ensure_ascii=False,indent=2))

if __name__ == '__main__':
    main()
