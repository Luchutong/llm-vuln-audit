import datetime as dt,hashlib,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPO=Path('/home/luchitong/work/vuln-audit')
def git(*args): return subprocess.check_output(['git',*args],cwd=REPO)
status=git('status','--porcelain=v1','-z','--untracked-files=all')
names=[]
for item in status.split(b'\0'):
 if item:
  name=item[3:].decode('utf-8',errors='surrogateescape')
  if (REPO/name).is_file(): names.append(name)
patch=git('diff','--binary','HEAD')
(ROOT/'working_tree.patch').write_bytes(patch)
hashes={name:hashlib.sha256((REPO/name).read_bytes()).hexdigest() for name in sorted(names)}
audit={str(p.relative_to(REPO)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((REPO/'backend/audit').rglob('*.py'))}
result={'time':dt.datetime.now(dt.timezone.utc).isoformat(),'head':git('rev-parse','HEAD').decode().strip(),
 'working_tree_patch_sha256':hashlib.sha256(patch).hexdigest(),'changed_files':hashes,'all_audit_py':audit,
 'note':'HEAD plus tracked patch and hashes of changed/untracked files; this is the actual worktree identity at capture, not a commit.'}
(ROOT/'code_identity.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'head':result['head'],'changed_files':len(hashes),'audit_python_files':len(audit),'patch_sha256':result['working_tree_patch_sha256']}))
