import json,datetime as dt,urllib.request
from pathlib import Path
with urllib.request.urlopen('http://127.0.0.1:8899/api/config',timeout=15) as r: data=json.load(r)
allowed=('model','base_url','configured','thinking','selected_profile_id','version','agent_policy','worker')
out={k:data.get(k) for k in allowed}
out['captured_at']=dt.datetime.now(dt.timezone.utc).isoformat()
Path(__file__).with_name('platform_config.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:out[k] for k in ('model','configured','selected_profile_id','version')}))
