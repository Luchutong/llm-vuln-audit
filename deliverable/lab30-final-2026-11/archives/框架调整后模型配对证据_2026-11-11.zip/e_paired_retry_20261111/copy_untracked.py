import json,hashlib,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPO=Path('/home/luchitong/work/vuln-audit')
identity=json.loads((ROOT/'code_identity.json').read_text(encoding='utf-8'))
paths=['backend/audit/audit_report.py','backend/audit/output_policy.py','backend/audit/review_prompt.py',
       'backend/tests/test_minimal_audit_outputs.py','backend/tests/test_review_protocol_simplification.py',
       'docs/audit-protocol-simplification-2026-11-11.md','docs/minimal-audit-output-2026-11-11.md',
       'docs/validation/audit-protocol-simplification-2026-11-11.json','docs/validation/minimal-audit-output-2026-11-11.json']
for name in paths:
 data=(REPO/name).read_bytes(); assert hashlib.sha256(data).hexdigest()==identity['changed_files'][name]
 dest=ROOT/'untracked_source'/name; dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(data)
print('copied verified untracked files:',len(paths))
