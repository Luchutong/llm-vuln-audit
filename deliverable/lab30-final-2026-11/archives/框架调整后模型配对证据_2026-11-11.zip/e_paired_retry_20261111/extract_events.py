import sqlite3,json,datetime as dt
from pathlib import Path
ROOT=Path(__file__).resolve().parent
db=sqlite3.connect('file:/home/luchitong/work/vuln-audit/data/audit.db?mode=ro',uri=True); db.row_factory=sqlite3.Row
runs=json.loads((ROOT/'paired_runs.json').read_text(encoding='utf-8'))['runs']
output=[]
for run in runs:
 rows=db.execute('select id,kind,payload,created_at from events where run_id=? and kind in (?,?,?) order by id',
                 (run['run_id'],'run_inconclusive','run_completed','goal_inconclusive')).fetchall()
 output.append({'label':run['label'],'run_id':run['run_id'],'events':[{'id':r['id'],'kind':r['kind'],'payload':json.loads(r['payload']),'created_at':r['created_at']} for r in rows]})
(ROOT/'paired_results'/'terminal_events.json').write_text(json.dumps({'collected_at':dt.datetime.now(dt.timezone.utc).isoformat(),'runs':output},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(output,ensure_ascii=False))
