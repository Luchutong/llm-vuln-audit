import datetime as dt,hashlib,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPO=Path('/home/luchitong/work/vuln-audit')
original=json.loads((ROOT/'code_identity.json').read_text(encoding='utf-8'))
patch=subprocess.check_output(['git','diff','--binary','HEAD'],cwd=REPO)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO).decode().strip()
current={str(p.relative_to(REPO)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((REPO/'backend/audit').rglob('*.py'))}
changed={name:hashlib.sha256((REPO/name).read_bytes()).hexdigest() if (REPO/name).is_file() else None for name in original['changed_files']}
result={'checked_at':dt.datetime.now(dt.timezone.utc).isoformat(),'head_unchanged':head==original['head'],
 'patch_unchanged':hashlib.sha256(patch).hexdigest()==original['working_tree_patch_sha256'],
 'audit_code_unchanged':current==original['all_audit_py'],'changed_files_unchanged':changed==original['changed_files'],
 'note':'Endpoint hashes do not prove absence of temporary edits between the two checks.'}
(ROOT/'code_verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
