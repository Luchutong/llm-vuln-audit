"""Offline discovery comparisons, fixed-set dedup ablation and ZAP/LLM benchmark mapping."""
import collections,copy,datetime as dt,hashlib,json,os,subprocess,sys,zipfile
from pathlib import Path
from urllib.parse import urlsplit

ROOT=Path(__file__).resolve().parent
PROJECTS=ROOT.parent
PROVENANCE=[]
KEEP=('id','finding_kind','category','title','summary','vulnerability_type','primary_location','evidence','cvss','severity','legacy_severity','disposition')
def load(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def save(name,value):
 p=ROOT/name;p.parent.mkdir(parents=True,exist_ok=True)
 p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def write(name,text):
 p=ROOT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text,encoding='utf-8')
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def origin(path,purpose): PROVENANCE.append({'path':str(path.resolve()),'sha256':sha(path),'purpose':purpose})
def table(headers,rows):
 def c(x):return str('' if x is None else x).replace('|','\\|').replace('\n',' ')
 return '| '+' | '.join(headers)+' |\n| '+' | '.join('---' for _ in headers)+' |\n'+''.join('| '+' | '.join(c(x) for x in r)+' |\n' for r in rows)
def score(label,findings,anchor='baseline'):
 save(f'scores/{label}_input.json',findings)
 cmd=[sys.executable,str(ROOT/'replay/scripts/score_dataset.py'),'--protocol','lab30-v2','--truth',str(ROOT/'inputs/ground_truth.json'),
      '--anchors',str(ROOT/f'inputs/{anchor}_anchors.json'),'--findings',str(ROOT/f'scores/{label}_input.json'),'--out',str(ROOT/f'scores/{label}.json')]
 p=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True,encoding='utf-8',env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
 write(f'scores/{label}.log',p.stdout+p.stderr)
 assert p.returncode==0,p.stderr
 executions.append({'label':label,'argv':cmd,'exit_code':p.returncode})
 return load(ROOT/f'scores/{label}.json')
def metrics(s):return [s[k] if k not in ('precision','recall','f1') else (round(s[k],6) if s[k] is not None else None) for k in ('findings','TP','D','U','FP','FN','precision','recall','f1')]
def check_refs(f,z):
 issues=[]
 if not f.get('title') or not f.get('summary') or not f.get('vulnerability_type'):issues.append('missing title/summary/type')
 refs=f.get('evidence') or []
 if not refs:issues.append('empty evidence')
 for ref in refs:
  path=ref.get('path','');path=path if path.startswith('lab30-shop/') else 'lab30-shop/'+path
  if path not in z.namelist():issues.append('missing source: '+path);continue
  a,b=ref.get('start_line'),ref.get('end_line')
  if not isinstance(a,int) or not isinstance(b,int) or not 1<=a<=b<=len(z.read(path).splitlines()):issues.append('invalid range: '+path)
 return issues

executions=[]
sources={
 'baseline':PROJECTS/'e_supplement_check_20261111/paired_results/baseline_report.redacted.json',
 'injected_parent':PROJECTS/'e_paired_retry_20261111/paired_results/injected_report.redacted.json',
 'injected_supplement':PROJECTS/'e_supplement_check_20261111/paired_results/injected_report.redacted.json'}
reports={}; datasets={}; checks={}; scores={}
for label,path in sources.items():
 origin(path,'Frozen canonical candidate claims; include pending, do not gate on final acceptance or run status')
 report=load(path);reports[label]=report
 archive='baseline' if label=='baseline' else 'injected'
 records=[];audit=[]
 with zipfile.ZipFile(ROOT/f'inputs/{archive}_full.zip') as z:
  for item in report['canonical_findings']:
   claim=copy.deepcopy(item.get('frozen_claim') or {})
   claim['id']=claim.get('finding_id') or item['current_claim_ref']['finding_id']
   issues=check_refs(claim,z)
   negative=item.get('final_disposition') in ('rejected','retracted','superseded','duplicate')
   audit.append({'finding_id':claim['id'],'canonical_id':item['canonical_id'],'title':claim.get('title'),
    'review_attribute':item.get('final_disposition'),'issues':issues,'included':not issues and not negative,
    'primary_location':claim.get('primary_location'),'vulnerability_type':claim.get('vulnerability_type')})
   if issues or negative:continue
   claim['finding_kind']='vulnerability';claim['disposition']='open'
   records.append({k:claim.get(k) for k in KEEP})
 datasets[label]=records;checks[label]=audit;scores[label]=score('discovery_'+label,records,archive)
 save(f'discovery/{label}_candidate_review.json',audit)
 save(f'discovery/{label}_source_claims.json',{'metadata':report['metadata'],'canonical_findings':report['canonical_findings']})

samples=load(ROOT/'inputs/samples_manifest.json')['records']
look={k:{r['truth_id']:r for r in s['truth_results']} for k,s in scores.items()}
sample_rows=[]
for sample in samples:
 tid=sample['truth_id'];row={'sample_id':sample['id'],'category':sample['category'],'truth_id':tid,'source_path':sample['source_path']}
 for label in sources:
  result=look[label][tid]
  related=next((x for x in scores[label]['missed_diagnostics'] if x['truth_id']==tid),None)
  row[label]={'strict_match':result['detected'],'finding_id':result.get('finding_id'),'diagnostic':related,
               'meaning':'精确类型和主定位匹配' if result['detected'] else '未精确匹配；结合相关候选区分类型/定位差异与未见候选'}
 sample_rows.append(row)
eligible=[x for x in sample_rows if x['baseline']['strict_match']]
retention={k:{'numerator':sum(x[k]['strict_match'] for x in eligible),'denominator':len(eligible)} for k in ('injected_parent','injected_supplement')}
save('discovery/sample_comparison.json',{'rows':sample_rows,'conditional_strict_retention':retention,
 'scope':'All canonical source-cited candidates, including pending. Not filtered by accepted/POC/run terminal status.',
 'note':'Original paired exports and asymmetric supplemented comparison are separate. Presence/absence differences alone do not establish causal injection effects.'})
write('discovery/逐样本检出对照.md','# 基于源码候选的逐样本检出对照\n\n以候选与源码引用为统计对象，包含待审候选；不以工程终态、终审接受或POC通过作门槛。自动检查仅验证引用文件/范围和必要字段，不替代语义人工复核。未标记为反证排除、撤回或重复且通过这些检查的规范候选进入静态评分。\n\n'+
 table(['样本','类别','真值','基线候选匹配','原注入候选匹配','补证注入候选匹配'],[[x['sample_id'],x['category'],x['truth_id'],x['baseline']['strict_match'],x['injected_parent']['strict_match'],x['injected_supplement']['strict_match']] for x in sample_rows])+
 '\n原基线和原注入是同一初始配对；补证注入是追加取证后的单侧接续结果，不能当作一次新的等预算独立配对。严格匹配包含类型和主定位，不代表任意相关描述都未发现。未匹配的相关候选及具体诊断见JSON。\n\n条件匹配保留数：'+json.dumps(retention,ensure_ascii=False)+'。单次配对不能证明“注入普遍无影响”；这些数字不是终审通过率或动态验证率。\n')
write('discovery/静态候选评分.md','# 静态候选评分\n\n与历史已接受集合评分分开。真值与源码不变；注入源的21处锚点仅机械处理行偏移。\n\n'+table(['集合','候选','TP','D','U','FP','FN','Precision','Recall','F1'],[[label,*metrics(scores[label])] for label in sources])+'\nFP=D+U是协议计数；U不等于已证实为假的漏洞。数据只覆盖归档中的规范候选，不声称是所有未发布模型草稿。\n')

# A controlled ablation on the SAME frozen claim versions, not invented historical pre-review state.
raw_path=PROJECTS/'closure_evidence_20261111/evidence/new/frozen_report.redacted.json'
origin(raw_path,'Fixed frozen raw candidate set; offline duplicate-label ablation')
raw=load(raw_path)['findings']
before=[];after=[];ledger=[]
for f in raw:
 record={k:f.get(k) for k in KEEP};record['finding_kind']='vulnerability';record['disposition']='open';before.append(record)
 disposition=f.get('disposition','open'); retained=disposition not in ('duplicate','retracted','superseded')
 if retained:after.append(record)
 ledger.append({'finding_id':f['id'],'title':f.get('title'),'frozen_disposition':disposition,'kept':retained,
   'reason':f.get('disposition_reason'),'primary_location':f.get('primary_location'),'vulnerability_type':f.get('vulnerability_type')})
assert len(before)==34 and len(after)==31 and {f['id'] for f in after}<={f['id'] for f in before}
bscore=score('dedup_all_frozen34',before);ascore=score('dedup_retained31',after)
save('dedup/disposition_ledger.json',ledger)
save('dedup/experiment.json',{'method':'Offline same-version fixed-set duplicate-label ablation; not historical pre-review reconstruction',
 'source_run':'3b50dbaf45955d989aacf47162e47967','before_ids':[x['id'] for x in before],'after_ids':[x['id'] for x in after],
 'unchanged_claim_fields':list(KEEP),'removed_ids':[x['finding_id'] for x in ledger if not x['kept']]})
write('dedup/固定候选去重消融.md','# 固定候选集合的离线去重消融\n\n采用新高召回运行冻结的34条原始记录；所有候选保持同一版本的类型、主定位和源码引用。实验A暂时忽略冻结处置标签让34条均参与评分；实验B按原处置理由去除3条重复，剩31条。输入、脚本、逐条理由均可重放，不进行新模型调用。\n\n'+table(['条件','候选','TP','D','U','FP','FN','Precision','Recall','F1'],[['忽略重复标签',*metrics(bscore)],['应用重复标签',*metrics(ascore)]])+'\n这证明此冻结候选集合上应用已有去重裁决的统计效果，不能声称重建了历史终审前的原始文本，也不能将不同运行的能力差异当作降噪效果。减少的是重复断言，不是证实排除了这些漏洞根因。\n\n'+table(['被合并ID','标题','冻结原理由'],[[x['finding_id'],x['title'],x['reason']] for x in ledger if not x['kept']]))

# Normalize only exported security alert instances. Informational findings stay in the ledger, not in the benchmark candidate denominator.
zap_path=PROJECTS/'e_materials_20261111/zap/active.json';origin(zap_path,'Actual unauthenticated active ZAP scan exported instances')
zap=load(zap_path);truths=load(ROOT/'inputs/ground_truth.json')['vulnerabilities'];anchors=load(ROOT/'inputs/baseline_anchors.json')
anchors_by_id={x['id']:x for x in anchors['vulnerabilities']}
reasons={'40012':'反射型XSS，与源码/路由/参数核对后映射', '10202':'缺少CSRF提示；login/register不等同该路由的会话固定/MD5真值',
 '10038':'缺CSP安全加固项，官方30项真值无对应项','10106':'HTTP部署提示，非官方30项漏洞','10020':'缺点击劫持响应头，非官方30项漏洞',
 '10009':'404页面banner信息，不等同数据库异常堆栈泄露真值#09','10036':'Server版本头，不等同数据库异常堆栈泄露真值#09',
 '10021':'缺nosniff响应头，非官方30项漏洞'}
scanner=[];alert_ledger=[];seen={};mapped=[]
for site in zap.get('site',[]):
 for alert in site.get('alerts',[]):
  plugin=str(alert['pluginid']);risk=int(alert['riskcode'])
  for idx,instance in enumerate(alert.get('instances',[])):
   route=urlsplit(instance.get('uri','')).path or '/';param=instance.get('param','')
   key=(plugin,route,param);rid='zap-'+hashlib.sha256(json.dumps(key).encode()).hexdigest()[:16]
   included=risk>0;first=key not in seen
   row={'alert_type':plugin,'riskcode':risk,'name':alert['alert'],'url':instance.get('uri'),'route':route,'method':instance.get('method'),
        'parameter':param,'instance_index':idx,'evidence':instance.get('evidence'),'included':included,'assertion_id':rid,
        'deduplicated':included and not first,'reason':reasons.get(plugin,'ZAP信息类记录，保留原始实例但不作为本次安全告警候选'),
        'official_truth_match':None,'mapping_basis':'Codex源码辅助协议映射；不是成员E旧批次的人工签名裁决'}
   if included and first:
    loc=None;typ='csrf' if plugin=='10202' else 'out_of_lab30_taxonomy'
    if plugin=='40012' and route=='/catalog/greeting.php' and param=='name':
     with zipfile.ZipFile(ROOT/'inputs/baseline_full.zip') as z:
      code=z.read('lab30-shop/app/public/catalog/greeting.php').splitlines()
     a=anchors_by_id['02']['scoring_locations'][0]
     assert hashlib.sha256(code[a['line']-1]).hexdigest()==a['line_sha256']
     assert "$_GET['name']" in b'\n'.join(code).decode() and '$name' in code[a['line']-1].decode() and instance.get('evidence')
     loc={'path':'lab30-shop/'+a['path'],'line':a['line']};typ='xss_r';row['official_truth_match']='02';mapped.append(rid)
    scanner.append({'id':rid,'finding_kind':'vulnerability','disposition':'open','title':alert['alert']+' '+route,
      'summary':'Scanner alert normalized as plugin+route+parameter; full instances in ledger. Not independently validated.',
      'vulnerability_type':typ,'primary_location':loc,'evidence':[],'source':'ZAP','scanner_plugin_id':plugin})
   elif included and key in seen:
    row['official_truth_match']=seen[key].get('official_truth_match')
   if included and first:seen[key]=row
   alert_ledger.append(row)
zapscore=score('zap_exported_security_assertions',scanner)
llm=datasets['baseline'];llmscore=scores['baseline'];union=copy.deepcopy(llm);merges=[]
for prediction in scanner:
 existing=next((f for f in union if prediction['primary_location'] is not None and f.get('primary_location')==prediction['primary_location'] and f.get('vulnerability_type')==prediction['vulnerability_type']),None)
 if existing:merges.append({'scanner_id':prediction['id'],'llm_id':existing['id'],'rule':'Exact same type and main source location; retain once with both sources'})
 else:union.append(prediction)
uscore=score('scanner_llm_union',union)
save('scanner/alert_instance_ledger.json',{'normalization':'plugin_id + URL path + parameter; informational riskcode=0 excluded; no severity threshold tuning',
 'exported_instances':len(alert_ledger),'records':alert_ledger,'canonical_security_assertions':len(scanner)})
save('scanner/union_merges.json',merges)
write('scanner/三路对照与映射.md','# 扫描器与LLM的三路对照\n\n扫描数据为已有独立Lab30未登录ZAP主动扫描；LLM选固定原基线的全部规范源码候选（含待审），与上述发现能力口径一致。ZAP按plugin+路由path+参数归一化，信息级记录不计入安全告警分母，完整实例均保留。唯一直接映射为反射XSS规则40012、greeting.php/name与真值#02，源码锚点行哈希已核对。其余导出安全告警均按协议未匹配U统计，不声称已证实为假。\n\n'+
 table(['实验臂','候选','TP','D','U','FP','FN','Precision','Recall','F1'],[['仅LLM',*metrics(llmscore)],['仅ZAP导出安全断言',*metrics(zapscore)],['二者并集去重',*metrics(uscore)]])+
 '\n分母：导出实例'+str(len(alert_ledger))+'，信息级'+str(sum(not x['included'] for x in alert_ledger))+'，安全实例'+str(sum(x['included'] for x in alert_ledger))+'，归一化安全断言'+str(len(scanner))+'。JSON导出受ZAP实例数量上限影响，不能写成扫描器全部实际请求的总告警数，也不复用旧E文稿的50 FP。官方协议FP=D+U不等于全部为真实假阳性。\n\n并集仅合并了相同类型和精确主定位的共同根因；其他未匹配项未做“复核消减”，不声称已减少假阳性。此ZAP为无认证有限爬取，LLM为全源码审计，访问范围不同；可说明两条实际流程的表现，不能据此公平比较算法优劣。ZAP的命中未给此LLM集合增加新真值，不强行宣称联动提升。\n\n'+
 table(['规则','实例/归一化断言','映射或未匹配依据'],[[p,str(sum(x['alert_type']==p for x in alert_ledger))+'/'+str(sum(f.get('scanner_plugin_id')==p for f in scanner)),reasons.get(p,'信息级，单独列出')] for p in dict.fromkeys(x['alert_type'] for x in alert_ledger)])+
 '\n基线源码归档与ZAP部署已在先前采集核对4个关键文件；不声称整镜像全部文件字节一致。至少六个案例及原始证据见完整实例台账。#08开放重定向仍是正例，不以CVSS0将其移除。\n')
save('scores/execution.json',executions);save('provenance/sources.json',PROVENANCE)
save('summary.json',{'created_at':dt.datetime.now(dt.timezone.utc).isoformat(),'discovery':{k:dict(zip(('findings','TP','D','U','FP','FN','precision','recall','f1'),metrics(v))) for k,v in scores.items()},
 'sample_retention':retention,'dedup':{'before':metrics(bscore),'after':metrics(ascore)},'scanner':{'exported_instances':len(alert_ledger),'canonical_assertions':len(scanner),'score':metrics(zapscore),'union_score':metrics(uscore)},
 'model_requests':0,'runner_jobs':0,'database_required':False})
print(json.dumps(load(ROOT/'summary.json'),ensure_ascii=False))
