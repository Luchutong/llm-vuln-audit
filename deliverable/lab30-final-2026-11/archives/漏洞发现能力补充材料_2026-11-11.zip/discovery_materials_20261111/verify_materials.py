"""Verify file integrity and replay all scores without model/DB/runner access."""
import hashlib,json,os,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def load(name):return json.loads((ROOT/name).read_text(encoding='utf-8'))
manifest=load('manifest.json')
for name,item in manifest['files'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==item['sha256'],name
executions=load('scores/execution.json')
with tempfile.TemporaryDirectory() as folder:
 for item in executions:
  label=item['label'];anchor='injected' if label in ('discovery_injected_parent','discovery_injected_supplement') else 'baseline'
  path=Path(folder)/(label+'.json')
  cmd=[sys.executable,str(ROOT/'replay/scripts/score_dataset.py'),'--protocol','lab30-v2','--truth',str(ROOT/'inputs/ground_truth.json'),
      '--anchors',str(ROOT/f'inputs/{anchor}_anchors.json'),'--findings',str(ROOT/f'scores/{label}_input.json'),'--out',str(path)]
  p=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8',env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
  assert p.returncode==0,p.stderr
  actual=json.loads(path.read_text(encoding='utf-8'));expected=load(f'scores/{label}.json')
  actual.pop('truth_file',None);expected.pop('truth_file',None);assert actual==expected,label
before={f['id']:f for f in load('scores/dedup_all_frozen34_input.json')}
after={f['id']:f for f in load('scores/dedup_retained31_input.json')}
assert len(before)==34 and len(after)==31 and set(after)<=set(before)
assert all(f==before[k] for k,f in after.items())
assert load('scores/dedup_all_frozen34.json')['TP']==load('scores/dedup_retained31.json')['TP']==29
ledger=load('scanner/alert_instance_ledger.json')
assert len(ledger['records'])==38
assert sum(x['included'] for x in ledger['records'])==27
assert ledger['canonical_security_assertions']==25
print(json.dumps({'status':'passed','files':len(manifest['files']),'scores_replayed':len(executions),
                 'fixed_candidate_contents_unchanged':True,'model_requests':0,'runner_jobs':0,'database_required':False},ensure_ascii=False))
