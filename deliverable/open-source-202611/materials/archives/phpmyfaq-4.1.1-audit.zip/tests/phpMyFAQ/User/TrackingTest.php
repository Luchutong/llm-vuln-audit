<?php

namespace phpMyFAQ\User;

use phpMyFAQ\Configuration;
use phpMyFAQ\Database\DatabaseDriver;
use PHPUnit\Framework\Attributes\AllowMockObjectsWithoutExpectations;
use PHPUnit\Framework\MockObject\Exception;
use PHPUnit\Framework\TestCase;
use ReflectionClass;
use Symfony\Component\HttpFoundation\HeaderBag;
use Symfony\Component\HttpFoundation\InputBag;
use Symfony\Component\HttpFoundation\Request;

#[AllowMockObjectsWithoutExpectations]
class TrackingTest extends TestCase
{
    private Configuration $configurationMock;
    private Request $requestMock;
    private UserSession $userSessionMock;
    private DatabaseDriver $databaseMock;
    private Tracking $tracking;

    /**
     * @throws Exception
     */
    protected function setUp(): void
    {
        $this->configurationMock = $this->createStub(Configuration::class);
        $this->requestMock = $this->createStub(Request::class);
        $this->requestMock->headers = new HeaderBag([
            'X-Forwarded-For' => '192.168.1.1',
        ]);
        $this->requestMock->method('getClientIp')->willReturn('127.0.0.1');
        $this->userSessionMock = $this->createStub(UserSession::class);
        $this->databaseMock = $this->createStub(DatabaseDriver::class);

        $this->configurationMock->method('getDb')->willReturn($this->databaseMock);
        $this->tracking = Tracking::getInstance($this->configurationMock, $this->requestMock, $this->userSessionMock);
    }

    /**
     * @throws \ReflectionException
     */
    public function testInitializeSessionId(): void
    {
        $this->requestMock->query = new InputBag([
            UserSession::KEY_NAME_SESSION_ID => 123,
            UserSession::COOKIE_NAME_SESSION_ID => 456,
        ]);

        $reflection = new ReflectionClass($this->tracking);
        $method = $reflection->getMethod('initializeSessionId');
        $method->invoke($this->tracking);

        $property = $reflection->getProperty('currentSessionId');
        $this->assertEquals(123, $property->getValue($this->tracking));
    }

    /**
     * @throws \ReflectionException
     */
    public function testGetCookieId(): void
    {
        $this->requestMock->query = new InputBag([
            UserSession::KEY_NAME_SESSION_ID => 123,
            UserSession::COOKIE_NAME_SESSION_ID => 456,
        ]);

        $reflection = new ReflectionClass($this->tracking);
        $method = $reflection->getMethod('getCookieId');
        $result = $method->invoke($this->tracking);

        $this->assertEquals(456, $result);
    }

    /**
     * @throws \ReflectionException
     */
    public function testCountBots(): void
    {
        $this->configurationMock->method('get')->willReturn('bot1,bot2');
        $this->requestMock->headers = new HeaderBag([
            'user-agent' => 'bot1',
        ]);

        $reflection = new ReflectionClass($this->tracking);
        $method = $reflection->getMethod('countBots');
        $result = $method->invoke($this->tracking);

        $this->assertEquals(1, $result);
    }
}
